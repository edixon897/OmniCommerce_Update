import flet as ft
from pages.estadisticas_view import estadisticas_view
from pages.mis_usuarios_view import mis_usuarios_view
from pages.inventario_view import inventario_view
from pages.proveedor_view import proveedor_view
from pages.ventas_view import ventas_view
from pages.caja_view import caja_view
from pages.realizar_venta_view import realizar_venta_view
from pages.gestion_facturas_view import gestion_facturas_view
from pages.codigos_barra_view import codigos_barra_view
from pages.cliente_view import cliente_view
from utils.usuarioSesion import estado_global
from utils.regisEmpresa import crear_modal_tienda  # Asegúrate de que la ruta es correcta
from routes.tienda import consultar_empresa, register_empresa 
from pages.categoria_view import categoria_view



def barra_menu(page: ft.Page):
    # Configuración de la página
    page.title = "OmniCommerce"
    page.window.width = 1350
    page.window.height = 800
    page.theme_mode = ft.ThemeMode.LIGHT
    

    # Estado para saber si el menú está expandido o no
    menu_expanded = ft.Ref[bool]()
    menu_expanded.value = True

    # Variable para guardar la vista actual
    current_view = ft.Ref[ft.Column]()

    # Función para alternar el estado del menú
    def toggle_menu(e):
        menu_expanded.value = not menu_expanded.value
        menu_drawer.extended = menu_expanded.value
        toggle_button.icon = ft.icons.CHEVRON_LEFT if menu_expanded.value else ft.icons.CHEVRON_RIGHT
        page.update()
    

    # Función para cambiar la vista basada en la selección del menú
    def change_view(index):
        if index == 0:
            current_view.current.controls[1] = estadisticas_view(page)
        elif index == 1:
            current_view.current.controls[1] = mis_usuarios_view((page))
        elif index == 2:
            current_view.current.controls[1] = inventario_view((page))
        #elif index == 3:
        #    current_view.current.controls[1] = categoria_view()
        elif index == 3:
            current_view.current.controls[1] = proveedor_view((page))
        elif index == 4:
            current_view.current.controls[1] = ventas_view(page)
        elif index == 5:
            current_view.current.controls[1] = caja_view(page)
        elif index == 6:
            current_view.current.controls[1] = realizar_venta_view(page)
        #elif index == 8:
        #    current_view.current.controls[1] = gestion_facturas_view(page)
        #elif index == 9:
        #    current_view.current.controls[1] = codigos_barra_view()
        elif index == 7:
            current_view.current.controls[1] = cliente_view((page))
        current_view.current.update()
        
    def mostrar_menu_perfil(e):
        profile_menu_container.visible = not profile_menu_container.visible
        page.update()

    # Funciones para las opciones de menú
    def abrir_ajustes(e):
        pass

    def editar_usuario(e):
        pass

    def cerrar_sesion(e):
        return

    # Contenedor para el menú desplegable de perfil
    profile_menu_container = ft.Container(
        visible=False,
        content=ft.Column(
            [
                ft.ListTile(
                    leading=ft.Icon(ft.icons.SETTINGS),
                    title=ft.Text("Ajustes"),
                    on_click=abrir_ajustes,
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.icons.EDIT),
                    title=ft.Text("Editar Usuario"),
                    on_click=editar_usuario,
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.icons.EXIT_TO_APP),
                    title=ft.Text("Cerrar Sesión"),
                    on_click=cerrar_sesion,
                ),
            ],
            spacing=5,
        ),
        width=150,
        padding=ft.Padding(left=0, top=0, right=0, bottom=0),
        border_radius=10,
        bgcolor=ft.colors.WHITE,
        shadow=ft.BoxShadow(blur_radius=10, color=ft.colors.GREY_200),
        offset=ft.Offset(x=0, y=40),  # Ajuste para que aparezca justo debajo del perfil
    )


    menu_drawer = ft.NavigationRail(
        selected_index=0,
        destinations=[
            ft.NavigationRailDestination(icon=ft.icons.DASHBOARD, label="Estadísticas"),
            ft.NavigationRailDestination(icon=ft.icons.SUPERVISED_USER_CIRCLE_OUTLINED, label="Mis Usuarios"),
            ft.NavigationRailDestination(icon=ft.icons.ADD_SHOPPING_CART, label="Inventario"),
            #ft.NavigationRailDestination(icon=ft.icons.INVENTORY_SHARP, label="Categorias"),
            ft.NavigationRailDestination(icon=ft.icons.LOCAL_SHIPPING, label="Proveedores"),
            ft.NavigationRailDestination(icon=ft.icons.DOCUMENT_SCANNER_ROUNDED, label="Ventas/Cotizaciones"),
            ft.NavigationRailDestination(icon=ft.icons.ASSIGNMENT, label="Caja Registradora"),
            ft.NavigationRailDestination(icon=ft.icons.SHOPPING_CART_ROUNDED, label="Realizar Venta"),
            #ft.NavigationRailDestination(icon=ft.icons.FACT_CHECK_SHARP, label="Gestión de Facturas"),
            #ft.NavigationRailDestination(icon=ft.icons.QR_CODE_SHARP, label="Códigos de Barra"),
            ft.NavigationRailDestination(icon=ft.icons.PEOPLE_OUTLINE_ROUNDED, label="Clientes"),
        ],
        extended=menu_expanded.value,
        height=700,
        on_change=lambda e: change_view(e.control.selected_index)
        
    )

    # Botón para alternar el menú
    toggle_button = ft.IconButton(
        icon=ft.icons.CHEVRON_LEFT if menu_expanded.value else ft.icons.CHEVRON_RIGHT,
        on_click=toggle_menu
    )
    nombre_perfil = estado_global.get_nombre()
    # Nombre de la persona y el icono de perfil
    profile_name = nombre_perfil.capitalize()
    profile_icon = ft.Icon(ft.icons.ACCOUNT_CIRCLE, size=24)

    # Contenedor redondeado con nombre e ícono
    profile_container = ft.Container(
        content=ft.Row(
            [
                profile_icon,
                ft.Text(profile_name, weight=ft.FontWeight.BOLD),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=8,
        ),
        padding=ft.Padding(left=12, top=8, right=12, bottom=8),
        border_radius=15,
        bgcolor=ft.colors.BLUE_GREY_100,
        on_click=mostrar_menu_perfil  # Llama a mostrar el menú al hacer clic
    )

    # Inicializa la vista actual con la pantalla de Estadísticas
    current_view.current = ft.Column(
        [
            ft.Row(
                [
                    toggle_button,
                    ft.Container(expand=True),
                    profile_container,
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                spacing=10
            ),
            estadisticas_view(page)  # Muestra la vista inicial
        ],
        expand=True
    )

    # Layout principal: Row que contiene el menú lateral y el contenido principal

    menu =   ft.Row(
            [
                menu_drawer,
                ft.Container(current_view.current, expand=True)
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.START,
            expand=True,
        )
    
    mostrar_modal_tienda = crear_modal_tienda(page, register_empresa)
    empresa = consultar_empresa()

    # Verificar si los datos de la empresa cumplen con las condiciones para mostrar el modal
    if empresa:
        # Desempaquetamos los valores de la tupla
        id_tienda, nombre_tienda, direccion_tienda, telefono_tienda, correo_tienda, logo_tienda, descripcion_tienda, *_ = empresa

        # Verificamos si todos los campos están llenos
        campos = [nombre_tienda, direccion_tienda, telefono_tienda, correo_tienda, logo_tienda, descripcion_tienda]
        todos_llenos = all(campo not in ("", None) for campo in campos)  # Todos los campos deben estar llenos

        if not todos_llenos:
            # Mostrar modal con los campos llenos para editar o completar los vacíos
            mostrar_modal_tienda(
                nombre_tienda=nombre_tienda or "",
                direccion_tienda=direccion_tienda or "",
                telefono_tienda=telefono_tienda or "",
                correo_tienda=correo_tienda or "",
                logo_tienda=logo_tienda or "",
                descripcion_tienda=descripcion_tienda or ""
            )
        else:
            return False
    else:

        mostrar_modal_tienda()


    

    

    # Ejecutar la aplicación
    page.add(menu)
    
    return menu


