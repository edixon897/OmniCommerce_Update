import flet as ft
from models.sesion import inicio_de_sesion
from home.pantalla_inicio import barra_menu
from utils.mensajeAlerta import mostrar_alerta_auto
from utils.usuarioSesion import estado_global


def inicioSesion(page: ft.Page):
    page.title = "Inicio de Sesión"
    page.window.width = 900
    page.window.height = 700
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    page.bgcolor = ft.colors.WHITE

    # Configuración del modal de recuperación de contraseña
    email_recover_field = ft.TextField(
        label="Correo Electrónico",
        width=300,
        text_align=ft.TextAlign.CENTER,
        border_color=ft.colors.LIGHT_BLUE_ACCENT,
        border_radius=8,
    )

    recovery_message = ft.Text(
        "Si el correo es válido, recibirás un enlace para restablecer tu contraseña.",
        color=ft.colors.GREEN,
        visible=False
    )

    def enviar_enlace(e):
        recovery_message.visible = True
        page.update()

    recovery_modal = ft.AlertDialog(
        modal=True,
        content=ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        "Recuperación de Contraseña",
                        weight="bold",
                        color=ft.colors.DEEP_PURPLE,
                        size=20,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    email_recover_field,
                    recovery_message,
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Enviar Enlace",
                                on_click=enviar_enlace
                            ),
                            ft.TextButton(
                                "Cancelar",
                                on_click=lambda e: (
                                    setattr(recovery_modal, 'open', False),
                                    page.update()
                                )
                            )
                        ],
                        alignment="center",
                    )
                ],
                alignment="center",
                horizontal_alignment="center",
                spacing=10,
            ),
            width=400,
            height=300,
            padding=20,
        )
    )

    def validar_sesion(e):
        documento_valor = documento.value
        password_valor = password.value
        usuario = inicio_de_sesion(documento_valor, password_valor)

        if usuario:
            page.clean()
            estado_global.set_usuario(usuario)
            barra_menu(page)
            page.update()
        else:
            mostrar_alerta_auto(page, "Error de inicio de sesión", "Por favor, verifica tus credenciales.", duracion=3)

    def show_recovery_form(e):
        page.dialog = recovery_modal
        recovery_modal.open = True
        recovery_message.visible = False
        page.update()

    # Configuración de los elementos de la pantalla de inicio de sesión
    documento = ft.TextField(
        label="Número de documento", 
        width=350,
        border_radius=8,
        border_color=ft.colors.BLACK,
        bgcolor=ft.colors.WHITE,
        text_style=ft.TextStyle(color=ft.colors.BLACK)
    )
    password = ft.TextField(
        label="Contraseña",
        password=True, 
        can_reveal_password=True, 
        width=350,
        border_radius=8,
        border_color=ft.colors.BLACK,
        bgcolor=ft.colors.WHITE,
        text_style=ft.TextStyle(color=ft.colors.BLACK)
    )

    

    login_button = ft.ElevatedButton(
        "Iniciar Sesión", 
        on_click=validar_sesion, 
        width=250,
        bgcolor=ft.colors.BLACK, 
        color=ft.colors.WHITE,
        height=50,
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=12)
        )

    )


    register_button = ft.TextButton(
        "Crear nueva cuenta",
        width=250,
        on_click=lambda e: print("Crear cuenta"),
        style=ft.ButtonStyle(
            color=ft.colors.BLUE_600
        )

    )
    

    forgot_password_button = ft.TextButton(
        "¿Olvidaste tu contraseña?",
        on_click=show_recovery_form,
        style=ft.ButtonStyle(
            color=ft.colors.BLUE_600
        )

    )

    # Formulario de inicio de sesión
    login_form = ft.Column(
        [
            ft.Text("Inicio de Sesión", size=30, weight="bold", color=ft.colors.BLACK),
            documento,
            password,
            login_button,
            forgot_password_button,
            ft.Divider(height=1, color=ft.colors.BLACK, thickness=1),
            register_button,
        ],
        alignment="center",
        horizontal_alignment="center",
        spacing=15,
        width=400,
    )

    # Sección de bienvenida
    welcome_section = ft.Column(
        [
            ft.Text("OmniCommerce", size=45, weight="bold", color=ft.colors.BLUE_700),
            ft.Text(
                "Bienvenido a OmniCommerce, tu plataforma integral de gestión de ventas e inventario.",
                size=20,
                color=ft.colors.BLACK,
                text_align=ft.TextAlign.CENTER,
            ),
        ],
        alignment="center",
        horizontal_alignment="center",
        spacing=10,
    )

    # Contenedor que incluye ambas secciones
    combined_section = ft.Row(
        [
            ft.Container(
                content=welcome_section,
                alignment=ft.alignment.center,
                padding=ft.padding.all(20),
                bgcolor=ft.colors.WHITE,
                expand=True,
            ),
            ft.Container(
                content=login_form,
                alignment=ft.alignment.center,
                padding=ft.padding.all(20),
                bgcolor=ft.colors.WHITE,
                border_radius=ft.border_radius.all(12),
                shadow=ft.BoxShadow(spread_radius=2, blur_radius=15, color=ft.colors.BLACK12),
                expand=True,
            )
        ],
        alignment="center",
        spacing=20,
    )

    # Contenedor principal que envuelve todo
    main_container = ft.Container(
        content=combined_section,
        alignment=ft.alignment.center,
        padding=ft.padding.all(30),
        expand=True,
        bgcolor=ft.colors.WHITE,  # Fondo para resaltar el contenedor principal
        border_radius=ft.border_radius.all(0),  # Bordes redondeados para todo el contenedor
        shadow=ft.BoxShadow(spread_radius=5, blur_radius=15, color=ft.colors.GREY_500)  # Sombra para el contenedor principal

    )

    # Agregar el contenedor principal a la página
    page.add(main_container)
    documento.on_submit = lambda e: password.focus()
    password.on_submit = validar_sesion

    documento.focus()

    return main_container