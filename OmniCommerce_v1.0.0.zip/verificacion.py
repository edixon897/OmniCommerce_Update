import json
import os

CONFIG_PATH = "config/update_config.json"
VERSION_FILE = "version.txt"
EXCLUDE_FILE = "update_exclude.json"

def load_update_config():
    """Carga la configuración de actualizaciones desde update_config.json."""
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(f"No se encontró el archivo {CONFIG_PATH}")
    with open(CONFIG_PATH, "r") as file:
        return json.load(file)

def save_update_config(data):
    """Guarda la configuración de actualizaciones en update_config.json."""
    with open(CONFIG_PATH, "w") as file:
        json.dump(data, file, indent=4)

def get_current_version():
    """Obtiene la versión actual desde version.txt."""
    if not os.path.exists(VERSION_FILE):
        return "0.0.0"
    with open(VERSION_FILE, "r") as file:
        return file.read().strip()

def update_current_version(new_version):
    """Actualiza la versión actual en version.txt."""
    with open(VERSION_FILE, "w") as file:
        file.write(new_version)

def load_exclude_list():
    """Carga la lista de exclusión de actualizaciones desde update_exclude.json."""
    if not os.path.exists(EXCLUDE_FILE):
        return []
    with open(EXCLUDE_FILE, "r") as file:
        data = json.load(file)
        return data.get("exclude", [])
