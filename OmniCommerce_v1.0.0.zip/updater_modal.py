import json
import os
import requests
import zipfile
import shutil
import subprocess
from pathlib import Path
from flet import Page, Column, Row, ProgressBar, Text, ElevatedButton, AlertDialog

# Archivos de configuración
CONFIG_PATH = "config/update_config.json"
VERSION_FILE = "version.txt"
EXCLUDE_FILE = "update_exclude.json"
UPDATE_URL = "https://api.github.com/repos/tu_usuario/sistema_venta_actualizaciones/releases/latest"

def get_current_version():
    """Obtiene la versión actual desde version.txt."""
    if not os.path.exists(VERSION_FILE):
        return "0.0.0"  # Valor predeterminado si no existe version.txt
    with open(VERSION_FILE, "r") as f:
        return f.read().strip()

def get_latest_release():
    """Obtiene la última versión desde GitHub."""
    response = requests.get(UPDATE_URL)
    if response.status_code == 200:
        release_data = response.json()
        version = release_data["tag_name"]
        download_url = release_data["assets"][0]["browser_download_url"]
        return version, download_url
    else:
        raise Exception("No se pudo conectar con GitHub.")

def download_update(download_url, progress_callback):
    """Descarga el archivo de actualización con progreso."""
    response = requests.get(download_url, stream=True)
    total_size = int(response.headers.get("Content-Length", 0))
    downloaded_size = 0

    target_path = "update.zip"
    with open(target_path, "wb") as file:
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                file.write(chunk)
                downloaded_size += len(chunk)
                progress_callback(downloaded_size, total_size)
    return target_path

def apply_update(update_file, progress_callback):
    """Aplica la actualización descargada."""
    with zipfile.ZipFile(update_file, "r") as zip_ref:
        file_list = zip_ref.namelist()
        total_files = len(file_list)
        extracted_files = 0

        zip_ref.extractall("temp_update")

        # Ignorar carpetas sensibles
        exclude = load_exclude_list()
        for item in os.listdir("temp_update"):
            if item not in exclude:
                src = os.path.join("temp_update", item)
                dst = os.path.join(".", item)
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dst)

            extracted_files += 1
            progress_callback(extracted_files, total_files)

    # Limpiar archivos temporales
    shutil.rmtree("temp_update")
    os.remove(update_file)

def load_exclude_list():
    """Carga la lista de exclusión de actualizaciones desde update_exclude.json."""
    if not os.path.exists(EXCLUDE_FILE):
        return []
    with open(EXCLUDE_FILE, "r") as file:
        data = json.load(file)
        return data.get("exclude", [])

def restart_application():
    """Reinicia la aplicación."""
    python = Path(os.sys.executable)
    os.execl(python, python, *os.sys.argv)

def update_software(page: Page):
    """Proceso completo de actualización con interfaz."""
    current_version = get_current_version()
    latest_version, download_url = get_latest_release()

    if current_version == latest_version:
        return  # No hay actualizaciones, continuar con la app

    # Configuración del diálogo de actualización
    progress_text = Text("Preparando para actualizar...", size=16)
    progress_bar = ProgressBar(width=300)

    def start_update(e):
        """Inicia el proceso de actualización al hacer clic en el botón."""
        def update_download_progress(downloaded, total):
            progress = downloaded / total
            progress_bar.value = progress
            progress_text.value = f"Descargando... {progress * 100:.2f}%"
            page.update()

        def update_apply_progress(processed, total):
            progress = processed / total
            progress_bar.value = progress
            progress_text.value = f"Aplicando cambios... {progress * 100:.2f}%"
            page.update()

        # Descarga
        progress_text.value = "Descargando actualización..."
        page.update()
        update_file = download_update(download_url, update_download_progress)

        # Aplicación
        progress_text.value = "Aplicando cambios..."
        page.update()
        apply_update(update_file, update_apply_progress)

        # Finalización y reinicio
        progress_text.value = "Actualización completada. Reiniciando sistema..."
        progress_bar.value = 1.0
        page.update()
        restart_application()

    # Crear el diálogo de actualización
    update_dialog = AlertDialog(
        title=Text(f"Actualización disponible: {latest_version}"),
        content=Column([
            Text(f"Se detectó una nueva versión {latest_version}."),
            Text("Por favor, no cierre la aplicación."),
            progress_text,
            progress_bar
        ]),
        actions=[
            ElevatedButton("Iniciar actualización", on_click=start_update),
            ElevatedButton("Cancelar", on_click=lambda e: page.dialog.close())
        ],
        modal=True
    )

    # Mostrar el diálogo
    page.dialog = update_dialog
    update_dialog.open = True
    page.update()
