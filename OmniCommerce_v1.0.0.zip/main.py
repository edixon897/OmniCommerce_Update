import flet as ft
from home.sesion import inicioSesion
import automatizacion.promo_automa

# Importa el sistema de actualización
from updater_modal import update_software  # Asegúrate de que este archivo exista

def main(page: ft.Page):
    # Configuración inicial de la página
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"

    # Verificar actualizaciones antes de mostrar la app
    update_software(page)

    # Si no hay actualizaciones o una vez completadas, carga la aplicación principal
    page.add(inicioSesion(page))

# Ejecutar la aplicación
if __name__ == "__main__":
    ft.app(target=main)
