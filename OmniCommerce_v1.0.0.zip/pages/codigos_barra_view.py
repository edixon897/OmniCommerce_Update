import flet as ft

def codigos_barra_view():
    return ft.Container(
        content=ft.Text("Códigos de Barra", style=ft.TextThemeStyle.HEADLINE_LARGE),
        padding=20
    )
