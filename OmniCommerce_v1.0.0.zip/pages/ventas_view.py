import flet as ft
from routes.venta_cotizacion import (
    consulta_cotizaciones,
    consulta_ventas,
    buscar_cotizacion,
    buscar_ventas,
    consulta_devoluciones,
    buscar_devoluciones,
    ver_venta,
)
from routes.devolucion import registro_detalle_devolucion, registro_devolucion, ver_devolucion
from routes.cotizaciones import detalle_cotizacion
from decimal import Decimal
from utils.usuarioSesion import estado_global
import datetime
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
import os
import io

import base64
import win32print
import win32ui
import win32con
from PIL import Image, ImageDraw, ImageFont, ImageWin

def ventas_view(page: ft.Page):
    
    # Inicializar la vista actual como None para que la tabla no se muestre inicialmente
    vista_actual = None

    # Crear un contenedor principal que contendrá la tabla y se actualizará según la vista seleccionada
    main_container = ft.Container()

    # Definir botones con estilo y almacenarlos para actualizar su estilo posteriormente
    btn_ventas = ft.OutlinedButton(
        text="Ver Ventas",
        on_click=lambda e: cambiar_vista("ventas"),
        style=ft.ButtonStyle(
            side=ft.border.BorderSide(1, ft.colors.GREY),
            shape=ft.RoundedRectangleBorder(radius=5),
        ),
    )
    btn_cotizaciones = ft.OutlinedButton(
        text="Ver Cotizaciones",
        on_click=lambda e: cambiar_vista("cotizaciones"),
        style=ft.ButtonStyle(
            side=ft.border.BorderSide(1, ft.colors.GREY),
            shape=ft.RoundedRectangleBorder(radius=5),
        ), # visible=False
    )
    btn_devoluciones = ft.OutlinedButton(
        text="Ver Devoluciones",
        on_click=lambda e: cambiar_vista("devoluciones"),
        style=ft.ButtonStyle(
            side=ft.border.BorderSide(1, ft.colors.GREY),
            shape=ft.RoundedRectangleBorder(radius=5),
        ),
    )

    # Función para actualizar la vista del inventario
    def actualizar_vista_inventario(tipo_vista, termino_busqueda=None):
        # Limpiar el contenido del contenedor principal
        main_container.content = None
        
        if tipo_vista is None:
            # Si no se ha seleccionado una vista, no mostramos nada
            page.update()
            return

        # Obtener los datos según la vista actual
        if tipo_vista == "ventas":
            productos = consulta_ventas() if not termino_busqueda else buscar_ventas(nombre_producto=termino_busqueda)
            # Definir proporciones de las columnas usando 'expand'
            col_ID = ft.Container(ft.Text("ID Factura", weight="bold"), expand=3)
            col_Cliente = ft.Container(ft.Text("Cliente/Usuario", weight="bold"), expand=3)
            col_Fecha = ft.Container(ft.Text("Fecha", weight="bold"), expand=3)
            col_Metodo = ft.Container(ft.Text("Método/Estado", weight="bold"), expand=3)
            col_Total = ft.Container(ft.Text("Total", weight="bold"), expand=4)
            col_Opciones = ft.Container(ft.Text("Opciones", weight="bold"), expand=4)
        elif tipo_vista == "cotizaciones":
            productos = consulta_cotizaciones() if not termino_busqueda else buscar_cotizacion(nombre_producto=termino_busqueda)
            # Definir encabezados específicos para cotizaciones
            col_Codigo = ft.Container(ft.Text("Código", weight="bold"), expand=4)
            col_Usuario = ft.Container(ft.Text("Usuario Cotización", weight="bold"), expand=4)
            col_Fecha = ft.Container(ft.Text("Fecha", weight="bold"), expand=4)
            col_Total = ft.Container(ft.Text("Total", weight="bold"), expand=4)
            col_Opciones = ft.Container(ft.Text("Opciones", weight="bold"), expand=4)
        elif tipo_vista == "devoluciones":
            productos = consulta_devoluciones() if not termino_busqueda else buscar_devoluciones(criterio_busqueda=termino_busqueda)
            # Definir encabezados específicos para devoluciones
            col_Factura = ft.Container(ft.Text("ID Factura", weight="bold"), expand=4)
            col_UsuarioRegistro = ft.Container(ft.Text("Usuario Registro", weight="bold"), expand=4)
            col_FechaRegistro = ft.Container(ft.Text("Fecha Registro", weight="bold"), expand=4)
            col_TotalDevolucion = ft.Container(ft.Text("Total Devolución", weight="bold"), expand=4)
            col_Opciones = ft.Container(ft.Text("Opciones", weight="bold"), expand=4)
        else:
            productos = []

        # Crear el encabezado de la tabla como una fila
        if tipo_vista == "ventas":
            encabezado = ft.Row(
                [
                    col_ID,
                    col_Cliente,
                    col_Fecha,
                    col_Metodo,
                    col_Total,
                    col_Opciones,
                ],
                alignment=ft.MainAxisAlignment.START,
                spacing=5,
            )
        elif tipo_vista == "cotizaciones":
            encabezado = ft.Row(
                [
                    col_Codigo,
                    col_Usuario,
                    col_Fecha,
                    col_Total,
                    col_Opciones,
                ],
                alignment=ft.MainAxisAlignment.START,
                spacing=5,
            )
        elif tipo_vista == "devoluciones":
            encabezado = ft.Row(
                [
                    col_Factura,
                    col_UsuarioRegistro,
                    col_FechaRegistro,
                    col_TotalDevolucion,
                    col_Opciones,
                ],
                alignment=ft.MainAxisAlignment.START,
                spacing=5,
            )

        # Crear las filas de datos
        data_rows = []
        for producto in productos:
            if tipo_vista == "ventas":
                factura = producto
                color_texto = "green" if (factura[3] == 'efectivo') else "red"
                opciones = [
                    ft.IconButton(
                        icon=ft.icons.PRINT,
                        on_click=lambda e, id=factura[0]: mostrar_modal_imprimir(id),
                        icon_color='blue',
                        tooltip="Imprimir",
                    ),
                    ft.IconButton(
                        icon=ft.icons.FILE_DOWNLOAD,
                        on_click=lambda e, id=factura[0]: exportar_excel(id),
                        icon_color='green',
                        tooltip="Exportar a Excel",
                    ),
                    ft.IconButton(
                        icon=ft.icons.PICTURE_AS_PDF,
                        on_click=lambda e, id=factura[0]: generar_pdf(id),
                        icon_color='purple',
                        tooltip="Generar PDF",
                    ),
                    ft.IconButton(
                        icon=ft.icons.ARCHIVE,
                        on_click=lambda e, id=factura[0]: devolucion_venta(id),
                        icon_color='red',
                        tooltip="Hacer Devolución",
                    ),
                ]
                fila = ft.Row(
                    [
                        ft.Container(ft.Text(factura[0]), expand=3),
                        ft.Container(ft.Text(factura[1]), expand=3),
                        ft.Container(ft.Text(factura[2]), expand=3),
                        ft.Container(ft.Text(factura[3], color=color_texto), expand=3),
                        ft.Container(ft.Text(f"${factura[4]:,.2f}"), expand=4),
                        ft.Container(ft.Row(opciones, spacing=2), expand=4),
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=5,
                )
            elif tipo_vista == "cotizaciones":
                cotizacion = producto
                opciones = [
                    ft.IconButton(
                        icon=ft.icons.PRINT,
                        on_click=lambda e, id=cotizacion[0]: mostrar_modal_imprimir_cotizacion(id),
                        icon_color='blue',
                        tooltip="Imprimir",
                    ),
                    
                    ft.IconButton(
                        icon=ft.icons.PICTURE_AS_PDF,
                        on_click=lambda e, id=cotizacion[0]: generar_pdf_cotizacion(id),
                        icon_color='purple',
                        tooltip="Generar PDF",
                    ),
                    
                ]
                fila = ft.Row(
                    [
                        ft.Container(ft.Text(cotizacion[0]), expand=4),
                        ft.Container(ft.Text(cotizacion[1]), expand=4),
                        ft.Container(ft.Text(cotizacion[2]), expand=4),
                        ft.Container(ft.Text(f"${cotizacion[3]:,.2f}"), expand=4),
                        ft.Container(ft.Row(opciones, spacing=2), expand=4),
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=5,
                )
            elif tipo_vista == "devoluciones":
                devolucion = producto
                opciones = [
                    ft.IconButton(
                        icon=ft.icons.INFO_OUTLINED,
                        on_click=lambda e, id=devolucion[0]: ver_detalle_devolucion(id),
                        icon_color='blue',
                        tooltip="Ver Detalle",
                    ),
                ]
                fila = ft.Row(
                    [
                        ft.Container(ft.Text(devolucion[0]), expand=4),
                        ft.Container(ft.Text(devolucion[1]), expand=4),
                        ft.Container(ft.Text(devolucion[2]), expand=4),
                        ft.Container(ft.Text(f"${devolucion[3]:,.2f}"), expand=4),
                        ft.Container(ft.Row(opciones, spacing=2), expand=4),
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=5,
                )
            data_rows.append(fila)

        # Crear una Column con scroll para las filas de datos y altura fija
        data_table = ft.Column(
            controls=data_rows,
            scroll="auto",
            expand=True,
        )

        # Crear un contenedor que envuelva el encabezado y las filas
        tabla_container = ft.Container(
            content=ft.Column(
                [
                    encabezado,
                    ft.Divider(height=1, thickness=1),
                    data_table,
                ],
                expand=True,
                spacing=0,
            ),
            height=570,  # Altura fija para permitir el scroll cuando sea necesario
            border=ft.border.all(1, ft.colors.BLUE_GREY_200),
            border_radius=10,
            padding=ft.padding.all(2),
        )

        # Añadir la tabla al main_container
        main_container.content = tabla_container

        page.update()

    # Función para manejar el evento de búsqueda
    def buscar_producto_evento(e):
        termino = e.control.value
        if vista_actual:
            actualizar_vista_inventario(vista_actual, termino)
        else:
            page.snack_bar = ft.SnackBar(ft.Text("Seleccione una vista para buscar"), bgcolor="red")
            page.update()

    # Función para cambiar de vista y actualizar el estilo del botón seleccionado
    def cambiar_vista(tipo):
        nonlocal vista_actual
        vista_actual = tipo
        actualizar_vista_inventario(vista_actual)
        # Actualizar estilos de botones
        botones = {
            "ventas": btn_ventas,
            "cotizaciones": btn_cotizaciones,
            "devoluciones": btn_devoluciones,
        }
        for key, btn in botones.items():
            es_seleccionado = key == vista_actual
            btn.style = ft.ButtonStyle(
                side=ft.border.BorderSide(2, ft.colors.BLUE) if es_seleccionado else ft.border.BorderSide(1, ft.colors.GREY),
                bgcolor=ft.colors.LIGHT_BLUE_100 if es_seleccionado else None,
            )
            
        page.update()

    # Función para mostrar e imprimir la factura con opciones
    def mostrar_modal_imprimir(id_factura):
        # Obtener los detalles de la venta
        venta_detalle = ver_venta(id_factura)  # Asegúrate de que esta función esté implementada
        
        # Procesar los datos para generar la factura
        ventas = []
        subtotal = 0
        total = 0
        for item in venta_detalle:
            ventas.append({
                'producto': item[3],
                'cantidad': item[4],
                'total': item[6]
            })
            subtotal += item[6]
        total = subtotal  # Puedes agregar impuestos si es necesario

        # Generar la imagen de la factura
        factura_img = generar_factura_imagen(ventas, subtotal, total, id_factura)

        # Convertir la imagen a base64 para mostrarla en Flet
        factura_buffer = io.BytesIO()
        factura_img.save(factura_buffer, format='PNG')
        factura_data = factura_buffer.getvalue()

        # Aumentar el tamaño de la imagen en el modal
        factura_flet_image = ft.Image(
            src_base64=base64.b64encode(factura_data).decode('utf-8'),
            width=500,  # Aumenta el tamaño para mejor visualización
            height=700,
            fit=ft.ImageFit.CONTAIN
        )

        # Obtener la lista de impresoras disponibles
        printers = [printer[2] for printer in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
        
        # Crear controles para las opciones de impresión
        printer_dropdown = ft.Dropdown(
            label="Seleccione una impresora",
            options=[ft.dropdown.Option(printer) for printer in printers],
            value=win32print.GetDefaultPrinter()  # Establecer impresora predeterminada
        )

        copies_field = ft.TextField(
            label="Número de copias",
            value=1,
            width=100,
            keyboard_type=ft.KeyboardType.NUMBER
        )

        color_mode_dropdown = ft.Dropdown(
            label="Modo de color",
            options=[
                ft.dropdown.Option("Color"),
                ft.dropdown.Option("Blanco y Negro")
            ],
            value="Blanco y Negro"
        )


        # Función para imprimir la imagen con las opciones seleccionadas
        def imprimir_factura(e):
            printer_name = printer_dropdown.value
            try:
                num_copies = int(copies_field.value)
                if num_copies <= 0:
                    raise ValueError
            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Ingrese un número válido de copias"), bgcolor="red")
                page.snack_bar.open = True
                page.update()
                return
            color_mode = color_mode_dropdown.value == "Color"  # True si es color, False si es blanco y negro
            imprimir_imagen(factura_img, printer_name, num_copies, color_mode)
            page.snack_bar = ft.SnackBar(ft.Text("Imprimiendo..."), bgcolor="green")
            page.snack_bar.open = True
            cerrar_modal()
            page.update()

        # Crear un contenedor para las opciones de impresión
        opciones_impresion = ft.Column(
            [
                printer_dropdown,
                copies_field,
                color_mode_dropdown,
                ft.Row(
                    [
                        ft.ElevatedButton("Imprimir", on_click=imprimir_factura, bgcolor=ft.colors.BLUE, color="white"),
                        ft.ElevatedButton("Cancelar", on_click=lambda e: cerrar_modal(), bgcolor=ft.colors.RED, color="white"),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10
                ),
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
            width=350  # Ajusta el ancho según necesites
        )

        # Contenedor principal que contiene la imagen y las opciones a la derecha
        contenido_dialogo = ft.Row(
            [
                factura_flet_image,
                opciones_impresion
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=20
        )

        modal = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Factura ID: {id_factura}", size=18, weight="bold"),
            content=contenido_dialogo,
            # Quitamos las acciones del diálogo para colocar los botones debajo de las opciones
            # actions=[],
        )

        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal():
            modal.open = False
            page.update()

    # Función para generar la imagen de la factura
    def generar_factura_imagen(ventas, subtotal, total, id_factura):
        usuario_venta = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"

        # Configuracion del tamaño de la etiqueta y el DPI
        label_width = 3.0  # Ancho en pulgadas (segun tu impresora)
        label_height = 11  # Alto en pulgadas (segun tu impresora)
        dpi = 203  # DPI típico de impresoras de tickets

        # Calcula las dimensiones en píxeles
        width = int(label_width * dpi)
        height = int(label_height * dpi)

        # Crear una imagen en blanco para la factura
        factura_img = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(factura_img)

        # Configuración de fuente
        font_path = "arial.ttf"  # Cambia a la ruta de una fuente TTF válida en tu sistema
        font_size = 20  # Ajusta el tamaño de la fuente para mayor legibilidad
        try:
            font = ImageFont.truetype(font_path, font_size)
        except IOError:
            font = ImageFont.load_default()

        # Información del supermercado
        y_offset = 10  # Espaciado vertical inicial
        draw.text((width // 2 - 80, y_offset), "Supermercado XYZ", font=font, fill="black")
        y_offset += 30
        draw.text((10, y_offset), "Av. Principal #123, Ciudad", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Tel: +123 456 7890", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "RUC: 1234567890", font=font, fill="black")
        y_offset += 30

        # Fecha y ID de factura
        draw.text((10, y_offset), f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), f"ID Factura: {id_factura}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "DETALLE DE LA FACTURA", font=font, fill="black")
        y_offset += 30

        # Títulos de las columnas
        draw.text((10, y_offset), "Producto", font=font, fill="black")
        draw.text((width // 2 - 30, y_offset), "Cant.", font=font, fill="black")
        draw.text((width - 100, y_offset), "Total", font=font, fill="black")
        y_offset += 20

        # Agregar los productos vendidos
        for venta in ventas:
            draw.text((10, y_offset), venta['producto'], font=font, fill="black")
            draw.text((width // 2 - 30, y_offset), str(venta['cantidad']), font=font, fill="black")
            draw.text((width - 100, y_offset), f"${venta['total']:.2f}", font=font, fill="black")
            y_offset += 20

        # Línea divisoria y resumen de totales
        y_offset += 10
        draw.line((10, y_offset, width - 10, y_offset), fill="black", width=1)
        y_offset += 10
        draw.text((10, y_offset), "Subtotal:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${subtotal:.2f}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Impuesto (0%):", font=font, fill="black")
        draw.text((width - 100, y_offset), "$0.00", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "TOTAL A PAGAR:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${total:.2f}", font=font, fill="black")
        y_offset += 30

        # Información del cajero y agradecimiento
        draw.text((10, y_offset), f"Atendido por: {usuario_venta}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Para cualquier reclamo", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "comuníquese con la persona que le atendió.", font=font, fill="black")
        y_offset += 40
        draw.text((width // 2 - 80, y_offset), "¡Gracias por su compra!", font=font, fill="black")

        return factura_img

    # Función para imprimir la imagen en la impresora seleccionada
    


    def exportar_excel(id):
        desired_folder = 'facturas_excel/'  # Carpeta donde guardar los archivos

        # Asegurar que la carpeta existe
        if not os.path.exists(desired_folder):
            os.makedirs(desired_folder)

        excel_file = os.path.join(desired_folder, f"factura_{id}.xlsx")
        abri_excel = (f"factura_{id}.xlsx")
        venta_data = ver_venta(id)  # Obtener los datos de la venta
        if not venta_data:
            
            return

        datos_fac = venta_data[0]  # Primera fila contiene datos generales
        productos = venta_data  # Lista completa con productos

        # Crear un archivo de Excel con OpenPyXL
        wb = Workbook()
        ws = wb.active
        ws.title = "Factura"

        # Definir estilos
        bold_font = Font(bold=True)
        centered_alignment = Alignment(horizontal="center")
        border_style = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin")
        )

        # Encabezado principal
        ws.merge_cells("A1:E1")
        ws["A1"].value = "FACTURA"
        ws["A1"].alignment = centered_alignment
        ws["A1"].font = Font(bold=True, size=16)
        ws["A1"].fill = PatternFill(start_color="2196F3", fill_type="solid")

        # Información del emisor
        ws.append(["Nombre del Negocio S.A.S", None, None, "Cliente:", f"{datos_fac[8]} {datos_fac[9]}"])
        ws.append(["NIT: 123.456.789-0", None, None, "Identificación:", datos_fac[1]])
        ws.append(["Calle Falsa 123, Ciudad, Colombia", None, None, "Dirección:", f"{datos_fac[11]}, {datos_fac[12]}"])
        ws.append(["Tel: +57 300 123 4567", None, None, None, None])
        ws.append([])

        # Información de la factura
        ws.append([f"Número de Factura: {datos_fac[0]}", None, None, "Fecha de Emisión:", datos_fac[10]])
        ws.append(["Tipo de Factura: Electrónica", None, None, None, None])
        ws.append([])

        # Agregar encabezado de la tabla
        ws.append(["No.", "Nombre del Producto/Servicio", "Precio Unitario", "Cantidad", "Total"])
        for cell in ws[8]:  # Fila donde está el encabezado de la tabla
            cell.font = bold_font
            cell.alignment = centered_alignment
            cell.border = border_style

        # Agregar productos al Excel
        for idx, producto in enumerate(productos, start=1):
            nombre_producto = producto[3]
            precio_unitario = producto[5]
            cantidad = producto[4]
            total_producto = precio_unitario * cantidad

            row = [idx, nombre_producto, precio_unitario, cantidad, total_producto]
            ws.append(row)

            # Aplicar estilos a las celdas de productos
            for col, cell in enumerate(ws[ws.max_row], start=1):
                cell.alignment = centered_alignment if col == 1 else Alignment(horizontal="left")
                cell.border = border_style

        # Calcular el subtotal, IVA y total
        subtotal = sum(producto[5] * producto[4] for producto in productos)
        iva =  0.19


        # Resumen de precios
        ws.append([])
        ws.append(["", "", "Subtotal:", None, subtotal])
        ws.append(["", "", "IVA (19%):", None, iva])
        ws.append(["", "", "Total a Pagar:", None, subtotal])

        # Aplicar estilos al resumen de precios
        for row in ws.iter_rows(min_row=ws.max_row - 2, max_row=ws.max_row, min_col=3, max_col=5):
            for cell in row:
                cell.font = bold_font
                cell.border = border_style
                if cell.column == 3:
                    cell.alignment = Alignment(horizontal="right")

        # Ajustar el ancho de las columnas para que todo quede ordenado
        ws.column_dimensions["A"].width = 5  # Número
        ws.column_dimensions["B"].width = 35  # Nombre del Producto/Servicio
        ws.column_dimensions["C"].width = 15  # Precio Unitario
        ws.column_dimensions["D"].width = 10  # Cantidad
        ws.column_dimensions["E"].width = 15  # Total

        # Guardar el archivo
        wb.save(excel_file)

        # Mostrar notificación de éxito
        page.snack_bar = ft.SnackBar(ft.Text("Factura exportada a Excel con éxito"), bgcolor="green")
        page.snack_bar.open = True
        page.update()



    
    def generar_pdf(id):
        desired_folder = 'facturas/'  # Replace with the actual path

        
        if not os.path.exists(desired_folder):
            os.makedirs(desired_folder)

        # Construct the full file path
        factura_pdf = os.path.join(desired_folder, f"factura_{id}.pdf")
        venta_data = ver_venta(id)
        if not venta_data:
            
            return

        datos_fac = venta_data[0]
        productos = venta_data # Los productos están después de la primera tupla


        c = canvas.Canvas(factura_pdf, pagesize=letter)
        width, height = letter

        # Encabezado del PDF
        c.setFillColor("#2196F3")
        c.setFont("Helvetica-Bold", 24)
        c.drawString(30, height - 50, "FACTURA")
        c.setFillColor(colors.black)

        # Información del emisor y cliente
        c.setFont("Helvetica", 12)
        c.drawString(30, height - 100, "Nombre del Negocio S.A.S")
        c.drawString(30, height - 115, "NIT: 123.456.789-0")
        c.drawString(30, height - 130, "Calle Falsa 123, Ciudad, Colombia")
        c.drawString(30, height - 145, "Tel: +57 300 123 4567 - Email: contacto@negocio.com")

        c.drawString(400, height - 100, "Cliente:")
        c.drawString(400, height - 115, f"{datos_fac[8]} {datos_fac[9]}")
        c.drawString(400, height - 130, f"Identificación: {datos_fac[1]}")
        c.drawString(400, height - 145, f"Dirección: {datos_fac[11]}, {datos_fac[12]} ")

        # Información de la factura
        c.drawString(30, height - 170, f"Número de Factura: {datos_fac[0]}")
        c.drawString(30, height - 185, f"Fecha de Emisión: {datos_fac[10]}")
        c.drawString(30, height - 200, "Tipo de Factura: Electrónica")

        # Dibujar tabla de productos
        y_position = height - 240
        c.setFont("Helvetica-Bold", 10)
        c.drawString(30, y_position, "No.")
        c.drawString(60, y_position, "Nombre del Producto/Servicio")
        c.drawString(300, y_position, "Precio Unitario")
        c.drawString(400, y_position, "Cantidad")
        c.drawString(470, y_position, "Total")
        y_position -= 20

        # Dibujar los productos usando el for
        c.setFont("Helvetica", 10)
        subtotal = 0  # Para acumular el subtotal
        for idx, producto in enumerate(productos, start=1):  # Ajustar para iterar sobre la lista de productos
            nombre_producto = producto[3]
            precio_unitario = producto[5]
            cantidad = producto[4]
            total_producto = precio_unitario * cantidad

            # Asignar los valores al PDF
            c.drawString(30, y_position, str(idx))  # Número del producto
            c.drawString(60, y_position, nombre_producto)  # Nombre del producto
            c.drawString(300, y_position, f"{precio_unitario:.2f}")  # Precio unitario
            c.drawString(400, y_position, str(cantidad))  # Cantidad
            c.drawString(470, y_position, f"{total_producto:.2f}")  # Total
            y_position -= 20
            # Sumar al subtotal
            subtotal += total_producto

        # Calcular IVA y total
        iva = subtotal * Decimal('0.19')
        total_a_pagar = subtotal + iva

        # Resumen de precios
        c.setFont("Helvetica-Bold", 12)
        c.drawString(400, y_position - 40, f"Subtotal: {subtotal:.2f}")
        c.drawString(400, y_position - 55, f"IVA (19%): {iva:.2f}")
        c.drawString(400, y_position - 70, f"Total a Pagar: {total_a_pagar:.2f}")

        c.save()
        page.snack_bar = ft.SnackBar(ft.Text("Factura generada con éxito"), bgcolor="green")
        page.snack_bar.open = True
        page.update()


    
    def generar_pdf_cotizacion(id):
        desired_folder = 'cotizaciones/'  # Cambiar según sea necesario

        # Crear carpeta si no existe
        if not os.path.exists(desired_folder):
            os.makedirs(desired_folder)

        factura_pdf = os.path.join(desired_folder, f"cotizacion_{id}.pdf")
        datos_fac = detalle_cotizacion(id)

        if not datos_fac:
            
            return

        # Extraer datos del cliente (primer registro)
        datos_cliente = datos_fac[0]

        c = canvas.Canvas(factura_pdf, pagesize=letter)
        width, height = letter

        # Encabezado del PDF
        c.setFillColor(colors.HexColor("#2196F3"))
        c.setFont("Helvetica-Bold", 24)
        c.drawString(30, height - 50, "COTIZACIÓN")
        c.setFillColor(colors.black)

        # Información del emisor y cliente
        c.setFont("Helvetica", 12)
        c.drawString(30, height - 100, "Nombre del Negocio S.A.S")
        c.drawString(30, height - 115, "NIT: 123.456.789-0")
        c.drawString(30, height - 130, "Calle Falsa 123, Ciudad, Colombia")
        c.drawString(30, height - 145, "Tel: +57 300 123 4567 - Email: contacto@negocio.com")

        c.drawString(400, height - 100, "Cliente:")
        c.drawString(400, height - 115, f"{datos_cliente[7]} {datos_cliente[8]}")
        c.drawString(400, height - 130, f"Identificación: {datos_cliente[9]}")
        c.drawString(400, height - 145, f"Dirección: {datos_cliente[10]}, {datos_cliente[11]}")

        # Información de la cotización
        c.drawString(30, height - 170, f"Número de Cotización: {datos_cliente[0]}")
        c.drawString(30, height - 185, f"Fecha de Emisión: {datos_cliente[5]}")

        # Tabla de productos
        y_position = height - 240
        c.setFont("Helvetica-Bold", 10)
        c.drawString(30, y_position, "No.")
        c.drawString(60, y_position, "Nombre del Producto/Servicio")
        c.drawString(300, y_position, "Precio Unitario")
        c.drawString(400, y_position, "Cantidad")
        c.drawString(470, y_position, "Total")
        y_position -= 20

        # Dibujar los productos
        c.setFont("Helvetica", 10)
        subtotal = Decimal('0.0')

        for idx, producto in enumerate(datos_fac, start=1):
            nombre_producto = producto[1]
            cantidad = int(producto[2])
            precio_unitario = Decimal(producto[3])
            total_producto = precio_unitario * cantidad

            # Añadir al PDF
            c.drawString(30, y_position, str(idx))
            c.drawString(60, y_position, nombre_producto)
            c.drawString(300, y_position, f"{precio_unitario:.2f}")
            c.drawString(400, y_position, str(cantidad))
            c.drawString(470, y_position, f"{total_producto:.2f}")

            y_position -= 20
            subtotal += total_producto

            # Crear nueva página si es necesario
            if y_position < 50:
                c.showPage()
                y_position = height - 50

        # Calcular IVA y total
        iva = subtotal * Decimal('0.19')
        total_a_pagar = subtotal + iva

        # Resumen de precios
        c.setFont("Helvetica-Bold", 12)
        c.drawString(400, y_position - 40, f"Subtotal: {subtotal:.2f}")
        c.drawString(400, y_position - 55, f"IVA (19%): {iva:.2f}")
        c.drawString(400, y_position - 70, f"Total a Pagar: {total_a_pagar:.2f}")

        c.save()
        page.snack_bar = ft.SnackBar(ft.Text("Factura generada con éxito"), bgcolor="green")
        page.snack_bar.open = True
        page.update()

    def mostrar_modal_imprimir_cotizacion(id_cotizacion):
        # Obtener los detalles de la cotización
        cotizacion_detalle = detalle_cotizacion(id_cotizacion)
        if not cotizacion_detalle:
            
            return

        # Procesar los datos de la cotización
        cotizaciones = []
        subtotal = Decimal('0.0')
        for item in cotizacion_detalle:
            cotizaciones.append({
                'producto': item[1],  # nombre_producto
                'cantidad': int(item[2]),  # cantidad
                'total': Decimal(item[3]) * int(item[2])  # precio_unitario * cantidad
            })
            subtotal += cotizaciones[-1]['total']

        total = subtotal  # Puedes agregar impuestos si es necesario

        # Generar la imagen de la cotización
        cotizacion_img = generar_cotizacion_imagen(cotizaciones, subtotal, total, id_cotizacion)

        # Convertir la imagen a base64 para mostrarla en Flet
        factura_buffer = io.BytesIO()
        cotizacion_img.save(factura_buffer, format='PNG')
        factura_data = factura_buffer.getvalue()

        # Mostrar la imagen en el modal
        cotizacion_flet_image = ft.Image(
            src_base64=base64.b64encode(factura_data).decode('utf-8'),
            width=500,  # Aumenta el tamaño para mejor visualización
            height=700,
            fit=ft.ImageFit.CONTAIN
        )

        # Obtener la lista de impresoras disponibles
        printers = [printer[2] for printer in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]

        # Crear controles para las opciones de impresión
        printer_dropdown = ft.Dropdown(
            label="Seleccione una impresora",
            options=[ft.dropdown.Option(printer) for printer in printers],
            value=win32print.GetDefaultPrinter()  # Establecer impresora predeterminada
        )

        copies_field = ft.TextField(
            label="Número de copias",
            value=1,
            width=100,
            keyboard_type=ft.KeyboardType.NUMBER
        )

        color_mode_dropdown = ft.Dropdown(
            label="Modo de color",
            options=[
                ft.dropdown.Option("Color"),
                ft.dropdown.Option("Blanco y Negro")
            ],
            value="Blanco y Negro"
        )

        # Función para imprimir la imagen con las opciones seleccionadas
        def imprimir_cotizacion(e):
            printer_name = printer_dropdown.value
            try:
                num_copies = int(copies_field.value)
                if num_copies <= 0:
                    raise ValueError
            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Ingrese un número válido de copias"), bgcolor="red")
                page.snack_bar.open = True
                page.update()
                return
            color_mode = color_mode_dropdown.value == "Color"  # True si es color, False si es blanco y negro
            imprimir_imagen(cotizacion_img, printer_name, num_copies, color_mode)
            page.snack_bar = ft.SnackBar(ft.Text("Imprimiendo..."), bgcolor="green")
            page.snack_bar.open = True
            cerrar_modal()
            page.update()

        # Crear un contenedor para las opciones de impresión
        opciones_impresion = ft.Column(
            [
                printer_dropdown,
                copies_field,
                color_mode_dropdown,
                ft.Row(
                    [
                        ft.ElevatedButton("Imprimir", on_click=imprimir_cotizacion, bgcolor=ft.colors.BLUE, color="white"),
                        ft.ElevatedButton("Cancelar", on_click=lambda e: cerrar_modal(), bgcolor=ft.colors.RED, color="white"),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10
                ),
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
            width=350  # Ajusta el ancho según necesites
        )

        # Contenedor principal que contiene la imagen y las opciones a la derecha
        contenido_dialogo = ft.Row(
            [
                cotizacion_flet_image,
                opciones_impresion
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=20
        )

        modal = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Cotización ID: {id_cotizacion}", size=18, weight="bold"),
            content=contenido_dialogo,
        )

        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal():
            modal.open = False
            page.update()


    # Función para generar la imagen de la cotización
    def generar_cotizacion_imagen(cotizaciones, subtotal, total, id_cotizacion):
        usuario_cotizacion = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"

        # Configuración del tamaño de la etiqueta y el DPI
        label_width = 3.0  # Ancho en pulgadas (según tu impresora)
        label_height = 11  # Alto en pulgadas (según tu impresora)
        dpi = 203  # DPI típico de impresoras de tickets

        # Calcular las dimensiones en píxeles
        width = int(label_width * dpi)
        height = int(label_height * dpi)

        # Crear una imagen en blanco para la cotización
        cotizacion_img = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(cotizacion_img)

        # Configuración de fuente
        font_path = "arial.ttf"  # Cambia a la ruta de una fuente TTF válida en tu sistema
        font_size = 20  # Ajusta el tamaño de la fuente para mayor legibilidad
        try:
            font = ImageFont.truetype(font_path, font_size)
        except IOError:
            font = ImageFont.load_default()

        # Información del negocio
        y_offset = 10  # Espaciado vertical inicial
        draw.text((width // 2 - 80, y_offset), "Negocio XYZ", font=font, fill="black")
        y_offset += 30
        draw.text((10, y_offset), "Av. Principal #123, Ciudad", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Tel: +123 456 7890", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "RUC: 1234567890", font=font, fill="black")
        y_offset += 30

        # Fecha e ID de cotización
        draw.text((10, y_offset), f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), f"ID Cotización: {id_cotizacion}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "DETALLE DE LA COTIZACIÓN", font=font, fill="black")
        y_offset += 30

        # Títulos de las columnas
        draw.text((10, y_offset), "Producto", font=font, fill="black")
        draw.text((width // 2 - 30, y_offset), "Cant.", font=font, fill="black")
        draw.text((width - 100, y_offset), "Total", font=font, fill="black")
        y_offset += 20

        # Agregar los productos de la cotización
        for cotizacion in cotizaciones:
            draw.text((10, y_offset), cotizacion['producto'], font=font, fill="black")
            draw.text((width // 2 - 30, y_offset), str(cotizacion['cantidad']), font=font, fill="black")
            draw.text((width - 100, y_offset), f"${cotizacion['total']:.2f}", font=font, fill="black")
            y_offset += 20

        # Resumen de totales
        y_offset += 10
        draw.line((10, y_offset, width - 10, y_offset), fill="black", width=1)
        y_offset += 10
        draw.text((10, y_offset), "Subtotal:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${subtotal:.2f}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "TOTAL:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${total:.2f}", font=font, fill="black")
        y_offset += 30

        # Información del usuario
        draw.text((10, y_offset), f"Atendido por: {usuario_cotizacion}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Gracias por confiar en nosotros.", font=font, fill="black")

        return cotizacion_img



        
    

    
    def devolucion_venta(id):
        # Consulta real de productos asociados a la venta
        productos = ver_venta(id)  # Implementa esta función para obtener los datos desde la base de datos
        checkboxes = []
        cantidades_seleccionadas = {}

        # Confirmar devolución
        def confirmar_devolucion(e):
            nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
            # Filtrar productos seleccionados
            seleccionados = [
                {
                    "num_factura": p[0],  # Número de factura
                    "cliente": p[1],  # Cliente
                    "total": p[2],  # Total de la venta
                    "nombre_pro": p[3],  # Nombre del producto
                    "cantidad_pro": p[4],  # Cantidad seleccionada
                    "precio_uni": p[5],  # Precio unitario
                    "subtotal": p[6],  # Subtotal
                    "producto_venta": p[7],
                }
                for p, checkbox in zip(productos, checkboxes) if checkbox.value
            ]

            
            motivo = motivo_devolucion.value.strip()

            if seleccionados:
                # Solicitar cantidad para los productos seleccionados que tienen más de una unidad disponible
                solicitar_cantidad(seleccionados, motivo, nombre_registrador)
            else:
                page.snack_bar = ft.SnackBar(ft.Text("Seleccione al menos un producto"), bgcolor="red")
                page.update()

        # Solicitar la cantidad a devolver
        def solicitar_cantidad(productos_pendientes, motivo, nombre_registrador):
            if not productos_pendientes:
                # No hay productos pendientes de confirmar la cantidad
                procesar_devolucion(list(cantidades_seleccionadas.values()), motivo, nombre_registrador)
                return

            producto = productos_pendientes.pop(0)

            def confirmar_cantidad(e):
                cantidad = int(cantidad_input.value.strip())
                if cantidad < 1 or cantidad > producto["cantidad_pro"]:
                    page.snack_bar = ft.SnackBar(ft.Text("Cantidad inválida"), bgcolor="red")
                    page.update()
                else:
                    producto["cantidad_pro"] = cantidad
                    producto["subtotal"] = cantidad * producto["precio_uni"]
                    cantidades_seleccionadas[producto["producto_venta"]] = producto
                    modal_cantidad.open = False
                    page.update()
                    solicitar_cantidad(productos_pendientes, motivo, nombre_registrador)

            cantidad_input = ft.TextField(
                label=f"Seleccione la cantidad a devolver para '{producto['nombre_pro']}' (Máximo {producto['cantidad_pro']})",
                value=str(producto["cantidad_pro"]),
                width=400,
            )

            modal_cantidad = ft.AlertDialog(
                modal=True,
                title=ft.Text("Cantidad a devolver", size=18, weight="bold"),
                content=ft.Container(
                    content=ft.Column(
                        [
                            cantidad_input,
                        ],
                        scroll="auto",
                    ),
                ),
                actions=[
                    ft.TextButton("Cancelar", on_click=lambda e: cerrar_modal_cantidad()),
                    ft.TextButton("Confirmar", on_click=confirmar_cantidad),
                ],
            )

            page.dialog = modal_cantidad
            modal_cantidad.open = True
            page.update()

            def cerrar_modal_cantidad():
                modal_cantidad.open = False
                page.update()

        # Procesar devolución general y detalles
        def procesar_devolucion(seleccionados, motivo, nombre_registrador):
            try:
                # Procesar devolución general
                total_devolucion = sum(item["subtotal"] for item in seleccionados)
                id_factura = seleccionados[0]["num_factura"]  # Todas las líneas tienen la misma factura

                registro_exitoso = registro_devolucion(
                    id_factura,
                    total_devolucion,
                    nombre_registrador,  # Usuario que realiza la devolución
                    motivo
                )

                if not registro_exitoso:
                    page.snack_bar = ft.SnackBar(ft.Text("Error al registrar devolución general"), bgcolor="red")
                    page.update()
                    return

                # Procesar detalles de devolución
                for item in seleccionados:
                    detalle_exitoso = registro_detalle_devolucion(
                        item["num_factura"],
                        item["producto_venta"],
                        item["cantidad_pro"],
                        item["precio_uni"],
                        item["subtotal"]
                    )

                    if not detalle_exitoso:
                        page.snack_bar = ft.SnackBar(ft.Text(f"Error al registrar detalle: {item['nombre_pro']}"), bgcolor="red")
                        page.update()
                        return

                # Mostrar mensaje de éxito
                page.snack_bar = ft.SnackBar(ft.Text("Devolución registrada con éxito"), bgcolor="green")
                page.update()
            except Exception as ex:
                
                page.snack_bar = ft.SnackBar(ft.Text("Ocurrió un error inesperado"), bgcolor="red")
                page.update()

            # Cerrar modal y actualizar la página
            modal.open = False
            page.update()

        # Seleccionar todos los productos
        def seleccionar_todos(e):
            for checkbox in checkboxes:
                checkbox.value = e.control.value
            modal.update()

        motivo_devolucion = ft.TextField(
            label="Motivo de la devolución (opcional)",
            multiline=True,
            max_lines=3,
            width=550,
        )

        # Crear filas de la tabla de productos con checkboxes
        rows = []
        for p in productos:
            checkbox = ft.Checkbox(value=False)
            checkboxes.append(checkbox)
            row = ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(str(p[0]))),  # factura
                    ft.DataCell(ft.Text(p[3])),  # Nombre del producto
                    ft.DataCell(ft.Text(str(p[4]))),  # Cantidad
                    ft.DataCell(ft.Text(f"${p[6]:.2f}")),  # Subtotal
                    ft.DataCell(checkbox),  # Checkbox
                ]
            )
            rows.append(row)

        # Tabla de productos
        tabla_productos = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Num Factura")),
                ft.DataColumn(ft.Text("Producto")),
                ft.DataColumn(ft.Text("Cantidad")),
                ft.DataColumn(ft.Text("Total")),
                ft.DataColumn(ft.Text("Seleccionar")),
            ],
            rows=rows,
        )

        # Crear el modal
        modal = ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Devolución de Venta, Factura: {id}", size=18, weight="bold"),
            content=ft.Container(
                content=ft.Column(
                    [
                        ft.Row(
                            [
                                ft.Checkbox(
                                    label="Seleccionar Todos",
                                    on_change=seleccionar_todos,
                                ),
                            ],
                            alignment="start",
                        ),
                        ft.Divider(),
                        ft.Container(
                            content=tabla_productos,
                            height=300,  # Altura para mantener un tamaño cómodo
                            width=550,
                            border=ft.border.all(1, ft.colors.BLUE_GREY_200),
                            border_radius=5,
                        ),
                        ft.Divider(),
                        motivo_devolucion,
                    ],
                    scroll="auto",
                ),
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: cerrar_modal_detalle()),
                ft.TextButton("Confirmar", on_click=confirmar_devolucion),
            ],
        )

        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal_detalle():
            modal.open = False
            page.update()

    def ver_detalle_devolucion(id):
        datos = ver_devolucion(id)

        # Verifica si se encontraron datos
        if not datos:
            ft.Text("No se encontraron detalles para el ID proporcionado.")

        # Calcula el total de los subtotales
        total = sum(float(detalle['subtotal']) for detalle in datos)

        # Crea las filas para la tabla
        filas = [
            ft.Row([
                ft.Text(f"{detalle['factura_venta']}", width=80),
                ft.Text(f"{detalle['nombre_producto']}", width=80),
                ft.Text(f"{detalle['cantidad']}", width=80),
                ft.Text(f"{detalle['precio_unitario']:,.2f}", width=80),
                ft.Text(f"{detalle['subtotal']:,.2f}", width=140),
                ft.Text(detalle['fecha_devolucion'], width=140),
            ]) for detalle in datos
        ]

        # Modal
        modal = ft.AlertDialog(
            modal=True,
            content=ft.Container(
                content=ft.Column(
                    controls=[
                        # Encabezado del modal
                        ft.Row(
                            controls=[
                                ft.Text("Detalle de Devolución", size=20, weight=ft.FontWeight.BOLD),
                                ft.IconButton(
                                    icon=ft.icons.CLOSE,
                                    on_click=lambda e: cerrar_modal_detalle(),
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        ),
                        ft.Divider(),
                        # Encabezados de la tabla
                        ft.Row(
                            controls=[
                                ft.Text("ID Factura", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Producto", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Cantidad", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Precio Unitario", width=90, weight=ft.FontWeight.BOLD),
                                ft.Text("Total", width=140, weight=ft.FontWeight.BOLD),
                                ft.Text("Fecha de Devolución", width=140, weight=ft.FontWeight.BOLD),
                            ],
                            alignment=ft.MainAxisAlignment.START,
                        ),
                        ft.Divider(),
                        # Contenedor desplazable solo para las filas
                        ft.Container(
                            content=ft.Column(
                                controls=filas,  # filas dinámicas
                                spacing=5,
                                scroll=ft.ScrollMode.AUTO,  # Habilito scroll 
                            ),
                            height=300,  # Ajusto el alto 
                        ),
                        ft.Divider(),
                        # Mostrar el total de los subtotales
                        ft.Row(
                            controls=[
                                ft.Text("Total General:", size=16, weight=ft.FontWeight.BOLD),
                                ft.Text(f"${total:,.2f}", size=16, weight=ft.FontWeight.BOLD),
                            ],
                            alignment=ft.MainAxisAlignment.END,
                        ),
                    ],
                ),
                height=490,
                width=600,
            ),
        )
        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal_detalle():
            modal.open = False
            page.update()


    def imprimir_imagen(imagen, printer_name, num_copies, color_mode):
        try:
            # Abre la impresora y obtiene el DEVMODE
            hPrinter = win32print.OpenPrinter(printer_name)
            devmode = win32print.GetPrinter(hPrinter, 2)["pDevMode"]

            # Configura el número de copias
            devmode.Copies = num_copies

            # Configura el modo de color
            devmode.Color = 1 if color_mode else 2  # 1 = Color, 2 = Blanco y Negro

            # Crea un contexto de dispositivo con el DEVMODE modificado
            hDC = win32ui.CreateDC()
            hDC.CreatePrinterDC(printer_name)
            hDC.SetMapMode(win32con.MM_TEXT)

            # Obtiene el área imprimible y el tamaño físico
            printable_area = hDC.GetDeviceCaps(win32con.HORZRES), hDC.GetDeviceCaps(win32con.VERTRES)
            printer_size = hDC.GetDeviceCaps(win32con.PHYSICALWIDTH), hDC.GetDeviceCaps(win32con.PHYSICALHEIGHT)
            printer_margins = hDC.GetDeviceCaps(win32con.PHYSICALOFFSETX), hDC.GetDeviceCaps(win32con.PHYSICALOFFSETY)

            # Obtiene las dimensiones de la imagen
            img_width, img_height = imagen.size

            # Escala la imagen para ajustarla al área imprimible
            ratios = [1.0 * printable_area[0] / img_width, 1.0 * printable_area[1] / img_height]
            scale = min(ratios)
            scaled_width, scaled_height = [int(scale * img_width), int(scale * img_height)]

            # Calcula la posición centrada de la imagen
            x1 = int((printer_size[0] - scaled_width) / 2)
            y1 = int((printer_size[1] - scaled_height) / 2)
            x2 = x1 + scaled_width
            y2 = y1 + scaled_height

            # Inicia el documento de impresión
            hDC.StartDoc("Prueba de Impresión")
            hDC.StartPage()

            # Crea un DIB de la imagen y la dibuja
            dib = ImageWin.Dib(imagen)
            dib.draw(hDC.GetHandleOutput(), (x1, y1, x2, y2))

            # Finaliza el documento de impresión
            hDC.EndPage()
            hDC.EndDoc()
            hDC.DeleteDC()

            # Cierra la impresora
            win32print.ClosePrinter(hPrinter)
            
        except Exception as e:
            return
        



    return ft.Column(
        [
            ft.Container(
                content=ft.Row(
                    [
                        ft.TextField(
                            hint_text="Buscar...",
                            border_radius=10,
                            width=350,
                            height=40,
                            prefix_icon=ft.icons.SEARCH,
                            on_change=buscar_producto_evento, # visible=False  
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10,
                ),
                padding=ft.Padding(10, 10, 10, 10),
            ),
            ft.Row(
                [
                    btn_ventas,
                    btn_cotizaciones,
                    btn_devoluciones,
                ],
                alignment=ft.MainAxisAlignment.START,
                spacing=5,
            ),
            main_container,  # Agregamos el contenedor principal que mostrará la tabla
        ],
        expand=True,
    )
