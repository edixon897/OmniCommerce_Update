import flet as ft

def categoria_view():
    return ft.Container(
        content=ft.Text("categoria", style=ft.TextThemeStyle.HEADLINE_LARGE),
        padding=20
    )
