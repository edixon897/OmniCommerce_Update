import flet as ft
from flet.plotly_chart import PlotlyChart
import plotly.graph_objects as go
import random
from datetime import datetime

def main(page: ft.Page):
    page.title = "Dashboard de Ventas e Inventario"
    page.bgcolor = "#1E1E2E"
    page.padding = 16
    page.scroll = ft.ScrollMode.AUTO

    # Datos simulados
    def generate_weekly_sales():
        return [random.randint(500, 1500) for _ in range(7)]

    def generate_monthly_sales(years):
        data = {}
        for year in years:
            data[year] = [random.randint(10000, 30000) for _ in range(12)]
        return data

    def get_top_customer():
        customers = [
            {"name": "Liam Alexander", "purchases": random.randint(20, 50)},
            {"name": "Daniel Stewart", "purchases": random.randint(15, 45)},
            {"name": "Eleanor Fire", "purchases": random.randint(10, 40)},
        ]
        return max(customers, key=lambda x: x["purchases"])

    def get_monthly_total_sales():
        return random.randint(100000, 300000)

    def get_notifications():
        return [
            {"message": "Nuevo producto añadido", "read": False},
            {"message": "Pedido #1234 realizado", "read": True},
            {"message": "Stock de producto X bajo", "read": False},
            {"message": "Cliente Y realizó una compra", "read": False},
        ]

    # Tarjeta de estadísticas semanales
    def weekly_sales_card():
        sales = generate_weekly_sales()
        days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

        fig = go.Figure(
            data=[
                go.Bar(
                    x=days,
                    y=sales,
                    marker_color='lightskyblue',
                    hoverinfo="x+y",
                )
            ]
        )
        fig.update_layout(
            title="Ventas Semanales",
            template="plotly_dark",
            paper_bgcolor="#262635",
            plot_bgcolor="#262635",
            margin=dict(l=0, r=0, t=0, b=0),
            xaxis=dict(
                color="white",
                tickfont=dict(size=16),
            ),
            yaxis=dict(
                color="white",
                tickfont=dict(size=16),
            ),
        )

        return ft.Container(
            bgcolor="#262635",
            border_radius=ft.border_radius.all(12),
            padding=ft.Padding(16, 16, 16, 16),
            content=ft.Column(
                [
                    ft.Container(
                        content=ft.Text("Ventas Semanales", size=20, color="white70"),
                        padding=ft.Padding(0, 0, 0, 0),
                    ),
                    ft.Container(
                        content=PlotlyChart(fig, expand=True),
                        expand=True,
                    ),
                ],
                spacing=8,
                expand=True,
            ),
            expand=True,
        )

    # Gráfica de comparación mensual entre años
    def monthly_comparison_chart():
        years = [2021, 2022, 2023]
        sales_data = generate_monthly_sales(years)
        months = [
            "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
        ]

        fig = go.Figure()
        for year in years:
            fig.add_trace(
                go.Scatter(
                    x=months,
                    y=sales_data[year],
                    mode="lines+markers",
                    name=str(year),
                    hoverinfo="x+y",
                )
            )
        fig.update_layout(
            title="Comparación de Ventas Mensuales por Año",
            template="plotly_dark",
            paper_bgcolor="#262635",
            plot_bgcolor="#262635",
            margin=dict(l=0, r=0, t=0, b=0),
            xaxis=dict(
                color="white",
                tickfont=dict(size=14),
                tickangle=45,
            ),
            yaxis=dict(
                color="white",
                tickfont=dict(size=14),
            ),
        )

        return ft.Container(
            bgcolor="#262635",
            border_radius=ft.border_radius.all(12),
            padding=ft.Padding(16, 16, 16, 16),
            content=ft.Column(
                [
                    ft.Container(
                        content=ft.Text("Comparación de Ventas Mensuales por Año", size=20, color="white70"),
                        padding=ft.Padding(0, 0, 0, 0),
                    ),
                    ft.Container(
                        content=PlotlyChart(fig, expand=True),
                        expand=True,
                    ),
                ],
                spacing=8,
                expand=True,
            ),
            expand=True,
        )

    # Tarjeta de cliente top
    def top_customer_card():
        top_customer = get_top_customer()

        return ft.Container(
            bgcolor="#262635",
            border_radius=ft.border_radius.all(12),
            padding=ft.Padding(16, 16, 16, 16),
            width=350,
            content=ft.Column(
                [
                    ft.Text("Cliente con más compras", size=20, color="white70"),
                    ft.Divider(color="white10"),
                    ft.Text(top_customer["name"], size=24, color="white", weight=ft.FontWeight.BOLD),
                    ft.Text(f"Compras: {top_customer['purchases']}", size=20, color="white70"),
                ],
                spacing=8,
            ),
        )

    # Tarjeta de ventas totales del mes
    def monthly_total_sales_card():
        total_sales = get_monthly_total_sales()
        current_month = datetime.now().strftime("%B %Y")

        return ft.Container(
            bgcolor="#262635",
            border_radius=ft.border_radius.all(12),
            padding=ft.Padding(16, 16, 16, 16),
            width=350,
            content=ft.Column(
                [
                    ft.Text(f"Ventas Totales - {current_month}", size=20, color="white70"),
                    ft.Divider(color="white10"),
                    ft.Text(f"${total_sales:,}", size=24, color="green", weight=ft.FontWeight.BOLD),
                ],
                spacing=8,
            ),
        )

    # Sección de notificaciones
    def notifications_section():
        notifications = get_notifications()

        notification_list = ft.ListView(expand=True, spacing=8)

        def toggle_read_status(e):
            idx = e.control.data
            notifications[idx]["read"] = not notifications[idx]["read"]
            update_notifications()

        def update_notifications():
            notification_list.controls.clear()
            for idx, n in enumerate(notifications):
                notification_list.controls.append(
                    ft.Row(
                        controls=[
                            ft.Text(n["message"], size=16, color="white"),
                            ft.ElevatedButton(
                                "Leída" if n["read"] else "No leída",
                                bgcolor="green" if n["read"] else "red",
                                color="white",
                                on_click=toggle_read_status,
                                data=idx,
                                height=30,
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=8),
                                    padding=ft.Padding(8, 0, 8, 0),
                                ),
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    )
                )
            # No es necesario llamar a notification_list.update() aquí

        # Crear el contenedor y agregar notification_list antes de llamar a update_notifications()
        notifications_container = ft.Container(
            bgcolor="#262635",
            border_radius=ft.border_radius.all(12),
            padding=ft.Padding(16, 16, 16, 16),
            width=350,
            content=ft.Column(
                [
                    ft.Text("Notificaciones", size=20, color="white70"),
                    ft.Divider(color="white10"),
                    ft.Container(
                        content=notification_list,
                        height=400,
                    ),
                ],
                spacing=8,
            ),
        )

        # Ahora que notification_list está agregado al contenedor, podemos actualizarlo
        update_notifications()

        return notifications_container

    # Layout principal
    page.add(
        ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        weekly_sales_card(),
                    ],
                    spacing=16,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                ft.Row(
                    controls=[
                        monthly_comparison_chart(),
                    ],
                    spacing=16,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                ft.Row(
                    controls=[
                        top_customer_card(),
                        monthly_total_sales_card(),
                        notifications_section(),
                    ],
                    spacing=16,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            spacing=16,
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

ft.app(target=main)
