import flet as ft
from routes.productos import consulta_producto, consulta_producto_promocion, buscar_producto, buscar_producto_promocion, informacion_producto, actualizar_producto, eliminar_producto, actualizar_cantidad_producto
from utils.proveedorAgg import mostrar_modal
from routes.ubicacion_p import consulta_ubicacion
#from utils.productosAgg import mostrar_modal_producto_agg
from utils.categoriaAgg import show_create_category_modal
#from utils.producto_sele import mostrar_modal_producto
from models.productos import registro_de_productos
from routes.proveedor import consulta_proveedor
from routes.categoria import consulta_categoria
from routes.productos import producto_promocion
from barcode import EAN13
from barcode.writer import ImageWriter
import os
from rembg import remove
from datetime import datetime






DESTINATION_FOLDER = "assets/image" 
DESTINATION_FOLDER_CODIGO_BARRAS = "assets/img"

# Asegúrate de que la carpeta de destino existe
os.makedirs(DESTINATION_FOLDER, exist_ok=True)




def inventario_view(page):
    
    

   # Contenedor tipo grid para productos
    contenido_inventario = ft.GridView(
        expand=True,
        runs_count=3,  # Número mínimo de columnas
        max_extent=270,  # Máximo ancho de cada tarjeta
        child_aspect_ratio=1,  # Proporción entre el ancho y alto de las tarjetas
        spacing=10,
    )

    def obtener_borde_producto(producto):
        if int(producto[7]) <= int(producto[6]):  # Stock mínimo
            return ft.border.all(2, ft.colors.PRIMARY)
        return None

    def obtener_color_cantidad(producto):
        return ft.colors.GREEN if int(producto[6]) >= int(producto[7]) else ft.colors.RED

    def actualizar_vista_inventario(tipo_vista, termino_busqueda=None):
        productos = consulta_producto()
        contenido_inventario.controls.clear()

        if tipo_vista == "productos":
            if termino_busqueda:
                productos_filtrados = buscar_producto(nombre_producto=termino_busqueda)
            else:
                productos_filtrados = productos

            for producto in productos_filtrados:
                card_producto = ft.Container(
                    content=ft.Column(
                        [
                            # Botón de tres puntos (menú) en la parte superior derecha, sin interferir con la imagen
                            ft.Row(
                                [
                                    ft.Container(),  # Espacio vacío para alinear los puntos al lado derecho
                                    ft.IconButton(
                                        icon=ft.icons.MORE_VERT,
                                        on_click=lambda e, prod=producto[0]: mostrar_modal_producto(page, prod),
                                        tooltip="Ver Opciones",
                                        icon_size=18,  # Tamaño reducido del icono
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            ),
                            # Imagen del producto centrada con tamaño fijo, sin afectar otros elementos
                            ft.Container(
                                content=ft.Image(
                                    src=f"assets/image/{producto[3]}",
                                    width=100,
                                    height=100,  # Mantener un tamaño constante
                                    fit=ft.ImageFit.CONTAIN,  # Asegurar que se contenga dentro del espacio dado
                                ),
                                alignment=ft.alignment.center,
                            ),
                            # Información del producto
                            ft.Text(
                                producto[2],  # Nombre del producto
                                weight=ft.FontWeight.BOLD,
                                size=14,
                                text_align="center",
                            ),
                            ft.Text(
                                f"{producto[8]}$",
                                color=ft.colors.BLUE,
                                size=12,
                                text_align="center",
                            ),
                            # Cantidad del producto y botón para aumentar la cantidad
                            ft.Row(
                                [
                                    ft.Text(
                                        f"Cantidad: {producto[6]}",
                                        color=obtener_color_cantidad(producto),
                                        size=16,
                                    ),
                                    ft.Container(
                                        content=ft.IconButton(
                                            icon=ft.icons.ADD,
                                            icon_size=35,
                                            on_click=lambda e, prod=producto:  mostrar_modal_agregar_cantidad(page, prod),
                                            tooltip="Agregar cantidad",
                                            alignment=ft.alignment.center,
                                        ),
                                        bgcolor=ft.colors.BLUE,
                                        border_radius=8,
                                        padding=-13,  # Relleno ajustado
                                        alignment=ft.alignment.center,  # Centrar el botón dentro del contenedor azul
                                        width=35,  # Ajustar el ancho del contenedor para que se ajuste al botón
                                        height=35,  # Ajustar la altura del contenedor
                                        
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            ),
                        ],
                        spacing=1,
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    padding=10,
                    border_radius=15,
                    bgcolor=ft.colors.WHITE,
                    border=obtener_borde_producto(producto),
                    shadow=ft.BoxShadow(
                        offset=ft.Offset(0, 5),
                        blur_radius=10,
                        color=ft.colors.with_opacity(0.2, ft.colors.GREY),
                    ),
                    # Asegurarse de que el contenedor se ajuste correctamente
                    width=300,  # Limitar el ancho del contenedor
                    height=350,  # Ajuste proporcional
                )
                contenido_inventario.controls.append(card_producto)
            page.update()

        elif tipo_vista == "promociones":
            promociones = consulta_producto_promocion()
            contenido_inventario.controls.clear()
            if termino_busqueda:
                promociones_filtradas = buscar_producto_promocion(nombre_producto=termino_busqueda)
            else:
                promociones_filtradas = promociones

            for producto in promociones_filtradas:
                card_producto_promocion = ft.Container(
                    content=ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.Container(),
                                    ft.IconButton(
                                        icon=ft.icons.MORE_VERT,
                                        on_click=lambda e, prod=producto: mostrar_modal_producto(page, prod),
                                        tooltip="Ver Opciones",
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            ),
                            ft.Container(
                                content=ft.Image(
                                    src=f"assets/image/{producto[3]}",
                                    width=150,
                                    height=100,
                                    fit=ft.ImageFit.CONTAIN,
                                ),
                                alignment=ft.alignment.center,
                            ),
                            ft.Text(
                                producto[2],
                                weight=ft.FontWeight.BOLD,
                                size=14,
                                text_align="center",
                            ),
                            ft.Row(
                                [
                                    ft.Text(
                                        f"{producto[8]}$",  # Precio anterior
                                        color=ft.colors.RED,
                                        size=12,
                                        style=ft.TextStyle(
                                            decoration=ft.TextDecoration.LINE_THROUGH
                                        ),
                                    ),
                                    ft.Text(
                                        f"  {producto[15]}$",  # Nuevo precio
                                        color=ft.colors.GREEN,
                                        size=12,
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            ),
                            ft.Row(
                                [
                                    ft.Text(
                                        f"Cantidad: {producto[6]}",
                                        color=obtener_color_cantidad(producto),
                                        size=16,
                                    ),
                                    ft.Container(
                                        content=ft.IconButton(
                                            icon=ft.icons.ADD,
                                            icon_size=20,
                                            on_click=lambda e, prod=producto:  mostrar_modal_agregar_cantidad(page, prod),
                                            tooltip="Agregar cantidad",
                                        ),
                                        bgcolor=ft.colors.BLUE,
                                        border_radius=8,
                                        padding=3,
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            ),
                        ],
                        spacing=5,
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    padding=10,
                    border_radius=15,
                    bgcolor=ft.colors.WHITE,
                    border=ft.border.all(2, ft.colors.GREEN),
                    shadow=ft.BoxShadow(
                        offset=ft.Offset(0, 5),
                        blur_radius=10,
                        color=ft.colors.with_opacity(0.2, ft.colors.GREY),
                    ),
                )
                contenido_inventario.controls.append(card_producto_promocion)
            page.update()

    # Variable de estado para controlar la vista actual
    vista_actual = "productos"  # Inicia mostrando productos

    
    
    

    def buscar_producto_evento(e):
        termino = e.control.value
        if vista_actual == "promociones":
            actualizar_vista_inventario("promociones", termino)
        else:
            actualizar_vista_inventario("productos", termino)

    def cambiar_vista_productos(e):
        nonlocal vista_actual
        vista_actual = "productos"
        actualizar_vista_inventario(vista_actual)

    def cambiar_vista_promociones(e):
        nonlocal vista_actual
        vista_actual = "promociones"
        actualizar_vista_inventario(vista_actual)
        
        
        #MODAL DE AGREGAR PRODUCTO



    def mostrar_modal_producto_agg(page):
        categorias = consulta_categoria()
        proveedores = consulta_proveedor()
        ubicacion = consulta_ubicacion()
        
        imagen_seleccionada = None

        def on_image_selected(e):
            nonlocal imagen_seleccionada
            if e.files:
                imagen_seleccionada = e.files[0]
                campo_imagen.value = imagen_seleccionada.name
                page.update()

        def actualizar_fecha_fin(e):
            campo_fecha_vencimiento.value = e.control.value
            page.update()
            
        def generador_barras(codigo_barras):
            barcode_path = os.path.join(DESTINATION_FOLDER_CODIGO_BARRAS, f"{codigo_barras}.png")
            with open(barcode_path, 'wb') as f:
                EAN13(codigo_barras, writer=ImageWriter()).write(f)
            return barcode_path
        # Función para guardar la imagen seleccionada
        def guardar_imagen(file):
            if file:
                # El archivo seleccionado tiene un atributo "path" que contiene su ruta temporal
                os.path.join(DESTINATION_FOLDER, file.name)
                
                # Leer la imagen original desde la ruta del archivo seleccionado
                with open(file.path, 'rb') as input_file:
                    input_data = input_file.read()

                # Eliminar el fondo de la imagen
                output_data = remove(input_data)  # Eliminar fondo

                # Guardar la imagen sin fondo en la carpeta de destino
                image_path_sin_fondo = os.path.join(DESTINATION_FOLDER, f"{file.name}")
                with open(image_path_sin_fondo, 'wb') as output_file:
                    output_file.write(output_data)
                
                # Retornar el nombre del archivo sin fondo para guardarlo en la base de datos
                return f"{file.name}"

            return None

        
        # Controles principales
        codigo_barra = ft.TextField(label="Código de Barras", width=300)
        nombre_producto = ft.TextField(label="Nombre del Producto", width=300)
        cantidad_disponible = ft.TextField(label="Cantidad Disponible", width=300)
        stock_minimo = ft.TextField(label="Stock Mínimo", width=300)
        precio_unitario = ft.TextField(label="Precio de Venta", width=300)
        precio_compra = ft.TextField(label="Precio de Compra", width=300)

        ubicacion_almacen =  ft.Dropdown(
            label="Ubicacion de Producto",
            options=[ft.dropdown.Option(key=str(ubi[0]), text=ubi[1]) for ubi in ubicacion],
            width=300
        )

        descripcion_producto = ft.TextField(label="Descripción del Producto", multiline=True, max_lines=3, width=300)
        marca_producto = ft.TextField(label="Marca del Producto", width=300)
        referencia_producto = ft.TextField(label="Referencia del Producto", width=300)

        categoria_producto = ft.Dropdown(
            label="Categoría del Producto",
            options=[ft.dropdown.Option(key=str(cat[0]), text=cat[1]) for cat in categorias],
            width=300
        )

        proveedor_producto = ft.Dropdown(
            label="Proveedor del Producto",
            options=[ft.dropdown.Option(key=str(prov[1]), text=prov[1]) for prov in proveedores],
            width=300
        )

        campo_imagen = ft.TextField(label="Imagen seleccionada", read_only=True, width=300)
        imagen_producto = ft.FilePicker(on_result=on_image_selected)
        btn_seleccionar_imagen = ft.ElevatedButton("Seleccionar Imagen", on_click=lambda _: imagen_producto.pick_files(allow_multiple=False))
        page.overlay.append(imagen_producto)

        campo_fecha_vencimiento = ft.TextField(label="Fecha de Vencimiento", read_only=True, width=300)
        btn_fecha_fin = ft.ElevatedButton(
            "Fecha Vencimiento",
            icon=ft.icons.CALENDAR_MONTH,
            on_click=lambda e: page.open(
                ft.DatePicker(
                    first_date=datetime(2024, 10, 1),
                    last_date=datetime(2030, 10, 1),
                    on_change=actualizar_fecha_fin,
                )
            ),
        )

        seccion_actual = 1

        def mostrar_seccion():
            if seccion_actual == 1:
                modal_producto.content.controls = [
                    ft.Row([codigo_barra, nombre_producto]),
                    ft.Row([cantidad_disponible, stock_minimo]),
                    ft.Row([precio_unitario, precio_compra]),
                    ft.Row([marca_producto, referencia_producto]),
                ]
                modal_producto.actions = [btn_cancelar, btn_siguiente]
            elif seccion_actual == 2:
                modal_producto.content.controls = [
                    ft.Row([btn_seleccionar_imagen, btn_fecha_fin]),
                    ft.Row([ campo_imagen, campo_fecha_vencimiento ]),
                    ft.Row([categoria_producto, proveedor_producto]),
                    ft.Row([ ubicacion_almacen, descripcion_producto]),
                ]
                modal_producto.actions = [btn_devolver, btn_guardar]
            page.update()

        def siguiente_seccion(e):
            nonlocal seccion_actual
            seccion_actual = 2
            mostrar_seccion()

        def devolver_seccion(e):
            nonlocal seccion_actual
            seccion_actual = 1
            mostrar_seccion()

        def guardar_producto(e):
            if not codigo_barra.value.strip():
                page.snack_bar = ft.SnackBar(ft.Text("El código de barras es obligatorio"), open=True)
                page.update()
                return
            guardar_imagen(imagen_seleccionada) if imagen_seleccionada else None
            generador_barras(codigo_barra.value)
            import datetime
            registro_de_productos(
                
                codigo_barra.value,
                nombre_producto.value,
                descripcion_producto.value,
                categoria_producto.value,
                proveedor_producto.value,
                cantidad_disponible.value,
                stock_minimo.value,
                precio_unitario.value,
                precio_compra.value,
                datetime.datetime.now(),
                ubicacion_almacen.value,
                campo_imagen.value,
                marca_producto.value,
                referencia_producto.value,
                campo_fecha_vencimiento.value
            )
            actualizar_vista_inventario(vista_actual)
            page.snack_bar = ft.SnackBar(ft.Text("Producto guardado exitosamente"), open=True)
            modal_producto.open = False
            page.update()

        btn_siguiente = ft.ElevatedButton("Siguiente", on_click=siguiente_seccion)
        btn_devolver = ft.ElevatedButton("Devolver", on_click=devolver_seccion)
        btn_guardar = ft.ElevatedButton("Guardar", on_click=guardar_producto)
        btn_cancelar = ft.ElevatedButton("Cancelar", on_click=lambda e: cerrar_modal(page))

        modal_producto = ft.AlertDialog(
            title=ft.Row(
                [
                    ft.Text("Crear Producto", size=24, weight="bold"),
                    ft.IconButton(ft.icons.CLOSE, on_click=lambda _: cerrar_modal(page), icon_size=24)
                ],
                alignment="spaceBetween"
            ),
            content=ft.Column([], spacing=10, height=400, width=650),
            actions=[],
            modal=True
        )

        mostrar_seccion()
        page.dialog = modal_producto
        modal_producto.open = True
        page.update()

        

    def mostrar_modal_promocion(page, id):
            """Muestra un modal para crear una promoción para el producto seleccionado."""

            producto = informacion_producto(id)
            precio_promocion = ft.TextField(label="Precio Promoción", width=220)
            codigo_promocion = ft.TextField(label="Código de Promoción (Opcional)", width=220)

            # Variables para almacenar fecha y hora seleccionadas
            fecha_inicio = None
            hora_inicio = None
            fecha_fin = None
            hora_fin = None

            # Textos para mostrar las fechas y horas seleccionadas
            fecha_inicio_text = ft.Text("Selecciona la fecha de inicio", size=16)
            hora_inicio_text = ft.Text("Selecciona la hora de inicio", size=16)
            fecha_fin_text = ft.Text("Selecciona la fecha de fin", size=16)
            hora_fin_text = ft.Text("Selecciona la hora de fin", size=16)

            # Funciones para actualizar la fecha y hora seleccionadas
            def actualizar_fecha_inicio(e):
                nonlocal fecha_inicio
                fecha_inicio = e.control.value
                fecha_inicio_text.value = f"Fecha de inicio: {fecha_inicio.strftime('%d/%m/%Y')}"
                page.update()

            def actualizar_hora_inicio(e):
                nonlocal hora_inicio
                hora_inicio = e.control.value
                hora_inicio_text.value = f"Hora de inicio: {hora_inicio.strftime('%H:%M')}"
                page.update()

            def actualizar_fecha_fin(e):
                nonlocal fecha_fin
                fecha_fin = e.control.value
                fecha_fin_text.value = f"Fecha de fin: {fecha_fin.strftime('%d/%m/%Y')}"
                page.update()

            def actualizar_hora_fin(e):
                nonlocal hora_fin
                hora_fin = e.control.value
                hora_fin_text.value = f"Hora de fin: {hora_fin.strftime('%H:%M')}"
                page.update()

            # Función para guardar la promoción
            def guardar_promocion(e):
                if fecha_inicio and hora_inicio and fecha_fin and hora_fin:
                    datetime_inicio = datetime.combine(fecha_inicio, hora_inicio)
                    datetime_fin = datetime.combine(fecha_fin, hora_fin)
                    precio_prom = precio_promocion.value
                    codigo = codigo_promocion.value
                    cantidad = producto['cantidad_disponible']

                    

                    producto_promocion(
                        producto["id_producto"], precio_prom, datetime_inicio, datetime_fin, codigo, cantidad
                    )
                    actualizar_vista_inventario(vista_actual)
                    cerrar_modal_promo(page)
                else:
                    return

            # Crear las filas con los campos de precio y código de promoción
            campos_row = ft.Row(
                [
                    precio_promocion,
                    codigo_promocion,
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10,
            )

            # Crear el contenido del modal
            modal_content = ft.Container(
                content=ft.Column(
                    [
                        ft.Row(
                            [
                                ft.Text(f"Crear Promoción para: {producto['nombre_producto']}", size=20, weight=ft.FontWeight.BOLD),
                                ft.IconButton(
                                    icon=ft.icons.CLOSE,
                                    on_click=lambda e: cerrar_modal_promo(page),
                                    tooltip="Cerrar",
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        ),
                        # Mostrar los campos juntos
                        campos_row,
                        ft.Row(
                            [
                                ft.ElevatedButton(
                                    "Seleccionar Fecha Inicio",
                                    icon=ft.icons.CALENDAR_MONTH,
                                    on_click=lambda e: page.open(
                                        ft.DatePicker(
                                            first_date=datetime(2023, 10, 1),
                                            last_date=datetime(2024, 10, 1),
                                            on_change=actualizar_fecha_inicio,
                                        )
                                    ),
                                ),
                                ft.ElevatedButton(
                                    "Seleccionar Hora Inicio",
                                    icon=ft.icons.ACCESS_TIME_FILLED,
                                    on_click=lambda e: page.open(
                                        ft.TimePicker(
                                            confirm_text="Confirmar",
                                            on_change=actualizar_hora_inicio,
                                        )
                                    ),
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.Row(
                            [
                                fecha_inicio_text,
                                hora_inicio_text,
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.Row(
                            [
                                ft.ElevatedButton(
                                    "Seleccionar Fecha Fin",
                                    icon=ft.icons.CALENDAR_MONTH,
                                    on_click=lambda e: page.open(
                                        ft.DatePicker(
                                            first_date=datetime(2024, 10, 1),
                                            last_date=datetime(2030, 10, 1),
                                            on_change=actualizar_fecha_fin,
                                        )
                                    ),
                                ),
                                ft.ElevatedButton(
                                    "Seleccionar Hora Fin",
                                    icon=ft.icons.ACCESS_TIME_FILLED,
                                    on_click=lambda e: page.open(
                                        ft.TimePicker(
                                            confirm_text="Confirmar",
                                            on_change=actualizar_hora_fin,
                                        )
                                    ),
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=20,
                        ),
                        ft.Row(
                            [
                                fecha_fin_text,
                                hora_fin_text,
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=20,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                ),
                width=600,
                height=380,
                padding=20,
                border_radius=ft.border_radius.all(20),
                bgcolor=ft.colors.WHITE,
            )

            # Botones "Guardar" y "Cancelar"
            modal = ft.AlertDialog(
                content=modal_content,
                actions=[
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Guardar Promoción",
                                on_click=guardar_promocion,
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    color=ft.colors.WHITE,
                                    bgcolor=ft.colors.GREEN,
                                    padding=15,
                                ),
                            ),
                            ft.TextButton(
                                "Cancelar",
                                on_click=lambda e: cerrar_modal_promo(page),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=15,
                                ),
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.END,
                    ),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
            )

            page.dialog = modal
            modal.open = True
            page.update()

    def cerrar_modal_promo(page):
        page.dialog.open = False
        page.update()
                    
            
            
            
            
    #MOSTRAR MODAL DE OPCIONES DE PRODUCTOS
    def mostrar_modal_producto(page, producto):
        """Muestra el modal con las opciones del producto seleccionado."""
        global producto_seleccionado
        productos = informacion_producto(producto)
        producto_seleccionado = productos  # Establecer el producto seleccionado

        # Crear el contenido del modal con un contenedor que define ancho y alto
        modal_content = ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text(f"{productos['nombre_producto']}", size=24, weight=ft.FontWeight.BOLD),
                            ft.IconButton(
                                icon=ft.icons.CLOSE,
                                on_click=lambda e: cerrar_modal(page),
                                tooltip="Cerrar",
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Poner en Promoción", 
                                on_click=lambda e: mostrar_modal_promocion(page, producto),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    color=ft.colors.WHITE,
                                    bgcolor=ft.colors.GREEN,
                                    padding=15,
                                ),
                            ),
                            ft.ElevatedButton(
                                "Editar Producto", 
                                on_click=lambda e: editar_producto(page, producto),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    color=ft.colors.WHITE,
                                    bgcolor=ft.colors.BLUE,
                                    padding=15,
                                ),
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=20,
                    ),
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Ver Información del Producto", 
                                on_click=lambda e: ver_mas(page, producto),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    color=ft.colors.WHITE,
                                    bgcolor=ft.colors.ORANGE,
                                    padding=15,
                                ),
                            ),
                            ft.ElevatedButton(
                                "Eliminar Producto", 
                                on_click=lambda e: eliminar_produc(page, producto),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    color=ft.colors.WHITE,
                                    bgcolor=ft.colors.RED,
                                    padding=15,
                                ),
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=20,
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=20,
            ),
            width=500,  # Ancho del contenido del modal
            height=250,  # Alto del contenido del modal
            padding=20,
            border_radius=ft.border_radius.all(20),  # Borde redondeado
            bgcolor=ft.colors.WHITE
        )

        # Crear el modal
        modal = ft.AlertDialog(
            content=modal_content,
            actions=[
                ft.TextButton(
                    "Cerrar", 
                    on_click=lambda e: cerrar_modal(page),
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=15,
                    ),
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        
        page.dialog = modal
        modal.open = True
        page.update()





# Función para cerrar el modal
    def cerrar_modal(page):
        if page.dialog is not None:
            page.dialog.open = False
            page.update()

# Función para editar producto, llamada desde cualquier lugar
    def editar_producto(page, id):
        cerrar_modal(page)  # Asegúrate de que el modal anterior se cierre.

        categorias = consulta_categoria()
        proveedores = consulta_proveedor()
        ubicacion = consulta_ubicacion()

        productos = informacion_producto(id)

        if productos is None:
            
            return

        # Variables que se actualizan con los eventos.
        imagen_seleccionada = None

        def actualizar_fecha(e):
            fecha_vencimiento.value = e.control.value
            page.update()

        def guardar_cambios(e):
            # Guardar la imagen si hay una seleccionada.
            if imagen_seleccionada:
                imagen_guardada = guardar_imagen(imagen_seleccionada)
            else:
                imagen_guardada = productos["imagen_producto"]

                

            # Actualizar el producto en la base de datos.
            actualizar_producto(
                productos['id_producto'],
                nombre_producto.value,
                imagen_guardada,
                descripcion.value,
                categoria.value,
                cantidad.value,
                stock_minimo.value,
                precio_unitario.value,
                precio_compra.value,
                proveedor.value,
                ubicacion_producto.value,
                marca_producto.value,
                fecha_vencimiento.value,
            )
            
            actualizar_vista_inventario(vista_actual)
            cerrar_modal(page)  # Cerrar el modal tras guardar los cambios.

        def on_image_selected(e):
            nonlocal imagen_seleccionada
            if e.files:
                imagen_seleccionada = e.files[0]
                imagen.value = imagen_seleccionada.name
                page.update()

        def guardar_imagen(file):
            if file:
                # El archivo seleccionado tiene un atributo "path" que contiene su ruta temporal
                os.path.join(DESTINATION_FOLDER, file.name)
                
                # Leer la imagen original desde la ruta del archivo seleccionado
                with open(file.path, 'rb') as input_file:
                    input_data = input_file.read()

                # Eliminar el fondo de la imagen
                output_data = remove(input_data)  # Eliminar fondo

                # Guardar la imagen sin fondo en la carpeta de destino
                image_path_sin_fondo = os.path.join(DESTINATION_FOLDER, f"{file.name}")
                with open(image_path_sin_fondo, 'wb') as output_file:
                    output_file.write(output_data)
                
                # Retornar el nombre del archivo sin fondo para guardarlo en la base de datos
                return f"{file.name}"

            return None

        # Creación del selector de imágenes.
        imagen_producto = ft.FilePicker(on_result=on_image_selected)
        btn_seleccionar_imagen = ft.ElevatedButton(
            "Seleccionar Imagen", 
            on_click=lambda _: imagen_producto.pick_files(allow_multiple=False)
        )
        page.overlay.append(imagen_producto)

        btn_fecha = ft.ElevatedButton(
            "Seleccionar Fecha Fin",
            icon=ft.icons.CALENDAR_MONTH,
            on_click=lambda e: page.open(
                ft.DatePicker(
                    first_date=datetime(2024, 10, 1),
                    last_date=datetime(2030, 10, 1),
                    on_change=actualizar_fecha,
                )
            ),
        )

        # Campos de edición.
        nombre_producto = ft.TextField(label="Nombre del Producto", value=productos["nombre_producto"], width=250)
        precio_unitario = ft.TextField(label="Precio Unitario", value=productos["precio_venta"], width=250)
        precio_compra = ft.TextField(label="Precio de Compra", value=productos["precio_compra"], width=250)
        cantidad = ft.TextField(label="Cantidad", value=productos["cantidad_disponible"], width=250)
        stock_minimo = ft.TextField(label="Stock Mínimo", value=productos["stock_minimo"], width=250)
        marca_producto = ft.TextField(label="Marca", value=productos["marca_producto"], width=250)
        descripcion = ft.TextField(label="Descripción", value=productos["descripcion_producto"], width=250)

        proveedor = ft.Dropdown(
            label="Proveedor", 
            value=productos["proveedor_producto"],
            options=[ft.dropdown.Option(key=prov[1], text=prov[1]) for prov in proveedores], 
            width=250
        )

        ubicacion_producto = ft.Dropdown(
            label="Ubicación", 
            value=productos["ubicacion_producto"],
            options=[ft.dropdown.Option(key=ubi[1], text=ubi[1]) for ubi in ubicacion], 
            width=250
        )

        categoria = ft.Dropdown(
            label="Categoría", 
            value=productos["categoria_producto"],
            options=[ft.dropdown.Option(key=cat[0], text=cat[0]) for cat in categorias], 
            width=250
        )

        fecha_vencimiento = ft.TextField(
            label="Fecha de Vencimiento", 
            value=productos["fecha_vencimiento"], 
            read_only=True, 
            width=250
        )

        imagen = ft.TextField(
            label="Imagen", 
            value=productos["imagen_producto"], 
            read_only=True, 
            width=250
        )

        # Organización en columnas.
        columna_derecha = ft.Column([
            nombre_producto,
            precio_unitario,
            stock_minimo,
            proveedor, 
            btn_seleccionar_imagen,
            imagen, 
            ubicacion_producto
        ])

        columna_izquierda = ft.Column([
            cantidad,
            precio_compra, 
            marca_producto,
            categoria,
            btn_fecha,
            fecha_vencimiento, 
            descripcion
        ])

        fila = ft.Row([columna_derecha, columna_izquierda], spacing=20)

        # Botón para cerrar el modal.
        boton_cerrar = ft.IconButton(
            icon=ft.icons.CLOSE, icon_size=20, icon_color=ft.colors.RED,
            on_click=lambda e: cerrar_modal(page)
        )

        # Crear y mostrar el modal.
        modal = ft.AlertDialog(
            title=ft.Row([
                ft.Text("Editar Producto", weight=ft.FontWeight.BOLD, size=22),
                ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            content=ft.Container(content=fila, padding=10, width=540, height=380),
            actions=[
                ft.TextButton("Guardar", on_click=guardar_cambios),
                ft.TextButton("Cancelar", on_click=lambda e: cerrar_modal(page))
            ],
            actions_alignment=ft.MainAxisAlignment.END,
            modal=True
        )

        page.dialog = modal
        modal.open = True  # Asegura que se abra.
        page.update()  # Actualiza la página para mostrar el modal.





        
  










    def ver_mas(page, id):
        cerrar_modal(page)  # Cierra cualquier modal abierto previamente
        
        productos = informacion_producto(id)
        

        if productos is None:
            
            return
        
        # Coloco el "Código de Barras" en la posición correcta
        datos_produtos = {
            "Nombre de Producto": productos["nombre_producto"],
            "Precio del Producto": productos["precio_compra"],
            "Precio de Venta": productos["precio_venta"],
            "Descripción del Producto": productos["descripcion_producto"],
            "Categoría del Producto": productos["categoria_producto"],
            "Proveedor del producto": productos["proveedor_producto"],
            "Fecha de Ingreso": productos["fecha_ingreso"],
            "Cantidad del Producto": productos["cantidad_disponible"],
            "Stock Minimo": productos["stock_minimo"],
            "Ubicación del Producto": productos["ubicacion_producto"],
            "Creador del Producto": f'{productos["nombre_creador"]} {productos["apellido_creador"]}',
            "Código de Barras": f'assets/img/{productos["codigo_barras"]}.png'  # Ruta de la imagen del código de barras
        }

        filas = []
        items = list(datos_produtos.items())

        # Agrupar elementos de dos en dos
        for i in range(0, len(items), 2):
            columnas = []
            for j in range(2):
                if i + j < len(items):
                    campo, valor = items[i + j]
                    if campo == "Código de Barras":
                        columnas.append(
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            campo,
                                            weight=ft.FontWeight.BOLD,
                                            size=16,
                                            color=ft.colors.BLUE_GREY_700
                                        ),
                                        ft.Image(
                                            src=valor, 
                                            width=200,
                                            height=100,
                                            fit=ft.ImageFit.CONTAIN
                                        )
                                    ],
                                    spacing=2
                                ),
                                padding=ft.padding.only(left=5, right=5),
                                expand=True
                            )
                        )
                    else:
                        columnas.append(
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            campo,
                                            weight=ft.FontWeight.BOLD,
                                            size=16,
                                            color=ft.colors.BLUE_GREY_700
                                        ),
                                        ft.Text(
                                            valor,
                                            weight=ft.FontWeight.NORMAL,
                                            size=16,
                                            color=ft.colors.BLACK
                                        )
                                    ],
                                    spacing=2
                                ),
                                padding=ft.padding.only(left=5, right=5),
                                expand=True
                            )
                        )
            
            # Cada fila tiene dos columnas
            fila = ft.Row(
                columnas,
                alignment=ft.MainAxisAlignment.START,
                spacing=10
            )
            filas.append(fila)

        contenido = ft.Column(
            filas,
            spacing=4
        )

        boton_cerrar = ft.IconButton(
            icon=ft.icons.CLOSE,
            icon_size=20,
            icon_color=ft.colors.RED,  # 'X' en rojo
            on_click=lambda e: cerrar_modal(page),
        )

        dialogo = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                [
                    ft.Text("Detalles de producto", weight=ft.FontWeight.BOLD, size=22),
                    ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
            ),
            content=ft.Container(
                content=contenido,
                padding=ft.padding.all(10),
                width=600,
                height=400,
            ),
            actions_alignment=ft.MainAxisAlignment.END,
            shape=ft.RoundedRectangleBorder(radius=10),
            bgcolor=ft.colors.WHITE,
        )

        page.dialog = dialogo
        dialogo.open = True
        page.update()








    
        
    def eliminar_produc(page, id):
        def eliminar_product(e):
                try:
                    # Aquí llamas tu función para eliminar el producto de la base de datos
                    eliminar_producto(id)  
                    actualizar_vista_inventario(vista_actual)
                    page.update()
                    cerrar_modal()
                except Exception as e:
                    return
                cerrar_modal()

        def cerrar_modal(e=None):
            # Ocultar el modal de confirmación
            page.dialog.open = False
            page.update()

        # Crear el contenido del modal
        modal = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirmación de eliminación", weight=ft.FontWeight.BOLD),
            content=ft.Text("¿Seguro que quieres eliminar este producto?"),
            actions=[
                ft.ElevatedButton(
                    "Cancelar", 
                    on_click=cerrar_modal
                ),
                ft.ElevatedButton(
                    "Eliminar", 
                    on_click=eliminar_product, 
                    bgcolor=ft.colors.RED, 
                    color=ft.colors.WHITE
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        # Asignar y mostrar el modal
        page.dialog = modal
        page.dialog.open = True
        page.update()


        
        

    def cerrar_modal(page):
        page.dialog.open = False
        page.update()   
        page.dialog = None

   
        
        
 
   # Función para abrir el modal de agregar cantidad de productos
    def mostrar_modal_agregar_cantidad(page, id_produc):
        produ = informacion_producto(id_produc[0])  # Obtener el producto por ID
          # Verificar que la información es correcta

        def actualiza_cantidad():
            try:
                if produ['id_producto']:  # Validar que el producto existe
                    id_pr = produ['id_producto']

                    # Asegurar que ambos valores son enteros antes de sumar
                    suma_cantidad = int(cantidad.value) + produ['cantidad_disponible']

                    # Actualizar la cantidad en la base de datos
                    actualizar_cantidad_producto(id_pr, suma_cantidad)
                    actualizar_vista_inventario(vista_actual)
                    
                    # Cerrar modal y actualizar la página
                    cerrar_modal_cantidad(page)
                    page.update()

            except ValueError:
                return
            except Exception as e:
                return

        # Campo de texto para ingresar la cantidad
        cantidad = ft.TextField(
            label="Cantidad",
            keyboard_type=ft.KeyboardType.NUMBER,
            width=200,
        )

        # Crear el modal de agregar cantidad
        modal_agregar_cantidad = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                [
                    ft.Text(f"Agregar cantidad - {produ['nombre_producto']}", weight=ft.FontWeight.BOLD),
                    ft.IconButton(
                        icon=ft.icons.CLOSE,
                        on_click=lambda e: cerrar_modal_cantidad(page),
                        tooltip="Cerrar",
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        ft.Text(f"Producto: {produ['nombre_producto']}", size=16),
                        cantidad,
                    ],
                    spacing=20,
                ),
                width=400,
                height=150,
            ),
            actions=[
                ft.Row(
                    [
                        ft.ElevatedButton(
                            text="Cancelar",
                            on_click=lambda e: cerrar_modal_cantidad(page),
                        ),
                        ft.ElevatedButton(
                            text="Guardar",
                            on_click=lambda e: actualiza_cantidad(),
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.END,
                    spacing=10,
                )
            ],
            actions_alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        )

        # Mostrar el modal
        page.dialog = modal_agregar_cantidad
        modal_agregar_cantidad.open = True
        page.update()

        
        
    def cerrar_modal_cantidad(page):
        page.dialog.open = False
        page.update()
        





                
        




    return ft.Column(
        [
            ft.Container(
                content=ft.Row(
                    [
                        ft.TextField(
                            hint_text="Buscar...",
                            border_radius=10,
                            width=350,
                            height=40,
                            prefix_icon=ft.icons.SEARCH,
                            on_change=buscar_producto_evento, # Evento de búsqueda
                        ),
                        ft.Row(
                            [
                                ft.ElevatedButton(text="Crear Ubicacion", visible=False),
                                ft.ElevatedButton(text="Crear Categoría", on_click=lambda e: show_create_category_modal(page)),
                                ft.ElevatedButton(text="Crear Producto", on_click=lambda e: mostrar_modal_producto_agg(page)),
                                ft.ElevatedButton(text="Crear Proveedor", on_click=lambda e: mostrar_modal(page)),
                            ],
                            alignment=ft.MainAxisAlignment.END,
                            spacing=5,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10,
                ),
                padding=ft.Padding(10, 10, 10, 10),
            ),
            ft.Row(
                [
                    ft.TextButton(text="Ver Productos", on_click=cambiar_vista_productos),
                    ft.TextButton(text="Ver Productos en Promociones", on_click=cambiar_vista_promociones, visible=False),
                ],
                alignment=ft.MainAxisAlignment.START,
                spacing=5,
            ),
            ft.Container(content=contenido_inventario, expand=True),
        ],
        expand=True,
    )
    
    
    
    
    
    
    
