import flet as ft
import re
import datetime
from models.usuarios import registro_de_usuarios
from routes.usuarios import consulta_usuario, eliminar_usuario, actualizar_usuario, buscar_usuario, informacion_usuario
from utils.mensajeAlerta import mostrar_alerta_auto


def mis_usuarios_view(page):

    contenido_usuarios = ft.Column(
        spacing=10,
        scroll="auto",
    )
    


    def actualizar_vista(e=None):


        # Limpiar la lista de controles antes de actualizar
        contenido_usuarios.controls.clear()

        # Comprobar si el campo de búsqueda tiene al menos 4 caracteres para filtrar
        if campo_buscar.value and len(campo_buscar.value) >= 4:
            usuarios_filtrados = buscar_usuario(nombre_usuario=campo_buscar.value)
        else:
            # Si no hay búsqueda o el texto de búsqueda es muy corto, mostrar todos los usuarios
            usuarios_filtrados = consulta_usuario()

        # Si no hay resultados de la búsqueda, mostrar un mensaje
        if not usuarios_filtrados:
            contenido_usuarios.controls.append(ft.Text("No hay resultados con esa búsqueda", color=ft.colors.RED))
        else:
            # Crear las filas para cada usuario encontrado
            for usuario in usuarios_filtrados:
                color_texto = "green" if usuario[14] == 'activo' else "red"
                def on_click_editar(e, user_id=usuario[0]):
                    actualizar_usuarios(page, user_id)
                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Row(
                                [
                                    ft.CircleAvatar(content=ft.Text(usuario[1][0], weight=ft.FontWeight.BOLD)),
                                    ft.Column(
                                        [
                                            ft.Text(usuario[1], weight=ft.FontWeight.BOLD),
                                            ft.Text(usuario[6]),
                                        ],
                                        spacing=2
                                    ),
                                ],
                                spacing=10,
                                alignment=ft.MainAxisAlignment.START
                            ),
                            padding=ft.Padding(top=10, right=10, bottom=10, left=10),
                            width=250,
                        ),
                        ft.Text(usuario[13], width=100),
                        ft.Text(usuario[8], width=100),
                        ft.Text(usuario[14], color=color_texto, width=80),
                        ft.Row(
                            [
                                    ft.IconButton(
                                        icon=ft.icons.DELETE_OUTLINED, 
                                        on_click=lambda e, id=usuario[0]: desativar_usuario(page, id),
                                        icon_color='red',
                                        # Deshabilitar botón si el usuario ya está desactivado
                                        disabled=not usuario[14]=='activo',
                                        tooltip="Usuario ya está desactivado" if not usuario[14] == 'activo' else "Desactivar usuario",
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.EDIT_OUTLINED, 
                                        on_click=on_click_editar,
                                        icon_color='blue'
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.INFO_OUTLINED, 
                                        on_click=lambda e, id=usuario[0]: ver_mas_info(page, id),
                                        icon_color= 'yellow'
                                    ),
                                ],
                            alignment=ft.MainAxisAlignment.END,
                            spacing=10
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                )
                contenido_usuarios.controls.append(fila)

        page.update()
        

        
        



    # Campo de búsqueda con icono
    campo_buscar = ft.TextField(
        hint_text="Buscar usuario...",
        border_radius=10,
        width=350,
        height=40,
        prefix_icon=ft.icons.SEARCH,
        on_change=actualizar_vista,
    )

    # Botón para agregar usuario
    boton_agregar_usuario = ft.FloatingActionButton(
        text="Agregar Usuario",
        icon=ft.icons.PERSON_ADD,
        bgcolor=ft.colors.BLUE,
        shape=ft.RoundedRectangleBorder(radius=15),
        on_click=lambda e: mostrar_modal(page),
        width=160,
        height=40,
        content=ft.Text("Agregar Usuario", weight=ft.FontWeight.BOLD),
    )

    # Contenedor para la barra de búsqueda y el botón
    barra_superior = ft.Container(
        content=ft.Row(
            [
                campo_buscar,
                boton_agregar_usuario,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        ),
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
    )

    # Contenedor para el encabezado (fijo)
    encabezado = ft.Container(
        content=ft.Row(
            [
                ft.Text("Usuario", weight=ft.FontWeight.BOLD, width=225),
                ft.Text("Rol de usuario", weight=ft.FontWeight.BOLD, width=100),
                ft.Text("telefono", weight=ft.FontWeight.BOLD, width=90),
                ft.Text("Estado", weight=ft.FontWeight.BOLD, width=105),
                ft.Text("Acciones", weight=ft.FontWeight.BOLD, width=100),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        bgcolor=ft.colors.BLUE_GREY_100,
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
        border_radius=10,
        margin=ft.Margin(top=10, right=10, bottom=10, left=10),
    )

    # Combinación de barra superior, encabezado fijo, y contenido desplazable
    vista_completa = ft.Column(
        [
            barra_superior,
            encabezado,
            ft.Container(
                content=contenido_usuarios,
                expand=True,
            )
        ],
        expand=True,
    )



    #DESACTIVAR USARIOS
    def desativar_usuario(page, id):
        
        # Crear un cuadro de diálogo de confirmación
        dialogo_confirmacion = ft.AlertDialog(
            title=ft.Text("Confirmar Eliminación",  weight=ft.FontWeight.BOLD),
            content=ft.Text("¿Estás seguro de que deseas eliminar este usuario?"),
            actions=[
                ft.ElevatedButton(
                    text="Cancelar",
                    on_click=lambda e: cerrar_dialogo(page)
                ),
                ft.ElevatedButton(
                    text="Eliminar",
                    on_click=lambda e: confirmar_eliminacion(page, id),
                    bgcolor=ft.colors.RED, 
                    color=ft.colors.WHITE
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )

        # Mostrar el diálogo
        page.dialog = dialogo_confirmacion
        dialogo_confirmacion.open = True
        page.update()

    
    #CERRA MODAL
    def cerrar_dialogo(page):
        # Cierra el cuadro de diálogo
        page.dialog.open = False
        page.update()
    
    #CONFIRMACION DE ELIMINAR USUARUIOS 
    def confirmar_eliminacion(page, id):
        try:
            eliminar_usuario(id)
            actualizar_vista()
            cerrar_dialogo(page)
            page.update()

        except Exception as e:
            
            error_dialogo = ft.AlertDialog(
                title=ft.Text("Error"),
                content=ft.Text("Hubo un problema al eliminar el usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))]
            )
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()


    #ACTUALIZAR USUARIOS
    def actualizar_usuarios(page, user_id):
        # Obtener los datos del usuario actual
        usuario = informacion_usuario(user_id)
    
        if usuario is None:
            
            return

        def guardar_cambios(e):
            # Recoger los nuevos valores de los campos modificables
            nuevos_datos = {
                "correo_usuario": correo_usuario.value,
                "telefono_usuario": telefono_usuario.value,
                "telefono_usuario2": telefono_usuario2.value,
                "direccion_usuario": direccion_usuario.value,
                "cuidad_usuario": ciudad_usuario.value,
                "rol_usuario": rol_usuario.value
            }

            # Lógica para guardar los cambios en la base de datos
            actualizar = actualizar_usuario(user_id, nuevos_datos["telefono_usuario"], nuevos_datos["telefono_usuario2"], nuevos_datos["direccion_usuario"], nuevos_datos["cuidad_usuario"], nuevos_datos["correo_usuario"], nuevos_datos["rol_usuario"])  # Aquí deberías implementar esta lógica
            if actualizar:
                cerrar_dialogo(page)  # Cierra el diálogo primero
                mostrar_alerta_auto(page, "Actualizacion exitosa", f"El usuario {usuario['nombre_usuario']}, ha sido modificado con exito", duracion=3) 
                actualizar_vista()
                page.update()
            else:
                mostrar_alerta_auto(page, "Error de actualizacion", f"El usuario {usuario['nombre_usuario']}, no pudo ser modificado, por favor intentalo nuevamente", duracion=3)




        # Campos editables
        correo_usuario = ft.TextField(
            label="Correo Electrónico",
            value=usuario["correo_usuario"],
            hint_text="Ingrese el nuevo correo",
            width=250
        )

        telefono_usuario = ft.TextField(
            label="Teléfono",
            value=usuario["telefono_usuario"],
            hint_text="Ingrese el nuevo teléfono",
            width=250
        )

        telefono_usuario2 = ft.TextField(
            label="Teléfono Secundario",
            value=usuario["telefono_usuario2"],
            hint_text="Ingrese el nuevo teléfono secundario",
            width=250
        )

        direccion_usuario = ft.TextField(
            label="Dirección",
            value=usuario["direccion_usuario"],
            hint_text="Ingrese la nueva dirección",
            width=250
        )

        ciudad_usuario = ft.TextField(
            label="Ciudad",
            value=usuario["cuidad_usuario"],
            hint_text="Ingrese la nueva ciudad",
            width=250
        )

        rol_usuario = ft.Dropdown(
            label="Rol de usuario",
            value=usuario["rol_usuario"],
            options=[
                ft.dropdown.Option("Administrador"),
                ft.dropdown.Option("Vendedor"),
                ft.dropdown.Option("Cajero"),
            ],
            width=250
        )

        columna_izquierda = ft.Column(
            controls=[
                correo_usuario,
                telefono_usuario,
                telefono_usuario2
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        columna_derecha = ft.Column(
            controls=[
                direccion_usuario,
                ciudad_usuario,
                rol_usuario
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        # Crear una fila que contenga las dos columnas
        fila = ft.Row(
            controls=[
                columna_izquierda,
                columna_derecha
            ],
            spacing=20,
            alignment=ft.MainAxisAlignment.START
        )

        boton_cerrar = ft.IconButton(
        icon=ft.icons.CLOSE,
        icon_size=20,
        icon_color=ft.colors.RED,  # 'X' en rojo
        on_click=lambda e: cerrar_dialogo(page),
        )


        # Crear el diálogo
        page.dialog = ft.AlertDialog(
            title=ft.Row(
                    [
                        ft.Text("Actualizar usuario", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
            content=ft.Container(
                content=fila,
                padding=10,
                width=540,  
                height=280
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: cerrar_dialogo(page)),
                ft.TextButton("Guardar", on_click=guardar_cambios),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
            modal=True
        )

        page.dialog.open = True
        page.update()




    def ver_mas_info(page, id):
        usuario = informacion_usuario(id)
        try:

            if usuario is None:
                raise ValueError("Usuario no encontrado.")

            # Mapear los datos del usuario
            datos_usuario = {
                "Nombre:": f"{usuario['nombre_usuario']} {usuario['apellido_usuario']}",
                "Documento:": usuario['documento_usuario'],
                "Tipo de Documento:": usuario['tipo_documento'],
                "Fecha de Nacimiento:": usuario['fecha_nacimiento'],
                "Correo:": usuario['correo_usuario'],
                "Teléfono:": usuario['telefono_usuario'],
                "Teléfono Secundario:": usuario['telefono_usuario2'],
                "Dirección:": usuario['direccion_usuario'],
                "Ciudad:": usuario['cuidad_usuario'],
                "Fecha de Creación:": usuario['fecha_creacion'],
                "Rol de usuario:": usuario['rol_usuario'],
                "Estado de usuario:":  usuario['estado_usuario'] 
            }

            # Crear filas con 6 elementos por fila
            filas = []
            items = list(datos_usuario.items())
            for i in range(0, len(items), 2):
                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(
                                        campo,
                                        weight=ft.FontWeight.BOLD,  # Campo en negrita
                                        size=16,  # Tamaño de letra más grande
                                        color=ft.colors.BLUE_GREY_700  # Color identificador
                                    ),
                                    ft.Text(
                                        valor,
                                        weight=ft.FontWeight.NORMAL,
                                        size=14,  # Aumentar un poco el tamaño del valor
                                        color=ft.colors.BLACK  # Color para diferenciar
                                    )
                                ],
                                spacing=2
                            ),
                            padding=ft.padding.only(left=5, right=5),
                            expand=True,
                        )
                        for campo, valor in items[i:i + 2]
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=10
                )
                filas.append(fila)

            # Crear contenido del diálogo
            contenido = ft.Column(
                filas,
                spacing=5
            )

            boton_cerrar = ft.IconButton(
                icon=ft.icons.CLOSE,
                icon_size=20,
                icon_color=ft.colors.RED,  # 'X' en rojo
                on_click=lambda e: cerrar_dialogo(page),
            )

            # Crear el diálogo
            dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Row(
                    [
                        ft.Text("Detalles del Usuario", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                content=ft.Container(
                    content=contenido,
                    padding=ft.padding.all(10),
                    width=600,  # Ajusta el ancho total del modal según sea necesario
                    height=300
                ),
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo
            page.dialog = dialogo
            dialogo.open = True
            page.update()



        except Exception as e:
            
            # Diálogo de error
            error_dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Text("Error", weight=ft.FontWeight.BOLD, color=ft.colors.RED),
                content=ft.Text("Hubo un problema al obtener la información del usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))],
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo de error
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()











    def mostrar_modal(page):
        def cerrar_modal(e=None):
            page.dialog.open = False
            page.update()

        def siguiente_seccion(e):
            nonlocal seccion_actual
            if seccion_actual < len(secciones) - 1:
                seccion_actual += 1
                actualizar_seccion()
                actualizar_botones()  # Mover aquí la actualización de botones
                page.update()

        def anterior_seccion(e):
            nonlocal seccion_actual
            if seccion_actual > 0:
                seccion_actual -= 1
                actualizar_seccion()
                actualizar_botones()  # Mover aquí la actualización de botones
                page.update()



        def actualizar_seccion():
            for i, seccion in enumerate(secciones):
                seccion["contenido"].visible = i == seccion_actual
            actualizar_progreso()
            page.update()

        def validar_correo(campo):
            patron = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
            return re.match(patron, campo.value) is not None

        def validar_telefono(campo):
            return campo.value.isdigit() and 10 <= len(campo.value) <= 12

        def validar_nombre_apellido(campo):
            return len(campo.value) >= 3

        def validar_documento(campo):
            return campo.value.isdigit() and len(campo.value) >= 8

        def validar_contrasena(campo):
            return len(campo.value) >= 4

        def validar_campo(campo, validacion_funcion, mensaje_error):
            """ Valida un campo y actualiza el mensaje de error si es necesario. """
            if campo.value:  # Validar solo si hay texto ingresado
                if validacion_funcion(campo):
                    campo.error_text = None
                else:
                    campo.error_text = mensaje_error
            else:
                campo.error_text = None  # No mostrar error si no hay texto
            page.update()
            
            
        def actualizar_botones():
            """Actualizar la visibilidad de los botones según la sección actual."""
            if seccion_actual == 0:  # Primera sección
                boton_siguiente.visible = True
                boton_atras.visible = False
                boton_guardar.visible = False
            elif seccion_actual == len(secciones) - 1:  # Última sección
                boton_siguiente.visible = False
                boton_atras.visible = True
                boton_guardar.visible = True
            else:  # Secciones intermedias
                boton_siguiente.visible = True
                boton_atras.visible = True
                boton_guardar.visible = False

            # Es necesario actualizar la página aquí después de actualizar la visibilidad
            page.update()


        def actualizar_progreso(e=None):
            campos_obligatorios = secciones[seccion_actual]['campos_obligatorios']
            completados = sum(1 for campo in campos_obligatorios if campo.value)

            # Validación de campos con errores dinámicos solo al ingresar texto
            for campo, validacion_funcion, mensaje_error in validaciones[seccion_actual]:
                validar_campo(campo, validacion_funcion, mensaje_error)

            # Actualizar el valor de la barra de progreso
            progreso.value = completados / len(campos_obligatorios)

            # Desactivar botones si no se han completado todos los campos obligatorios o si hay errores
            boton_siguiente.disabled = completados < len(campos_obligatorios) or any(
                campo.error_text for campo, _, _ in validaciones[seccion_actual]
            )
            
            boton_guardar.disabled = completados < len(campos_obligatorios) or any(
                campo.error_text for campo, _, _ in validaciones[seccion_actual]
            )

            page.update()

        def alternar_contrasena(e):
            contrasena.password = not contrasena.password
            repetir_contrasena.password = not repetir_contrasena.password
            page.update()

        def handle_date_change(e):
            fecha_nacimiento.value = e.control.value.strftime("%Y-%m-%d")
            actualizar_progreso()
        
        def registrar_empresa_y_administrador(e):
            # Registro de usuario
            registro = registro_de_usuarios(
                nombre.value,
                apellido.value,
                documento.value,
                tipo_documento.value,
                fecha_nacimiento.value,
                correo.value,
                contrasena.value,
                telefono1.value,
                telefono2.value,
                direccion.value,
                ciudad.value,
                datetime.datetime.now(),
                rol.value
                
            )

            if registro:
                cerrar_modal()
                mostrar_alerta_auto(page, "Usuario creado", "Usuario creado exitosamente", duracion=3)
                actualizar_vista()
                page.update()      
            else:
                mostrar_alerta_auto(page, "Error de registro", f"El Usuario, no ha podido ser regitrado", duracion=3)


            

        seccion_actual = 0
        progreso = ft.ProgressBar(width=300, height=20, color=ft.colors.GREEN, bgcolor=ft.colors.LIGHT_GREEN)

        nombre = ft.TextField(label="Nombre", on_change=actualizar_progreso)
        apellido = ft.TextField(label="Apellido", on_change=actualizar_progreso)
        documento = ft.TextField(label="Documento", on_change=actualizar_progreso)
        tipo_documento = ft.Dropdown(
            label="Tipo de Documento", on_change=actualizar_progreso,
            options=[
                ft.dropdown.Option("Cédula de Ciudadanía"),
                ft.dropdown.Option("Pasaporte"),
                ft.dropdown.Option("Tarjeta de Identidad"),
            ],
        )
        correo = ft.TextField(label="Correo Electrónico", on_change=actualizar_progreso)
        telefono1 = ft.TextField(label="Teléfono 1", on_change=actualizar_progreso)
        seccion1 = ft.Column([ft.Row([nombre, apellido]), ft.Row([tipo_documento, correo]), ft.Row([documento, telefono1])])

        telefono2 = ft.TextField(label="Segundo numero telefono (opcional)", on_change=actualizar_progreso)
        direccion = ft.TextField(label="Dirección (opcional)", on_change=actualizar_progreso)
        ciudad = ft.TextField(label="Ciudad", on_change=actualizar_progreso)
        fecha_nacimiento = ft.TextField(label="Fecha de Nacimiento", read_only=True)
        boton_fecha = ft.ElevatedButton(
            "Seleccionar Fecha",
            icon=ft.icons.CALENDAR_MONTH,
            on_click=lambda e: page.open(
                ft.DatePicker(
                    first_date=datetime.datetime(year=1960, month=10, day=1),
                    last_date=datetime.datetime(year=2007, month=10, day=1),
                    on_change=handle_date_change,
                )
            )
        )
        contrasena = ft.TextField(label="Contraseña", password=True, on_change=actualizar_progreso)
        repetir_contrasena = ft.TextField(label="Repetir Contraseña", password=True, on_change=actualizar_progreso)
        rol = ft.Dropdown(
            label="Rol", on_change=actualizar_progreso,
            options=[
                ft.dropdown.Option("Administrador"),
                ft.dropdown.Option("Vendedor"),
                ft.dropdown.Option("Cajero"),
            ],
        )

        seccion2 = ft.Column([
            ft.Row([ciudad, direccion]),
            ft.Row([telefono2, fecha_nacimiento]),
            ft.Row([rol, boton_fecha]),
            ft.Row([contrasena, repetir_contrasena])
        ])

        secciones = [
            {"campos_obligatorios": [nombre, apellido, documento, correo, tipo_documento, telefono1], "contenido": seccion1},
            {"campos_obligatorios": [ciudad, fecha_nacimiento, contrasena, repetir_contrasena, rol], "contenido": seccion2},
        ]

        # Validaciones y mensajes de error dinámicos
        validaciones = [
            [(nombre, validar_nombre_apellido, "Debe tener al menos 3 caracteres"),
            (apellido, validar_nombre_apellido, "Debe tener al menos 3 caracteres"),
            (documento, validar_documento, "Debe ser numérico y tener al menos 8 dígitos"),
            (correo, validar_correo, "Correo inválido"),
            (telefono1, validar_telefono, "Debe tener entre 10 y 12 dígitos")],
            [(contrasena, validar_contrasena, "Contraseña debe tener al menos 4 caracteres"),
            (repetir_contrasena, validar_contrasena, "Contraseña debe tener al menos 4 caracteres")]
        ]

        boton_siguiente = ft.ElevatedButton("Siguiente", on_click=siguiente_seccion, disabled=True)
        boton_atras = ft.TextButton("Atrás", on_click=anterior_seccion, visible=False)
        boton_guardar = ft.ElevatedButton("Guardar", on_click=registrar_empresa_y_administrador, visible=False, disabled=True)

        modal = ft.AlertDialog(
            title=ft.Row(
                [
                    ft.Text("Agregar Usuario", weight=ft.FontWeight.BOLD, size=20),
                    ft.IconButton(icon=ft.icons.CLOSE, icon_color=ft.colors.RED, on_click=cerrar_modal),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        progreso,
                        seccion1,
                        seccion2,
                    ],
                    spacing=10,
                    scroll="auto",
                ),
                padding=10,
                width=630,
            ),
            actions=[
                #boton_atras, #boton suspendido
                boton_siguiente,
                boton_guardar,
            ],
            modal=True,
            on_dismiss=cerrar_modal,
            shape=ft.RoundedRectangleBorder(radius=10),
            bgcolor=ft.colors.WHITE,
        )
        actualizar_botones()

        actualizar_seccion()
        page.dialog = modal
        modal.open = True
        page.update()
        contenido_usuarios.update()


    
    
    actualizar_vista()
    
    return vista_completa
