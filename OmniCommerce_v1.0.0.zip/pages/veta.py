import flet as ft

def main(page: ft.Page):
    # Configuración de la página
    page.title = "Sistema de Venta - Administrador"
    page.window.width = 1350  # Actualizado para evitar deprecación
    page.window.height = 800  # Actualizado para evitar deprecación
    page.theme_mode = ft.ThemeMode.LIGHT

    # Estado para saber si el menú está expandido o no
    menu_expanded = ft.Ref[bool]()
    menu_expanded.value = True  # Estado inicial del menú

    # Función para alternar el estado del menú
    def toggle_menu(e):
        menu_expanded.value = not menu_expanded.value
        menu_drawer.extended = menu_expanded.value
        toggle_button.icon = ft.icons.CHEVRON_LEFT if menu_expanded.value else ft.icons.CHEVRON_RIGHT
        page.update()

    # Menú lateral con módulos
    menu_drawer = ft.NavigationRail(
        selected_index=0,
        destinations=[
            ft.NavigationRailDestination(icon=ft.icons.DASHBOARD, label="Estadísticas"),
            ft.NavigationRailDestination(icon=ft.icons.PEOPLE, label="Mis Usuarios"),
            ft.NavigationRailDestination(icon=ft.icons.SCHOOL, label="Inventario"),
            ft.NavigationRailDestination(icon=ft.icons.MESSAGE, label="Compras"),
            ft.NavigationRailDestination(icon=ft.icons.CALENDAR_MONTH, label="Ventas"),
            ft.NavigationRailDestination(icon=ft.icons.SETTINGS, label="Cotizaciones"),
            ft.NavigationRailDestination(icon=ft.icons.SHOPPING_CART, label="Realizar Venta"),
            ft.NavigationRailDestination(icon=ft.icons.RECEIPT, label="Gestión de Facturas"),
            ft.NavigationRailDestination(icon=ft.icons.SCANNER, label="Códigos de Barra"),
            ft.NavigationRailDestination(icon=ft.icons.TAG, label="Categorías"),
            ft.NavigationRailDestination(icon=ft.icons.SETTINGS, label="Ajustes"),
        ],
        extended=menu_expanded.value,  # Controlar si está expandido o no
        height=700,  # Altura fija para NavigationRail
    )

    # Botón para alternar el menú
    toggle_button = ft.IconButton(
        icon=ft.icons.CHEVRON_LEFT if menu_expanded.value else ft.icons.CHEVRON_RIGHT,
        on_click=toggle_menu
    )

    # Nombre de la persona y el icono de perfil
    profile_name = "John Doe"
    profile_icon = ft.Icon(ft.icons.ACCOUNT_CIRCLE, size=24)

    # Contenedor redondeado con nombre e ícono
    profile_container = ft.Container(
        content=ft.Row(
            [
                profile_icon,
                ft.Text(profile_name, weight=ft.FontWeight.BOLD),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=8,
        ),
        padding=ft.Padding(left=12, top=8, right=12, bottom=8),  # Definir padding para todos los lados
        border_radius=15,  # Radio de borde para el contenedor
        bgcolor=ft.colors.BLUE_GREY_100,
    )

    # Contenido principal dentro de un ListView para desplazamiento
    main_content = ft.ListView(
        expand=True,
        padding=ft.Padding(left=12, top=8, right=12, bottom=8),  # Padding uniforme para todo el ListView
        spacing=20,
        controls=[
            # Fila para el botón de alternar menú y el contenedor de perfil alineado a la derecha
            ft.Row(
                [
                    toggle_button,
                    ft.Container(
                        expand=True,  # Expande el contenedor para empujar el perfil a la derecha
                    ),
                    profile_container,  # El contenedor del perfil al lado derecho
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Espacio entre el botón y el perfil
                spacing=10  # Espacio entre el botón y el perfil
            ),
            # Bienvenida
            ft.Text(
                "Bienvenido de nuevo, Taylor 👋",
                style=ft.TextThemeStyle.HEADLINE_MEDIUM
            ),
            # Sección de nuevos cursos
            ft.Text(
                "Nuevos Cursos",
                style=ft.TextThemeStyle.TITLE_SMALL
            ),
            ft.Row(
                [
                    # Tarjetas de cursos
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Content Writing", weight=ft.FontWeight.BOLD),
                                ft.Text("12 Lecciones"),
                                ft.Text("Rate: 4.8"),
                                ft.Text("Tipo: Data Research"),
                            ]),
                            padding=10,
                            width=200
                        )
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Content Writing", weight=ft.FontWeight.BOLD),
                                ft.Text("12 Lecciones"),
                                ft.Text("Rate: 4.8"),
                                ft.Text("Tipo: Data Research"),
                            ]),
                            padding=10,
                            width=200
                        )
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Usability Testing", weight=ft.FontWeight.BOLD),
                                ft.Text("15 Lecciones"),
                                ft.Text("Rate: 5.0"),
                                ft.Text("Tipo: UX/UI Design"),
                            ]),
                            padding=10,
                            width=200
                        )
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Photography", weight=ft.FontWeight.BOLD),
                                ft.Text("8 Lecciones"),
                                ft.Text("Rate: 4.6"),
                                ft.Text("Tipo: Art and Design"),
                            ]),
                            padding=10,
                            width=200
                        )
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            ft.Divider(),
            # Sección de actividades y horarios
            ft.Row(
                [
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Hours Activity", weight=ft.FontWeight.BOLD),
                            # Aquí iría el gráfico de actividad
                        ]),
                        width=300,
                        height=200,
                        padding=20,
                        bgcolor=ft.colors.LIGHT_BLUE,
                        border_radius=10
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Daily Schedule", weight=ft.FontWeight.BOLD),
                            # Aquí iría la lista de schedule
                        ]),
                        width=300,
                        height=200,
                        padding=20,
                        bgcolor=ft.colors.LIGHT_BLUE,
                        border_radius=10
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Daily Schedule", weight=ft.FontWeight.BOLD),
                            # Aquí iría la lista de schedule
                        ]),
                        width=300,
                        height=200,
                        padding=20,
                        bgcolor=ft.colors.LIGHT_BLUE,
                        border_radius=10
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            ft.Divider(),
            # Sección de asignaciones
            ft.Text(
                "Asignaciones",
                style=ft.TextThemeStyle.TITLE_SMALL
            ),
            ft.Row(
                [
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Métodos de datos"),
                                ft.Text("02 Jul, 10:00 AM"),
                                ft.Text("In Progress"),
                            ]),
                            padding=10,
                            width=200
                        )
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Market Research"),
                                ft.Text("14 Jun, 12:45 AM"),
                                ft.Text("Completed"),
                            ]),
                            padding=10,
                            width=200
                        )
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Data Collection"),
                                ft.Text("12 May, 11:00 AM"),
                                ft.Text("Upcoming"),
                            ]),
                            padding=10,
                            width=200
                        )
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
        ]
    )

    # Layout principal: Row que contiene el menú lateral y el contenido principal
    page.add(
        ft.Row(
            [
                menu_drawer,
                main_content,
            ],
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.START,
            expand=True,  # Permitir que el Row ocupe todo el espacio disponible
        )
    )

# Ejecutar la aplicación
ft.app(target=main)