from decimal import Decimal
import flet as ft

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
import os
import fitz 

from win32 import win32print
from routes.facturas import buscar_facturas, consulta_facturas, informacion_facturas


def gestion_facturas_view(page):

    contenido_facturas = ft.Column(
        spacing=10,
        scroll="auto",
    )

    def actualizar_vista(e=None):
        contenido_facturas.controls.clear()

        if campo_buscar.value and len(campo_buscar.value) >= 4:
            facturas_filtradas = buscar_facturas(id_factura=campo_buscar.value)
        else:
            facturas_filtradas = consulta_facturas()
            
        if not facturas_filtradas:
            contenido_facturas.controls.append(
                ft.Text("No hay resultados con esa búsqueda", color=ft.colors.RED)
            )
        else:
            for factura in facturas_filtradas:
                color_texto = "green" if factura[3] == 'pagada' else "red"
                fila = ft.Container(
                    content=ft.Row(
                        [
                            ft.Text(factura[0], width=90),  # ID de factura
                            ft.Text(factura[1], width=150),  # Producto
                            ft.Text(factura[2], width=130),  # Fecha
                            ft.Text(factura[3], color=color_texto, width=80),  # Estado
                            ft.Text(f"${factura[4]:,.2f}", width=100),  # Total
                            ft.Row(
                                [
                                    ft.IconButton(
                                        icon=ft.icons.PRINT,
                                        on_click=lambda e, id=factura[0]:  mostrar_modal_imprimir(id),
                                        icon_color='blue',
                                        tooltip="Imprimir factura",
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.FILE_DOWNLOAD,
                                        on_click=lambda e, id=factura[0]: exportar_excel(id),
                                        icon_color='green',
                                        tooltip="Exportar a Excel",
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.PICTURE_AS_PDF,
                                        on_click=lambda e, id=factura[0]: generar_pdf(id),
                                        icon_color='purple',
                                        tooltip="Generar PDF",
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.DELETE_OUTLINED,
                                        on_click=lambda e, id=factura[0]: eliminar_factura(id),
                                        icon_color='red',
                                        tooltip="Eliminar factura",
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.END,
                                spacing=5,
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=10,
                    ),
                    border=ft.border.all(1, ft.colors.BLUE_GREY_200),
                    border_radius=10,
                    padding=ft.Padding(top=10, right=10, bottom=10, left=10),
                    margin=ft.Margin(top=10, right=10, bottom=10, left=10),
                )
                contenido_facturas.controls.append(fila)

        page.update()

    campo_buscar = ft.TextField(
        hint_text="Buscar factura...",
        border_radius=10,
        width=350,
        height=40,
        prefix_icon=ft.icons.SEARCH,
        on_change=actualizar_vista,
    )


    barra_superior = ft.Container(
        content=ft.Row(
            [
                campo_buscar,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        ),
        padding=ft.Padding(top=5, right=5, bottom=5, left=5),
    )

    encabezado = ft.Container(
        content=ft.Row(
            [
                ft.Text("ID Factura", weight=ft.FontWeight.BOLD, width=80),
                ft.Text("Producto", weight=ft.FontWeight.BOLD, width=150),
                ft.Text("Fecha", weight=ft.FontWeight.BOLD, width=100),
                ft.Text("Estado", weight=ft.FontWeight.BOLD, width=80),
                ft.Text("Total", weight=ft.FontWeight.BOLD, width=100),
                ft.Text("Acciones", weight=ft.FontWeight.BOLD, width=150),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        bgcolor=ft.colors.BLUE_GREY_100,
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
        border_radius=10,
        margin=ft.Margin(top=10, right=10, bottom=10, left=10),
    )
    
    
    def mostrar_modal_imprimir(id_factura):
        # Obtener los datos de la base de datos
        datos_fac = informacion_facturas(id_factura)

        if not datos_fac:
           
            return

        factura_pdf = f"factura_{id_factura}.pdf"

        # Generar PDF para previsualización
        def generar_pdf():

            c = canvas.Canvas(factura_pdf, pagesize=letter)
            width, height = letter

            # Encabezado del PDF
            c.setFillColor("#2196F3")
            c.setFont("Helvetica-Bold", 24)
            c.drawString(30, height - 50, "FACTURA")
            c.setFillColor(colors.black)

            # Información del emisor y cliente
            c.setFont("Helvetica", 12)
            c.drawString(30, height - 100, "Nombre del Negocio S.A.S")
            c.drawString(30, height - 115, "NIT: 123.456.789-0")
            c.drawString(30, height - 130, "Calle Falsa 123, Ciudad, Colombia")
            c.drawString(30, height - 145, "Tel: +57 300 123 4567 - Email: contacto@negocio.com")
            
            c.drawString(400, height - 100, "Cliente:")
            c.drawString(400, height - 115, f"{datos_fac['nombre_cliente']} {datos_fac['apellido_cliente']}")
            c.drawString(400, height - 130, f"Identificación: {datos_fac['documento_cliente']}")
            c.drawString(400, height - 145, f"Dirección: {datos_fac['direccion_cliente']}, {datos_fac['cuidad_cliente']} ")

            # Información de la factura
            c.drawString(30, height - 170, f"Número de Factura: {id_factura}")
            c.drawString(30, height - 185, f"Fecha de Emisión: {datos_fac['fecha_factura']}")
            c.drawString(30, height - 200, "Tipo de Factura: Electrónica")

            # Dibujar tabla de productos
            y_position = height - 240
            c.setFont("Helvetica-Bold", 10)
            c.drawString(30, y_position, "No.")
            c.drawString(60, y_position, "Nombre del Producto/Servicio")
            c.drawString(300, y_position, "Precio Unitario")
            c.drawString(400, y_position, "Cantidad")
            c.drawString(470, y_position, "Total")
            y_position -= 20

            # Dibujar los productos usando el for
            c.setFont("Helvetica", 10)
            subtotal = 0  # Para acumular el subtotal
            for idx, producto in enumerate(datos_fac['productos'], 1):  # Ajustar para iterar sobre la lista de productos
                nombre_producto = producto['nombre_producto']
                precio_unitario = producto['precio_unitario']
                cantidad = producto['cantidad']
                total_producto = precio_unitario * cantidad

                # Asignar los valores al PDF
                c.drawString(30, y_position, str(idx))  # Número del producto
                c.drawString(60, y_position, nombre_producto)  # Nombre del producto
                c.drawString(300, y_position, f"{precio_unitario:.2f}")  # Precio unitario
                c.drawString(400, y_position, str(cantidad))  # Cantidad
                c.drawString(470, y_position, f"{total_producto:.2f}")  # Total
                y_position -= 20
                # Sumar al subtotal
                subtotal += total_producto

            # Calcular IVA y total
            iva = subtotal * Decimal('0.19')
            total_a_pagar = subtotal + iva

            # Resumen de precios
            c.setFont("Helvetica-Bold", 12)
            c.drawString(400, y_position - 40, f"Subtotal: {subtotal:.2f}")
            c.drawString(400, y_position - 55, f"IVA (19%): {iva:.2f}")
            c.drawString(400, y_position - 70, f"Total a Pagar: {datos_fac['total']:.2f}")

            c.save()

        generar_pdf()

        # Obtener número de páginas reales del PDF
        def obtener_paginas_pdf(archivo_pdf):
            doc = fitz.open(archivo_pdf)
            num_paginas = doc.page_count
            doc.close()
            return num_paginas

        # Convertir la primera página del PDF a imagen
        def convertir_pdf_a_imagen(archivo_pdf):
            doc = fitz.open(archivo_pdf)
            page = doc.load_page(0)  # Cargar la primera página
            pix = page.get_pixmap()
            imagen_path = archivo_pdf.replace(".pdf", ".png")
            pix.save(imagen_path)
            doc.close()
            return imagen_path

        # Función de impresión
        def imprimir_factura(archivo_pdf, impresora):
            try:
                # Configurar impresión en impresora seleccionada
                h_printer = win32print.OpenPrinter(impresora)
                os.startfile(archivo_pdf, "print")
                win32print.ClosePrinter(h_printer)
            except Exception as e:
                return

        # Obtener impresoras instaladas
        impresoras = [impresora[2] for impresora in win32print.EnumPrinters(2)]

        # Actualizar imagen del PDF en el modal
        imagen_pdf = convertir_pdf_a_imagen(factura_pdf)
        num_paginas_pdf = obtener_paginas_pdf(factura_pdf)

        # Controles de opciones de impresión
        opciones_impresion = ft.Column(
            [
                ft.Dropdown(
                    label="Destino",
                    options=[ft.dropdown.Option(imp) for imp in impresoras],
                ),
                ft.Dropdown(
                    label="Páginas",
                    options=[ft.dropdown.Option("Todo"), ft.dropdown.Option("Personalizado")],
                ),
                ft.TextField(label="Copias", value="1"),
                ft.Dropdown(
                    label="Color",
                    options=[ft.dropdown.Option("Color"), ft.dropdown.Option("Blanco y Negro")],
                ),
                ft.Text(f"{num_paginas_pdf} hojas de papel", color=ft.colors.GREY),
            ],
            spacing=10,
        )

        # Contenedor principal del modal
        modal_content = ft.Row(
            [
                # Vista del PDF a la izquierda
                ft.Container(
                    content=ft.Image(src=imagen_pdf, fit="contain", width=400, height=600),
                    padding=ft.Padding(top=0, right=20, bottom=0, left=0),
                    alignment=ft.alignment.center,
                ),
                # Controles de impresión a la derecha
                ft.Column(
                    [
                        ft.Text("Opciones de impresión", weight=ft.FontWeight.BOLD, size=18),
                        opciones_impresion,
                        ft.Row(
                            [
                                ft.ElevatedButton(
                                    text="Imprimir",
                                    icon=ft.icons.PRINT,
                                    on_click=lambda e: imprimir_factura(factura_pdf, opciones_impresion.controls[0].value),
                                    bgcolor=ft.colors.BLUE,
                                    color=ft.colors.WHITE,
                                ),
                                ft.ElevatedButton(
                                    text="Cancelar",
                                    icon=ft.icons.CANCEL,
                                    on_click=lambda e: cerrar(),
                                    bgcolor=ft.colors.RED,
                                    color=ft.colors.WHITE,
                                ),
                            ],
                            spacing=10,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=20,
                    width=300,
                ),
            ]
        )

        modal = ft.AlertDialog(
            title=ft.Text("Previsualización e impresión"),
            content=modal_content,
            actions_alignment=ft.MainAxisAlignment.END,
        )

        page.dialog = modal
        page.dialog.open = True
        page.update()
        
        def cerrar():
            page.dialog = modal
            page.dialog.open = False
            page.update()
    
  

    def exportar_excel(id):
        pass
        # Lógica para exportar factura a Excel


    def generar_pdf(id):
        
        # Lógica para generar un PDF de la factura
        pdf_file = f"factura_{id}.pdf"
        c = canvas.Canvas(pdf_file, pagesize=letter)
        width, height = letter

        # Encabezado del PDF
        c.setFillColor("#2196F3")
        c.setFont("Helvetica-Bold", 24)
        c.drawString(30, height - 50, "FACTURA")
        c.setFillColor(colors.black)

        # Información del emisor y cliente
        c.setFont("Helvetica", 12)
        c.drawString(30, height - 100, "Nombre del Negocio S.A.S")
        c.drawString(30, height - 115, "NIT: 123.456.789-0")
        c.drawString(30, height - 130, "Calle Falsa 123, Ciudad, Colombia")
        c.drawString(30, height - 145, "Tel: +57 300 123 4567 - Email: contacto@negocio.com")
        
        c.drawString(400, height - 100, "Cliente:")
        c.drawString(400, height - 115, "Nombre del Cliente")
        c.drawString(400, height - 130, "Identificación: 987654321")
        c.drawString(400, height - 145, "Dirección: Calle Ejemplo 456, Ciudad")

        # Información de la factura
        c.drawString(30, height - 170, f"Número de Factura: {id}")
        c.drawString(30, height - 185, "Fecha de Emisión: 22 / 10 / 2024")
        c.drawString(30, height - 200, "Tipo de Factura: Electrónica")

        # Dibujar tabla de productos
        y_position = height - 240
        c.setFont("Helvetica-Bold", 10)
        c.drawString(30, y_position, "No.")
        c.drawString(60, y_position, "Descripción del Producto/Servicio")
        c.drawString(300, y_position, "Precio Unitario")
        c.drawString(400, y_position, "Cantidad")
        c.drawString(470, y_position, "Total")
        y_position -= 20

        # Dibujar los productos
        data = [
            ["1", "Producto A", "100.000", "2", "200.000"],
            ["2", "Producto B", "80.000", "1", "80.000"],
        ]
        c.setFont("Helvetica", 10)
        for row in data:
            c.drawString(30, y_position, row[0])
            c.drawString(60, y_position, row[1])
            c.drawString(300, y_position, row[2])
            c.drawString(400, y_position, row[3])
            c.drawString(470, y_position, row[4])
            y_position -= 20

        # Resumen de precios
        c.setFont("Helvetica-Bold", 12)
        c.drawString(400, y_position - 40, "Subtotal: 530.000")
        c.drawString(400, y_position - 55, "IVA (19%): 100.700")
        c.drawString(400, y_position - 70, "Total a Pagar: 630.700")

        c.save()
        
        
        os.startfile(pdf_file)  

    def eliminar_factura(id):
        pass
        # Aquí iría la lógica para eliminar la factura

    vista_completa = ft.Column(
        [
            barra_superior,
            encabezado,
            ft.Container(
                content=contenido_facturas,
                expand=True,
            )
        ],
        expand=True,
    )
    
    actualizar_vista()

    return vista_completa
