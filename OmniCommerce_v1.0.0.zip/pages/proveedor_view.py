import flet as ft

from routes.proveedor import consulta_proveedor, eliminar_proveedor, actualizar_proveedor, buscar_proveedor, informacion_proveedor, registro_proveedor
from utils.mensajeAlerta import mostrar_alerta_auto
from models.proveedor import registro_de_proveedor
import datetime
import re


def proveedor_view(page):

    # Contenedor con desplazamiento para los usuarios
    contenido_usuarios = ft.Column(
        spacing=10,
        scroll="auto",
    )
    
 
    # Función para actualizar la vista de usuarios
    def actualizar_vista(e=None):
        # Limpiar la lista de controles antes de actualizar
        contenido_usuarios.controls.clear()

        if campo_buscar.value and len(campo_buscar.value) >= 4:
            usuarios_filtrados = buscar_proveedor(campo_buscar.value)
            
        else:

            usuarios_filtrados = consulta_proveedor()

        # Si no hay resultados de la búsqueda, mostrar un mensaje
        if not usuarios_filtrados:
            contenido_usuarios.controls.append(ft.Text("No hay resultados con esa búsqueda", color=ft.colors.RED))
        else:
            # Crear las filas para cada usuario encontrado
            for usuario in usuarios_filtrados:
                color_texto = "green" if usuario[12] == 'activo' else "red"
                def on_click_editar(e, user_id=usuario[0]):
                    actualizar_usuarios(page, user_id)
                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Row(
                                [
                                    ft.CircleAvatar(content=ft.Text(usuario[1][0], weight=ft.FontWeight.BOLD)),
                                    ft.Column(
                                        [
                                            ft.Text(usuario[1], weight=ft.FontWeight.BOLD),
                                            ft.Text(usuario[8]),
                                        ],
                                        spacing=2
                                    ),
                                ],
                                spacing=10,
                                alignment=ft.MainAxisAlignment.START
                            ),
                            padding=ft.Padding(top=10, right=10, bottom=10, left=10),
                            width=250,
                        ),
                        ft.Text(usuario[3], width=100),
                        ft.Text(usuario[7], width=100),
                        ft.Text(usuario[12], color=color_texto, width=80),
                        ft.Row(
                            [
                                    ft.IconButton(
                                        icon=ft.icons.DELETE_OUTLINED, 
                                        on_click=lambda e, id=usuario[0]: desativar_usuario(page, id),
                                        icon_color='red',
                                        # Deshabilitar botón si el usuario ya está desactivado
                                        disabled=not usuario[12]=='activo',
                                        tooltip="Usuario ya está desactivado" if not usuario[12] == 'activo' else "Desactivar usuario",
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.EDIT_OUTLINED, 
                                        on_click=on_click_editar,
                                        icon_color='blue'
                                    ),
                                    ft.IconButton(
                                        icon=ft.icons.INFO_OUTLINED, 
                                        on_click=lambda e, id=usuario[0]: ver_mas_info(page, id),
                                        icon_color= 'yellow'
                                    ),
                                ],
                            alignment=ft.MainAxisAlignment.END,
                            spacing=10
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                )
                contenido_usuarios.controls.append(fila)
        
        page.update()
        

        
        



    # Campo de búsqueda con icono
    campo_buscar = ft.TextField(
        hint_text="Buscar proveedor...",
        border_radius=10,
        width=350,
        height=40,
        prefix_icon=ft.icons.SEARCH,
        on_change=actualizar_vista,
    )

    # Botón para agregar usuario
    boton_agregar_usuario = ft.FloatingActionButton(
        text="Agregar Proveedor",
        icon=ft.icons.PERSON_ADD,
        bgcolor=ft.colors.BLUE,
        shape=ft.RoundedRectangleBorder(radius=15),
        on_click=lambda e: mostrar_modal(page),
        width=160,
        height=40,
        content=ft.Text("Agregar Proveedor", weight=ft.FontWeight.BOLD),
    )

    # Contenedor para la barra de búsqueda y el botón
    barra_superior = ft.Container(
        content=ft.Row(
            [
                campo_buscar,
                boton_agregar_usuario,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        ),
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
    )

    # Contenedor para el encabezado (fijo)
    encabezado = ft.Container(
        content=ft.Row(
            [
                ft.Text("Nombre", weight=ft.FontWeight.BOLD, width=225),
                ft.Text("Documento", weight=ft.FontWeight.BOLD, width=100),
                ft.Text("telefono", weight=ft.FontWeight.BOLD, width=90),
                ft.Text("Estado", weight=ft.FontWeight.BOLD, width=105),
                ft.Text("Acciones", weight=ft.FontWeight.BOLD, width=100),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        bgcolor=ft.colors.BLUE_GREY_100,
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
        border_radius=10,
        margin=ft.Margin(top=10, right=10, bottom=10, left=10),
    )

    # Combinación de barra superior, encabezado fijo, y contenido desplazable
    vista_completa = ft.Column(
        [
            barra_superior,
            encabezado,
            ft.Container(
                content=contenido_usuarios,
                expand=True,
            )
        ],
        expand=True,
    )



    #DESACTIVAR USARIOS
    def desativar_usuario(page, id):
        
        # Crear un cuadro de diálogo de confirmación
        dialogo_confirmacion = ft.AlertDialog(
            title=ft.Text("Confirmar Eliminación", weight=ft.FontWeight.BOLD),
            content=ft.Text("¿Estás seguro de que deseas eliminar este proveedor?"),
            actions=[
                ft.ElevatedButton(
                    text="Cancelar",
                    on_click=lambda e: cerrar_dialogo(page)
                ),
                ft.ElevatedButton(
                    text="Eliminar",
                    on_click=lambda e: confirmar_eliminacion(page, id),
                     bgcolor=ft.colors.RED, 
                    color=ft.colors.WHITE
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )

        # Mostrar el diálogo
        page.dialog = dialogo_confirmacion
        dialogo_confirmacion.open = True
        page.update()

    
    #CERRA MODAL
    def cerrar_dialogo(page):
        # Cierra el cuadro de diálogo
        page.dialog.open = False
        page.update()
    
    #CONFIRMACION DE ELIMINAR USUARUIOS 
    def confirmar_eliminacion(page, id):
        try:
            eliminar_proveedor(id)
            actualizar_vista()
            cerrar_dialogo(page)
            page.update()

        except Exception as e:
            
            error_dialogo = ft.AlertDialog(
                title=ft.Text("Error"),
                content=ft.Text("Hubo un problema al eliminar el usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))]
            )
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()


    #ACTUALIZAR USUARIOS
    def actualizar_usuarios(page, user_id):
        # Obtener los datos del usuario actual
        usuario = informacion_proveedor(user_id)
    
        if usuario is None:
            
            return

        def guardar_cambios(e):
            nuevos_datos = {
                "correo_proveedor": correo_usuario.value,
                "telefono_proveedor": telefono_usuario.value,
                #"telefono_usuario2": telefono_usuario2.value,
                "direccion_proveedor": direccion_usuario.value,
                "cuidad_proveedo": ciudad_usuario.value,
                #"rol_usuario": rol_usuario.value
            }

            # Lógica para guardar los cambios en la base de datos
            actualizar = actualizar_proveedor(user_id, nuevos_datos["telefono_proveedor"],  nuevos_datos["direccion_proveedor"], nuevos_datos["cuidad_proveedo"], nuevos_datos["correo_proveedor"])   
            if actualizar:
                cerrar_dialogo(page)  
                mostrar_alerta_auto(page, "Actualizacion exitosa", f"El Proveedor {usuario['nombre_proveedor']}, ha sido modificado con exito", duracion=3) 
                actualizar_vista()
                page.update()
            else:
                mostrar_alerta_auto(page, "Error de actualizacion", f"El proveedor {usuario['nombre_proveedor']}, no pudo ser modificado, por favor intentalo nuevamente", duracion=3)




        # Campos editables
        correo_usuario = ft.TextField(
            label="Correo Electrónico",
            value=usuario["correo_proveedor"],
            hint_text="Ingrese el nuevo correo",
            width=250
        )

        telefono_usuario = ft.TextField(
            label="Teléfono",
            value=usuario["telefono_proveedor"],
            hint_text="Ingrese el nuevo teléfono",
            width=250
        )


        direccion_usuario = ft.TextField(
            label="Dirección",
            value=usuario["direccion_proveedor"],
            hint_text="Ingrese la nueva dirección",
            width=250
        )

        ciudad_usuario = ft.TextField(
            label="Ciudad",
            value=usuario["cuidad_proveedor"],
            hint_text="Ingrese la nueva ciudad",
            width=250
        )



        columna_izquierda = ft.Column(
            controls=[
                correo_usuario,
                telefono_usuario
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        columna_derecha = ft.Column(
            controls=[
                direccion_usuario,
                ciudad_usuario
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        # Crear una fila que contenga las dos columnas
        fila = ft.Row(
            controls=[
                columna_izquierda,
                columna_derecha
            ],
            spacing=20,
            alignment=ft.MainAxisAlignment.START
        )

        boton_cerrar = ft.IconButton(
        icon=ft.icons.CLOSE,
        icon_size=20,
        icon_color=ft.colors.RED,  # 'X' en rojo
        on_click=lambda e: cerrar_dialogo(page),
        )


        # Crear el diálogo
        page.dialog = ft.AlertDialog(
            title=ft.Row(
                    [
                        ft.Text("Actualizar proveedor", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
            content=ft.Container(
                content=fila,
                padding=10,
                width=540,  # Ajustar el ancho del contenedor para mantener el diseño
                height=280
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: cerrar_dialogo(page)),
                ft.TextButton("Guardar", on_click=guardar_cambios),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
            modal=True
)

        page.dialog.open = True
        page.update()




    def ver_mas_info(page, id):
        try:
            # Obtener todos los usuarios
            usuarios = consulta_proveedor()

            # Encontrar el usuario por ID
            usuario = next((u for u in usuarios if u[0] == id), None)

            if usuario is None:
                raise ValueError("Usuario no encontrado.")

            # Mapear los datos del usuario
            datos_usuario = {
                "Nombre:": f"{usuario[1]} {usuario[2]}",
                "Documento:": usuario[3],
                "Tipo de Documento:": usuario[4],
                "Correo:": usuario[8],
                "Teléfono:": usuario[7],
                "Dirección:": usuario[6],
                "Ciudad:": usuario[5],
                "Fecha de Creación:": usuario[11],
                "Persona de registro:": f" {usuario[9]} {usuario[10]}",
                "Estado de usuario:": usuario[12]
            }

            # Crear filas con 6 elementos por fila
            filas = []
            items = list(datos_usuario.items())
            for i in range(0, len(items), 2):
                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(
                                        campo,
                                        weight=ft.FontWeight.BOLD,  # Campo en negrita
                                        size=16,  # Tamaño de letra más grande
                                        color=ft.colors.BLUE_GREY_700  # Color identificador
                                    ),
                                    ft.Text(
                                        valor,
                                        weight=ft.FontWeight.NORMAL,
                                        size=14,  # Aumentar un poco el tamaño del valor
                                        color=ft.colors.BLACK  # Color para diferenciar
                                    )
                                ],
                                spacing=2
                            ),
                            padding=ft.padding.only(left=5, right=5),
                            expand=True,
                        )
                        for campo, valor in items[i:i + 2]
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=10
                )
                filas.append(fila)

            # Crear contenido del diálogo
            contenido = ft.Column(
                filas,
                spacing=5
            )

            boton_cerrar = ft.IconButton(
            icon=ft.icons.CLOSE,
            icon_size=20,
            icon_color=ft.colors.RED,  # 'X' en rojo
            on_click=lambda e: cerrar_dialogo(page),
            )

            # Crear el diálogo
            dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Row(
                    [
                        ft.Text("Detalles del Usuario", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                content=ft.Container(
                    content=contenido,
                    padding=ft.padding.all(10),
                    width=600,  # Ajusta el ancho total del modal según sea necesario
                    height=300
                ),
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo
            page.dialog = dialogo
            dialogo.open = True
            page.update()



        except Exception as e:
            
            # Diálogo de error
            error_dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Text("Error", weight=ft.FontWeight.BOLD, color=ft.colors.RED),
                content=ft.Text("Hubo un problema al obtener la información del usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))],
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo de error
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()


    
    def mostrar_modal(page):
        def cerrar_modal(e=None):
            page.dialog.open = False
            page.update()

        def validar_campo(campo, validacion_funcion, mensaje_error):
            """ Valida un campo y actualiza el mensaje de error si es necesario. """
            if campo.value:  # Validar solo si hay texto ingresado
                if validacion_funcion(campo):
                    campo.error_text = None
                else:
                    campo.error_text = mensaje_error
            else:
                campo.error_text = None  # No mostrar error si no hay texto
            page.update()

        def actualizar_progreso(e=None):
            # Validación de campos con errores dinámicos solo al ingresar texto
            for campo, validacion_funcion, mensaje_error in validaciones:
                validar_campo(campo, validacion_funcion, mensaje_error)

            # Contar campos obligatorios completados
            completados = sum(1 for campo in campos_obligatorios if campo.value)

            # Actualizar el valor de la barra de progreso
            progreso.value = completados / len(campos_obligatorios)

            # Desactivar botón de guardar si no se han completado todos los campos obligatorios o si hay errores
            boton_guardar.disabled = completados < len(campos_obligatorios) or any(
                campo.error_text for campo, _, _ in validaciones
            )

            page.update()

        def registrar_empresa_y_administrador(e):
            registro = registro_de_proveedor(
                nombre_proveedor.value,
                apellido_proveedor.value,
                documento_proveedor.value,
                tipo_documento_proveedor.value,
                cuidad_proveedor.value,
                direccion_proveedor.value,
                telefono_proveedor.value,
                correo_proveedor.value,
                fecha_registro = datetime.datetime.now(),
            )

            if registro:
                cerrar_modal()
                actualizar_vista()
                mostrar_alerta_auto(page, "Proveedor creado", "Proveedor creado exitosamente", duracion=3)           
                page.update() 
            else:
                mostrar_alerta_auto(page, "Error de registro", "El Proveedor no ha podido ser registrado", duracion=3)
            page.update()


        progreso = ft.ProgressBar(width=300, height=20, color=ft.colors.GREEN, bgcolor=ft.colors.LIGHT_GREEN)

        
        nombre_proveedor = ft.TextField(label="Nombre de proveerdor", on_change=actualizar_progreso)
        apellido_proveedor = ft.TextField(label="Apellido de proveedor", on_change=actualizar_progreso)
        documento_proveedor = ft.TextField(label="Documento de proveedor", on_change=actualizar_progreso)
        tipo_documento_proveedor = ft.Dropdown(
            label="Tipo de Documento", on_change=actualizar_progreso,
            options=[
                ft.dropdown.Option("Cédula de Ciudadanía"),
                ft.dropdown.Option("Pasaporte"),
                ft.dropdown.Option("Tarjeta de Identidad"),
            ],
        )
        correo_proveedor = ft.TextField(label="Correo Electrónico", on_change=actualizar_progreso)
        telefono_proveedor = ft.TextField(label="Teléfono", on_change=actualizar_progreso)
        direccion_proveedor = ft.TextField(label="Dirección (opcional)", on_change=actualizar_progreso)
        cuidad_proveedor= ft.TextField(label="Ciudad", on_change=actualizar_progreso)


        
        campos_obligatorios = [nombre_proveedor , apellido_proveedor, documento_proveedor, correo_proveedor, tipo_documento_proveedor, telefono_proveedor, cuidad_proveedor]

        
        validaciones = [
            (nombre_proveedor , lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
            (apellido_proveedor, lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
            (documento_proveedor, lambda campo: campo.value.isdigit() and len(campo.value) >= 8, "Debe ser numérico y tener al menos 8 dígitos"),
            (correo_proveedor, lambda campo: re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", campo.value) is not None, "Correo inválido"),
            (telefono_proveedor, lambda campo: campo.value.isdigit() and 10 <= len(campo.value) <= 12, "Debe tener entre 10 y 12 dígitos"),
        ]

        
        boton_guardar = ft.ElevatedButton("Guardar", on_click=registrar_empresa_y_administrador, disabled=True)
        boton_cancelar = ft.TextButton("Cancelar", on_click=cerrar_modal)

        
        modal = ft.AlertDialog(
            title=ft.Row(
                [
                    ft.Text("Agregar Proveedor", weight=ft.FontWeight.BOLD, size=20),
                    ft.IconButton(icon=ft.icons.CLOSE, icon_color=ft.colors.RED, on_click=cerrar_modal),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        progreso,
                        ft.Row([nombre_proveedor , apellido_proveedor]),
                        ft.Row([tipo_documento_proveedor, correo_proveedor]),
                        ft.Row([documento_proveedor, telefono_proveedor]),
                        ft.Row([cuidad_proveedor, direccion_proveedor]),
                    ],
                    spacing=10,
                    scroll="auto",
                ),
                padding=10,
                width=630,
            ),
            actions=[
                boton_cancelar,
                boton_guardar,
            ],
            modal=True,
            on_dismiss=cerrar_modal,
            shape=ft.RoundedRectangleBorder(radius=10),
            bgcolor=ft.colors.WHITE,
        )

        # Mostrar modal
        actualizar_progreso()
        page.dialog = modal
        modal.open = True
        page.update()


    actualizar_vista()
    
    return vista_completa

