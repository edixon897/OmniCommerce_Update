import flet as ft
#from utils.clienteAgg import mostrar_modal
from routes.clientes import consulta_cliente, eliminar_cliente, actualizar_cliente, informacion_cliente, buscar_cliente
from utils.mensajeAlerta import mostrar_alerta_auto
from models.clientes import registro_de_clientes

import datetime
import re


def cliente_view(page):
    # Contenedor con desplazamiento para los usuarios
    contenido_usuarios = ft.Column(
        spacing=10,
        scroll="auto",
    )

   # VISTA DE LOS USUARIOS REGISTRADOS
    def actualizar_vista(e=None):
        # Si el campo de búsqueda tiene al menos 4 caracteres, realizar la búsqueda
        if campo_buscar.value and len(campo_buscar.value) >= 4:
            # Realizar la búsqueda en la base de datos por nombre o documento
            usuarios_filtrados = buscar_cliente(nombre_cliente=campo_buscar.value)
        else:
            # Si no se busca nada o la búsqueda es muy corta, mostrar todos los usuarios
            usuarios_filtrados = consulta_cliente()

        # Limpia la lista de controles antes de actualizar
        contenido_usuarios.controls.clear()

        # Si no hay resultados de la búsqueda o consulta, mostrar un mensaje
        if not usuarios_filtrados:
            contenido_usuarios.controls.append(ft.Text("No hay resultados con esa búsqueda", color=ft.colors.RED))
        else:
            # Crear las filas para cada usuario encontrado
            for usuario in usuarios_filtrados:
                color_texto = "green" if usuario[12] == 'activo' else "red"

                def on_click_editar(e, user_id=usuario[0]):
                    actualizar_usuarios(page, user_id)

                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Row(
                                [
                                    ft.CircleAvatar(content=ft.Text(usuario[1][0], weight=ft.FontWeight.BOLD)),
                                    ft.Column(
                                        [
                                            ft.Text(usuario[1], weight=ft.FontWeight.BOLD),
                                            ft.Text(usuario[6]),
                                        ],
                                        spacing=2
                                    ),
                                ],
                                spacing=10,
                                alignment=ft.MainAxisAlignment.START
                            ),
                            padding=ft.Padding(top=10, right=10, bottom=10, left=10),
                            width=250,
                        ),
                        ft.Text(usuario[3], width=100),
                        ft.Text(usuario[5], width=100),
                        ft.Text(usuario[12], color=color_texto, width=80),
                        ft.Row(
                            [
                                ft.IconButton(
                                    icon=ft.icons.DELETE_OUTLINED,
                                    on_click=lambda e, id=usuario[0]: desactivar_usuario(page, id),
                                    icon_color='red',
                                    disabled=not usuario[12] == 'activo',
                                    tooltip="Usuario ya está desactivado" if not usuario[12] == 'activo' else "Desactivar usuario",
                                ),
                                ft.IconButton(
                                    icon=ft.icons.EDIT_OUTLINED,
                                    on_click=on_click_editar,
                                    icon_color='blue'
                                ),
                                ft.IconButton(
                                    icon=ft.icons.INFO_OUTLINED,
                                    on_click=lambda e, id=usuario[0]: ver_mas_info(page, id),
                                    icon_color='yellow'
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.END,
                            spacing=10
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10
                )
                contenido_usuarios.controls.append(fila)

        page.update()

    # Campo de búsqueda con icono
    campo_buscar = ft.TextField(
        hint_text="Buscar usuario...",
        border_radius=10,
        width=350,
        height=40,
        prefix_icon=ft.icons.SEARCH,
        on_change=actualizar_vista,
    )

    # Botón para agregar usuario
    boton_agregar_usuario = ft.FloatingActionButton(
        text="Agregar Cliente",
        icon=ft.icons.PERSON_ADD,
        bgcolor=ft.colors.BLUE,
        shape=ft.RoundedRectangleBorder(radius=15),
        on_click=lambda e: mostrar_modal(page),
        width=160,
        height=40,
        content=ft.Text("Agregar Cliente", weight=ft.FontWeight.BOLD),
    )

    # Contenedor de la barra de búsqueda y el botón
    barra_superior = ft.Container(
        content=ft.Row(
            [
                campo_buscar,
                boton_agregar_usuario,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        ),
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
    )

    # Contenedor del encabezado
    encabezado = ft.Container(
        content=ft.Row(
            [
                ft.Text("Usuario", weight=ft.FontWeight.BOLD, width=225),
                ft.Text("Cuidad/Lugar", weight=ft.FontWeight.BOLD, width=100),
                ft.Text("Teléfono", weight=ft.FontWeight.BOLD, width=90),
                ft.Text("Estado", weight=ft.FontWeight.BOLD, width=105),
                ft.Text("Acciones", weight=ft.FontWeight.BOLD, width=100),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        bgcolor=ft.colors.BLUE_GREY_100,
        padding=ft.Padding(top=10, right=10, bottom=10, left=10),
        border_radius=10,
        margin=ft.Margin(top=10, right=10, bottom=10, left=10),
    )

    # Combinación de barra superior, encabezado fijo, y contenido desplazable
    vista_completa = ft.Column(
        [
            barra_superior,
            encabezado,
            ft.Container(
                content=contenido_usuarios,
                expand=True,
            )
        ],
        expand=True,
    )





    #DESACTIVAR USARIOS
    def desactivar_usuario(page, id):
       
        # Crear un cuadro de diálogo de confirmación
        dialogo_confirmacion = ft.AlertDialog(
            title=ft.Text("Confirmar Eliminación",  weight=ft.FontWeight.BOLD),
            content=ft.Text("¿Estás seguro de que deseas eliminar este usuario?"),
            actions=[
                ft.ElevatedButton(
                    text="Cancelar",
                    on_click=lambda e: cerrar_dialogo(page)
                ),
                ft.ElevatedButton(
                    text="Eliminar",
                    on_click=lambda e: confirmar_eliminacion(page, id),
                    bgcolor=ft.colors.RED,
                    color=ft.colors.WHITE
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )

        # Mostrar el diálogo
        page.dialog = dialogo_confirmacion
        dialogo_confirmacion.open = True
        page.update()

    
    #CERRA MODAL
    def cerrar_dialogo(page):
        # Cierra el cuadro de diálogo
        page.dialog.open = False
        page.update()
    
    #CONFIRMACION DE ELIMINAR USUARUIOS 
    def confirmar_eliminacion(page, id):
        try:
            eliminar_cliente(id)
            cerrar_dialogo(page)
            actualizar_vista()
            page.update()

        except Exception as e:
            
            error_dialogo = ft.AlertDialog(
                title=ft.Text("Error"),
                content=ft.Text("Hubo un problema al eliminar el usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))]
            )
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()


    #ACTUALIZAR USUARIOS
    def actualizar_usuarios(page, user_id):
        # Obtener los datos del usuario actual
        usuario = informacion_cliente(user_id)
    
        if usuario is None:
            
            return None

        def guardar_cambios(e):
            # Recoger los nuevos valores de los campos modificables
            nuevos_datos = {
                "correo_cliente": correo_usuario.value,
                "telefono_cliente": telefono_usuario.value,
                "direccion_cliente": direccion_usuario.value,
                "cuidad_cliente": ciudad_usuario.value,
                
            }

            # Lógica para guardar los cambios en la base de datos
            actualizar = actualizar_cliente(user_id, nuevos_datos["telefono_cliente"], nuevos_datos["direccion_cliente"], nuevos_datos["cuidad_cliente"], nuevos_datos["correo_cliente"])  # Aquí deberías implementar esta lógica
            if actualizar:
                cerrar_dialogo(page)  # Cierra el diálogo primero
                mostrar_alerta_auto(page, "Actualizacion exitosa", f"El usuario {usuario['nombre_cliente']}, ha sido modificado con exito", duracion=2) 
                actualizar_vista()
                page.update()
            else:
                mostrar_alerta_auto(page, "Error de actualizacion", f"El usuario {usuario['nombre_cliente']}, no pudo ser modificado, por favor intentalo nuevamente", duracion=2)




        # Campos editables
        correo_usuario = ft.TextField(
            label="Correo Electrónico",
            value=usuario["correo_cliente"],
            hint_text="Ingrese el nuevo correo",
            width=250
        )

        telefono_usuario = ft.TextField(
            label="telefono_cliente",
            value=usuario["telefono_cliente"],
            hint_text="Ingrese el nuevo teléfono",
            width=250
        )



        direccion_usuario = ft.TextField(
            label="Dirección",
            value=usuario["direccion_cliente"],
            hint_text="Ingrese la nueva dirección",
            width=250
        )

        ciudad_usuario = ft.TextField(
            label="Ciudad",
            value=usuario["cuidad_cliente"],
            hint_text="Ingrese la nueva ciudad",
            width=250
        )

        
        columna_izquierda = ft.Column(
            controls=[
                correo_usuario,
                telefono_usuario,
                
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        columna_derecha = ft.Column(
            controls=[
                direccion_usuario,
                ciudad_usuario,
                
            ],
            spacing=10,
            alignment=ft.MainAxisAlignment.START
        )

        # Crear una fila que contenga las dos columnas
        fila = ft.Row(
            controls=[
                columna_izquierda,
                columna_derecha
            ],
            spacing=20,
            alignment=ft.MainAxisAlignment.START
        )

        boton_cerrar = ft.IconButton(
        icon=ft.icons.CLOSE,
        icon_size=20,
        icon_color=ft.colors.RED,  
        on_click=lambda e: cerrar_dialogo(page),
        )


        # Crear el diálogo
        page.dialog = ft.AlertDialog(
            title=ft.Row(
                    [
                        ft.Text("Actualizar Cliente", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
            content=ft.Container(
                content=fila,
                padding=10,
                width=540,  # Ajustar el ancho del contenedor para mantener el diseño
                height=280
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: cerrar_dialogo(page)),
                ft.TextButton("Guardar", on_click=guardar_cambios),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
            modal=True
)

        page.dialog.open = True
        page.update()




    def ver_mas_info(page, id):
        try:
            # Obtener todos los usuarios
            usuarios = consulta_cliente()

            # Encontrar el usuario por ID
            usuario = next((u for u in usuarios if u[0] == id), None)

            if usuario is None:
                raise ValueError("Usuario no encontrado.") 
            

            datos_usuario = {
                "Nombre:": f"{usuario[1]} {usuario[2]}",
                "Documento:": usuario[8],
                "Tipo de Documento:": usuario[7],
                "Correo Eletronico:": usuario[6],
                "Teléfono:": usuario[5],
                "Dirección:": usuario[4],
                "Ciudad:": usuario[3],
                "Fecha de Creación:": usuario[11],
                "Usuario de registro": f" {usuario[9]} {usuario[10]}",
                "Estado de usuario:":  usuario[12] 
            }

            # Crear filas con 6 elementos por fila
            filas = []
            items = list(datos_usuario.items())
            for i in range(0, len(items), 2):
                fila = ft.Row(
                    [
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(
                                        campo,
                                        weight=ft.FontWeight.BOLD,  # Campo en negrita
                                        size=16,  # Tamaño de letra más grande
                                        color=ft.colors.BLUE_GREY_700  # Color identificador
                                    ),
                                    ft.Text(
                                        valor,
                                        weight=ft.FontWeight.NORMAL,
                                        size=14,  # Aumentar un poco el tamaño del valor
                                        color=ft.colors.BLACK  # Color para diferenciar
                                    )
                                ],
                                spacing=2
                            ),
                            padding=ft.padding.only(left=5, right=5),
                            expand=True,
                        )
                        for campo, valor in items[i:i + 2]
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=10
                )
                filas.append(fila)

            # Crear contenido del diálogo
            contenido = ft.Column(
                filas,
                spacing=5
            )

            boton_cerrar = ft.IconButton(
            icon=ft.icons.CLOSE,
            icon_size=20,
            icon_color=ft.colors.RED,  # 'X' en rojo
            on_click=lambda e: cerrar_dialogo(page),
            )

            # Crear el diálogo
            dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Row(
                    [
                        ft.Text("Detalles del Usuario", weight=ft.FontWeight.BOLD, size=22),
                        ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)  # 'X' arriba a la derecha
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                content=ft.Container(
                    content=contenido,
                    padding=ft.padding.all(10),
                    width=600,  # Ajusta el ancho total del modal según sea necesario
                    height=300
                ),
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo
            page.dialog = dialogo
            dialogo.open = True
            page.update()



        except Exception as e:
    
            # Diálogo de error
            error_dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Text("Error", weight=ft.FontWeight.BOLD, color=ft.colors.RED),
                content=ft.Text("Hubo un problema al obtener la información del usuario."),
                actions=[ft.TextButton(text="OK", on_click=lambda e: cerrar_dialogo(page))],
                actions_alignment=ft.MainAxisAlignment.END,
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=ft.colors.WHITE,
            )

            # Mostrar el diálogo de error
            page.dialog = error_dialogo
            error_dialogo.open = True
            page.update()
    


    #CREAR CLIENTES
    def mostrar_modal(page):
        def cerrar_modal(e=None):
            page.dialog.open = False
            page.update()

        def validar_campo(campo, validacion_funcion, mensaje_error):
            """ Valida un campo y actualiza el mensaje de error si es necesario. """
            if campo.value:  # Validar solo si hay texto ingresado
                if validacion_funcion(campo):
                    campo.error_text = None
                else:
                    campo.error_text = mensaje_error
            else:
                campo.error_text = None  # No mostrar error si no hay texto
            page.update()

        def actualizar_progreso(e=None):
            # Validación de campos con errores dinámicos solo al ingresar texto
            for campo, validacion_funcion, mensaje_error in validaciones:
                validar_campo(campo, validacion_funcion, mensaje_error)

            # Contar campos obligatorios completados
            completados = sum(1 for campo in campos_obligatorios if campo.value)

            # Actualizar el valor de la barra de progreso
            progreso.value = completados / len(campos_obligatorios)

            # Desactivar botón de guardar si no se han completado todos los campos obligatorios o si hay errores
            boton_guardar.disabled = completados < len(campos_obligatorios) or any(
                campo.error_text for campo, _, _ in validaciones
            )

            page.update()

        def registrar_empresa_y_administrador(e):
            #r, fecha_creacion
            registro = registro_de_clientes(
                nombre_cliente.value,
                apellido_cliente.value,
                cuidad_cliente.value,
                direccion_cliente.value,
                telefono_cliente.value,
                correo_cliente.value,
                tipo_documento.value,
                documento_cliente.value,
                fecha_creacion = datetime.datetime.now(),
            )

            if registro:
                cerrar_modal()
                mostrar_alerta_auto(page, "Usuario creado", "Cliente creado exitosamente", duracion=2)  
                actualizar_vista()
                page.update()         
            else:
                mostrar_alerta_auto(page, "Error de registro", "El cliente no ha podido ser registrado", duracion=2)


        progreso = ft.ProgressBar(width=300, height=20, color=ft.colors.GREEN, bgcolor=ft.colors.LIGHT_GREEN)

        # Campos de formulario
        nombre_cliente = ft.TextField(label="Nombre", on_change=actualizar_progreso)
        apellido_cliente = ft.TextField(label="Apellido", on_change=actualizar_progreso)
        documento_cliente = ft.TextField(label="Documento", on_change=actualizar_progreso)
        tipo_documento = ft.Dropdown(
            label="Tipo de Documento", on_change=actualizar_progreso,
            options=[
                ft.dropdown.Option("Cédula de Ciudadanía"),
                ft.dropdown.Option("Pasaporte"),
                ft.dropdown.Option("Tarjeta de Identidad"),
            ],
        )
        correo_cliente = ft.TextField(label="Correo Electrónico", on_change=actualizar_progreso)
        telefono_cliente = ft.TextField(label="Teléfono", on_change=actualizar_progreso)
        direccion_cliente = ft.TextField(label="Dirección (opcional)", on_change=actualizar_progreso)
        cuidad_cliente = ft.TextField(label="Ciudad", on_change=actualizar_progreso)


        # Campos obligatorios para validación de progreso
        campos_obligatorios = [nombre_cliente, apellido_cliente, documento_cliente, correo_cliente, tipo_documento, telefono_cliente, cuidad_cliente]

        # Validaciones y mensajes de error dinámicos
        validaciones = [
            (nombre_cliente, lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
            (apellido_cliente, lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
            (documento_cliente, lambda campo: campo.value.isdigit() and len(campo.value) >= 8, "Debe ser numérico y tener al menos 8 dígitos"),
            (correo_cliente, lambda campo: re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", campo.value) is not None, "Correo inválido"),
            (telefono_cliente, lambda campo: campo.value.isdigit() and 10 <= len(campo.value) <= 12, "Debe tener entre 10 y 12 dígitos"),
        ]

        # Botones de acción
        boton_guardar = ft.ElevatedButton("Guardar", on_click=registrar_empresa_y_administrador, disabled=True)
        boton_cancelar = ft.TextButton("Cancelar", on_click=cerrar_modal)

        # Layout del modal
        modal = ft.AlertDialog(
            title=ft.Row(
                [
                    ft.Text("Agregar Usuario", weight=ft.FontWeight.BOLD, size=20),
                    ft.IconButton(icon=ft.icons.CLOSE, icon_color=ft.colors.RED, on_click=cerrar_modal),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        progreso,
                        ft.Row([nombre_cliente, apellido_cliente]),
                        ft.Row([tipo_documento, correo_cliente]),
                        ft.Row([documento_cliente, telefono_cliente]),
                        ft.Row([cuidad_cliente, direccion_cliente]),
                    ],
                    spacing=10,
                    scroll="auto",
                ),
                padding=10,
                width=630,
            ),
            actions=[
                boton_cancelar,
                boton_guardar,
            ],
            modal=True,
            on_dismiss=cerrar_modal,
            shape=ft.RoundedRectangleBorder(radius=10),
            bgcolor=ft.colors.WHITE,
        )

        # Mostrar modal
        actualizar_progreso()
        page.dialog = modal
        modal.open = True
        page.update()

    
    
    actualizar_vista()
    
    return vista_completa
