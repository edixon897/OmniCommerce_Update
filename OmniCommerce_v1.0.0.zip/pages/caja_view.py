import flet as ft
from flet import Container, Page, Row, Text, border, colors, KeyboardEvent
from routes.caja_registradora import registro_caja, consulta_caja, informacion_caja, actualizar_caja, eliminar_caja, informacion_detalle
from utils.mensajeAlerta import mostrar_alerta_auto
import datetime
from utils.usuarioSesion import estado_global


class ButtonControl(Container):
    def __init__(self, text):
        super().__init__()
        self.content = Text(text)
        self.border = border.all(1, colors.BLACK54)
        self.border_radius = 3
        self.bgcolor = "0x09000000"
        self.padding = 10
        self.visible = False



def caja_view(page: ft.Page):

    
    agregar_caja = ft.FloatingActionButton(
        text="Crear Caja",
        icon=ft.icons.PERSON_ADD,
        bgcolor=ft.colors.BLUE,
        shape=ft.RoundedRectangleBorder(radius=15),
        on_click=lambda e: crear_caja(page),
        width=160,
        height=40,
        content=ft.Text("Crear Caja", weight=ft.FontWeight.BOLD),
    )


    
    def crear_caja_registro(caja):
        """Crea una tarjeta para un registro de caja específico."""
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text("Saldo de Caja", size=20, weight="bold"),
                    ft.Text(f"${caja[3]:,.2f}", size=26, weight="bold", color=ft.colors.GREEN_600),
                    ft.Text(f"Fecha {caja[2].strftime('%d-%m-%Y %H:%M')}", size=15, color=ft.colors.BLACK54),
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.IconButton(
                                    icon=ft.icons.DELETE, tooltip="Eliminar", data="Eliminar caja", on_click=lambda e: eliminar_caja_registro(caja[0])
                                ),
                                bgcolor=ft.colors.RED_100,
                                border_radius=10,
                                padding=8,
                            ),
                            ft.Container(
                                content=ft.IconButton(
                                    icon=ft.icons.ADD, tooltip="Agregar Más", data="Agregar Más", on_click=lambda e: agregar_cantida(page, caja[0])
                                ),
                                bgcolor=ft.colors.GREEN_100,
                                border_radius=10,
                                padding=8,
                            ),
                            ft.Container(
                                content=ft.IconButton(
                                    icon=ft.icons.INFO, tooltip="Ver Información", data="Información", on_click=lambda e: ver_mas(page, caja[0])
                                ),
                                bgcolor=ft.colors.YELLOW_100,
                                border_radius=10,
                                padding=8,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=10,
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=10,
            ),
            width=240,
            height=230,
            border_radius=15,
            bgcolor=ft.colors.WHITE,
            padding=10,
            shadow=ft.BoxShadow(spread_radius=2, blur_radius=8, color=ft.colors.BLACK12),
        )


    def cargar_tarjetas():
        registros_caja = consulta_caja()  # Recupera todos los registros desde la base de datos.
        return [crear_caja_registro(caja) for caja in registros_caja]


    # Crear la vista de cuadrícula con todas las tarjetas.
    lista_cajas = ft.GridView(
        expand=True,
        max_extent=260,
        padding=10,
        spacing=10,
        run_spacing=10,
        controls=cargar_tarjetas(),  # Carga las tarjetas en la cuadrícula.
    )
    
    barra_superior = ft.Row(
        [
            ft.TextField(
                hint_text="Buscar Caja...",
                border_radius=10,
                prefix_icon=ft.icons.SEARCH,
                width=370, visible=False
            ),
            
            
            agregar_caja,
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        spacing=10,
    )
    
    def guarda_caja(e):
        codigo_caj = codigo_caja.value
        # Lógica para guardar la categoría
        if cantidad_caja.value.strip() == "":
                cantidad_caja.error_text = "La cantidad inicial es obligatorio"
                cantidad_caja.update()
        else:
            if len(codigo_caj) > 0:
                codigo = codigo_caj
            else:
                codigo = f"C-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
            usuario = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
            fecha = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            saldo_inicial = cantidad_caja.value
            
            registro_caja(codigo, fecha, usuario, saldo_inicial)
            page.dialog.open = False
            lista_cajas.controls = cargar_tarjetas()  # Recarga las tarjetas.
            lista_cajas.update()  # Actualiza la vista.
            page.update()
            
            mostrar_alerta_auto(page, "Registro exitoso", f"Tu caja de hoy ha sido creada", duracion=2)

    # Función para cerrar el modal
    def cerra_modal_crear(e=None):
        page.dialog.open = False
        page.update()

    cantidad_caja = ft.TextField(
        label="Cantidad",
        hint_text="Ingrese la cantidad inicial",
        autofocus=True,
        error_text="",
        expand=True
    )
    
    codigo_caja = ft.TextField(
        label="Codigo de caja (opcional)",
        hint_text="Igresar codigo de caja (opcional)",
        multiline=True,
        expand=True
    )
    def crear_caja(page):
    
        modal = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                [
                    ft.Text("Crear nueva categoría", expand=True),
                    ft.IconButton(ft.icons.CLOSE, on_click=lambda e: cerra_modal_crear())  # Botón X para cerrar
                ]
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        cantidad_caja,
                        codigo_caja,
                    ],
                    tight=True,
                ),
                width=400,  # Ancho del contenido del modal
                height=150,  # Altura del contenido del modal
                padding=ft.padding.all(10),
            ),
            actions=[
                ft.ElevatedButton("Guardar", on_click=guarda_caja),
                ft.TextButton("Cancelar", on_click=lambda e: cerra_modal_crear())  # También cierra el modal
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        page.dialog = modal
        page.dialog.open = True
        page.update()
    
    def agregar_cantida(page, id_caja):
        caja = informacion_caja(id_caja)  # Obtener el producto por ID
       

        def actualiza_cantidad():
            try:
                if caja['id_registro']:  # Validar que el producto existe
                    id_caja = caja['id_registro']

                    can = int(cantidad.value)

                    # Actualizar la cantidad en la base de datos
                    actualizar_caja(id_caja, can)
                    lista_cajas.controls = cargar_tarjetas()  # Recarga las tarjetas.
                    lista_cajas.update()  # Actualiza la vista
                    
                    # Cerrar modal y actualizar la página
                    cerrar_modal_cantidad(page)
                    page.update()

            except ValueError:
                pass
            except Exception as e:
                pass

        # Campo de texto para ingresar la cantidad
        cantidad = ft.TextField(
            label="Cantidad",
            keyboard_type=ft.KeyboardType.NUMBER,
            width=200,
        )

        # Crear el modal de agregar cantidad
        modal_agregar_cantidad = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                [
                    ft.Text(f"Agregar cantidad", weight=ft.FontWeight.BOLD),
                    ft.IconButton(
                        icon=ft.icons.CLOSE,
                        on_click=lambda e: cerrar_modal_cantidad(page),
                        tooltip="Cerrar",
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=ft.Container(
                content=ft.Column(
                    [
                        ft.Text(f"Codigo de Caja: {caja['codigo_caja']}", size=16),
                        cantidad,
                    ],
                    spacing=20,
                ),
                width=400,
                height=150,
            ),
            actions=[
                ft.Row(
                    [
                        ft.ElevatedButton(
                            text="Cancelar",
                            on_click=lambda e: cerrar_modal_cantidad(page),
                        ),
                        ft.ElevatedButton(
                            text="Guardar",
                            on_click=lambda e: actualiza_cantidad(),
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.END,
                    spacing=10,
                )
            ],
            actions_alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        )

        # Mostrar el modal
        page.dialog = modal_agregar_cantidad
        modal_agregar_cantidad.open = True
        page.update()

    def cerrar_modal_cantidad(page):
        page.dialog.open = False
        page.update()

    def eliminar_caja_registro(id_caja):

        def eliminar_product(e):


                try:
                    # Aquí llamas tu función para eliminar el producto de la base de datos
                    eliminar_caja(id_caja)  
                    lista_cajas.controls = cargar_tarjetas()  # Recarga las tarjetas.
                    lista_cajas.update()  # Actualiza la vista
                    cerrar_modal()
                except Exception as e:
                    pass
                cerrar_modal()

        def cerrar_modal(e=None):
            # Ocultar el modal de confirmación
            page.dialog.open = False
            page.update()

        # Crear el contenido del modal
        modal = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirmación de eliminación", weight=ft.FontWeight.BOLD),
            content=ft.Text("¿Seguro que quieres eliminar esta Caja?"),
            actions=[
                ft.ElevatedButton(
                    "Cancelar", 
                    on_click=cerrar_modal
                ),
                ft.ElevatedButton(
                    "Eliminar", 
                    on_click=eliminar_product, 
                    bgcolor=ft.colors.RED, 
                    color=ft.colors.WHITE
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        # Asignar y mostrar el modal
        page.dialog = modal
        page.dialog.open = True
        page.update()


    def ver_mas(page, id):
        cerrar_modal(page)  # Cierra cualquier modal abierto previamente
        
        caja = informacion_caja(id)

        id_detalle = caja["codigo_caja"]
        

        if caja is None:
            
            return None
        
        # Coloco el "Código de Barras" en la posición correcta
        datos_caja = {
            "Codigo de Caja": caja["codigo_caja"],
            "Fecha de Registro": caja["fecha_hora"],
            "Usuario de Registro": caja["usuario_registro"],
            "Cantidad Vendida": caja["total_ventas"],
            "Total de Egresos": caja["egresos"],
            "Saldo de Inicio": caja["saldo_inicial"],
            "Saldo Final": caja["saldo_final"],
            "Total de Ingresos": caja["ingresos"],
            "estado de Caja": caja["estado_caja"],
            
        }
        filas = []
        items = list(datos_caja.items())

        # Agrupar elementos de dos en dos
        for i in range(0, len(items), 2):
            columnas = []
            for j in range(2):
                if i + j < len(items):
                    campo, valor = items[i + j]
                    columnas.append(
                        ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(
                                        campo,
                                        weight=ft.FontWeight.BOLD,
                                        size=16,
                                        color=ft.colors.BLUE_GREY_700
                                    ),
                                    ft.Text(
                                        valor,
                                        weight=ft.FontWeight.NORMAL,
                                        size=16,
                                        color=ft.colors.BLACK
                                    )
                                ],
                                spacing=2
                            ),
                            padding=ft.padding.only(left=5, right=5),
                            expand=True
                        )
                    )
            
            # Cada fila tiene dos columnas
            fila = ft.Row(
                columnas,
                alignment=ft.MainAxisAlignment.START,
                spacing=10
            )
            filas.append(fila)

        contenido = ft.Column(
            filas,
            spacing=4
        )

        boton_cerrar = ft.IconButton(
            icon=ft.icons.CLOSE,
            icon_size=20,
            icon_color=ft.colors.RED,  
            on_click=lambda e: cerrar_modal(page),
        )
        boton_ver_mas = ft.ElevatedButton(
            text="Ver más detalles",
            icon=ft.icons.SEARCH,
            style=ft.ButtonStyle(
                bgcolor=ft.colors.BLUE,
                color=ft.colors.WHITE,
            ),
            on_click=lambda e:  mostrar_modal_detalle(page, id_detalle),  
        )

        dialogo = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                [
                    ft.Text("Detalles de Caja Registradora", weight=ft.FontWeight.BOLD, size=22),
                    ft.Container(content=boton_cerrar, alignment=ft.alignment.top_right)
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
            ),
            content=ft.Container(
                content=contenido,
                padding=ft.padding.all(10),
                width=600,
                height=400,
            ),
            actions=[
                boton_ver_mas,
                ],
            actions_alignment=ft.MainAxisAlignment.END,
            shape=ft.RoundedRectangleBorder(radius=10),
            bgcolor=ft.colors.WHITE,
        )

        page.dialog = dialogo
        dialogo.open = True
        page.update()

    def cerrar_modal(e=None):
        page.dialog.open = False
        page.update()


    def mostrar_modal_detalle(page, id_detalle):

        datos = informacion_detalle(id_detalle)

        # Verifica si se encontraron datos
        if not datos:
            ft.Text("No se encontraron detalles para el ID proporcionado.")

        # Crea las filas para la tabla
        filas = [
            ft.Row([
                ft.Text(f"{detalle['id_factura']}", width=80),
                ft.Text(f"{detalle['ingresos']:,.2f}", width=80),
                ft.Text(f"{detalle['egresos']:,.2f}", width=80),
                ft.Text(f"{detalle['monto_pago']:,.2f}", width=80),
                ft.Text(detalle['fecha_hor'], width=140),
                ft.Text(detalle['usuario_venta'], width=140),
            ]) for detalle in datos
        ]

        # Modal
        modal = ft.AlertDialog(
            modal=True,
            content=ft.Container(
                content=ft.Column(
                    controls=[
                        # Encabezado del modal
                        ft.Row(
                            controls=[
                                ft.Text("Detalle Caja", size=20, weight=ft.FontWeight.BOLD),
                                ft.IconButton(
                                    icon=ft.icons.CLOSE,
                                    on_click=lambda e: cerrar_modal_detalle(),
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        ),
                        ft.Divider(),
                        # Encabezados de la tabla
                        ft.Row(
                            controls=[
                                ft.Text("ID Factura", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Ingresos", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Egresos", width=80, weight=ft.FontWeight.BOLD),
                                ft.Text("Monto de Pago", width=90, weight=ft.FontWeight.BOLD),
                                ft.Text("Fecha", width=140, weight=ft.FontWeight.BOLD),
                                ft.Text("Usuario", width=140, weight=ft.FontWeight.BOLD),
                            ],
                            alignment=ft.MainAxisAlignment.START,
                        ),
                        ft.Divider(),
                         # Contenedor desplazable solo para las filas
                        ft.Container(
                            content=ft.Column(
                                controls=filas,  # filas dinámicas
                                spacing=5,
                                scroll=ft.ScrollMode.AUTO,  # Habilito scroll 
                            ),
                            height=300,  # Ajusto el alto 
                        ),
                    ],
                ),
                height=400,
                width=600,
            ),
        )
        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal_detalle():
            modal.open = False
            page.update()


    
    def obtener_cajas_abiertas():
        # Simulando datos de la base de datos
        return [
            {"id": 1, "nombre": "Caja Principal"},
            {"id": 2, "nombre": "Caja Secundaria"},
        ]

    # Función para mostrar el modal de cierre de caja
    def mostrar_modal_cierre_caja(e: ft.KeyboardEvent):
        if e.key == "F4":  # Detecta si se presionó F4
            cajas_abiertas = obtener_cajas_abiertas()

            # Controles para las cajas abiertas
            checkboxes = [
                ft.Checkbox(label=f"[ ] {caja['nombre']} (ID: {caja['id']})", value=False)
                for caja in cajas_abiertas
            ]

            # Función para manejar el cierre de caja
            def cerrar_cajas(_):
                seleccionadas = [
                    caja["nombre"] for caja, checkbox in zip(cajas_abiertas, checkboxes) if checkbox.value
                ]
                if seleccionadas:
                    
                    # Aquí iría la lógica para cerrar las cajas en la base de datos
                    page.dialog.open = False
                    page.update()
                else:
                    return
            # Crear el modal
            modal = ft.AlertDialog(
                modal=True,
                content=ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("Cierre de Caja", size=20, weight=ft.FontWeight.BOLD),
                            ft.Divider(),
                            ft.Column(checkboxes, spacing=10),  # Lista de cajas abiertas
                            ft.Divider(),
                            ft.Row(
                                controls=[
                                    ft.ElevatedButton("Cerrar cajas seleccionadas", on_click=cerrar_cajas),
                                    ft.TextButton(
                                        "Cancelar",
                                        on_click=lambda _: setattr(page.dialog, "open", False),
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.END,
                            ),
                        ],
                    ),
                    padding=20,
                ),
            )
            page.dialog = modal
            modal.open = True
            page.update()


    # Función para manejar eventos de teclado
    page.on_keyboard_event = mostrar_modal_cierre_caja


                


            


    
    
    # Layout principal de la vista
    vista = ft.Column(
        [
            barra_superior,
            ft.Divider(),
            lista_cajas,  # Contenedor dinámico para múltiples cajas
        ],
        spacing=20,
    )

    return vista

