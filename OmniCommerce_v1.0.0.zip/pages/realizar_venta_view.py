import flet as ft
from routes.productos import buscar_producto_compra, informacion_producto
from routes.clientes import buscar_cliente, consulta_cliente
from routes.venta_producto import registro_venta, registro_detalle_venta, registro_cotizacion, registro_detalle_cotizacion
from routes.caja_registradora import registrar_detalle

from decimal import Decimal  
import datetime
from utils.usuarioSesion import estado_global
from automatizacion.genrador_factura import generar_codigo_factura_unico
import io
import base64
import win32print
import win32ui
import win32con
from PIL import Image, ImageDraw, ImageFont, ImageWin
from utils.clienteAgg import mostrar_modal


def realizar_venta_view(page: ft.Page):
    usuario_venta = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
    ventas = []  # Lista de productos vendidos
    
    

    # Contenedor que muestra el detalle de venta
    detalle_venta_contenedor = ft.Container(
        content=ft.Column(controls=[], spacing=5),
        height=300,
        padding=5,
    )
    

    


    subtotal_text = ft.Text("Subtotal: $0.00")
    descuento_text = ft.Text("Descuento: $0.00")
    total_text = ft.Text("Total: $0.00", size=20, weight=ft.FontWeight.BOLD)
    
    

    # Botones de realizar venta y cotización
    realizar_venta_btn = ft.ElevatedButton(
        text="Realizar Venta", 
        on_click=lambda _: realizar_venta(), 
        disabled=True, 
        bgcolor=ft.colors.BLUE, 
        color=ft.colors.WHITE
    )
    realizar_cotizacion_btn = ft.ElevatedButton(
        text="Realizar Cotización", 
        on_click=lambda _: crear_cotizacion(), 
        disabled=True,

    )

    # Actualiza el subtotal, descuento y total
    def actualizar_totales():
        global subtotal, descuento, total
        # Convertimos todos los totales a Decimal para asegurar consistencia
        subtotal = sum(Decimal(str(venta["total"])) for venta in ventas)
        descuento = Decimal("0.00") * subtotal if subtotal > Decimal("0.00") else Decimal("0.00")
        total = subtotal - descuento

        # Actualizamos los textos en la interfaz con formato apropiado
        subtotal_text.value = f"Subtotal: ${subtotal:,.2f}"
        descuento_text.value = f"Descuento: ${descuento:,.2f}"
        total_text.value = f"Total: ${total:,.2f}"

        subtotal_text.update()
        descuento_text.update()
        total_text.update()

        # Habilitar o deshabilitar botones según si hay productos en la venta
        realizar_venta_btn.disabled = len(ventas) == 0
        realizar_cotizacion_btn.disabled = len(ventas) == 0
        realizar_venta_btn.update()
        realizar_cotizacion_btn.update()

    # Función para realizar la venta
    def realizar_venta():
        mostrar_modal_confirmacion()
        page.update()

    def crear_cotizacion():
        realizar_cotizacion()
        page.update()

    # Función para realizar la cotización
    def realizar_cotizacion():
        codigo_factura = generar_codigo_factura_unico()

        cotizacion_img = generar_factura_cotizacion(ventas, subtotal, descuento, total, codigo_factura, label_width=3.0, label_height=11, dpi=203)

        cotizacio_boffer = io.BytesIO()
        cotizacion_img.save(cotizacio_boffer, format='PNG')
        contizacion_data = cotizacio_boffer.getvalue()

        cotizacion_flet_imagen = ft.Image(
            src_base64=base64.b64encode(contizacion_data).decode('utf-8'),
            width=400, 
            height=600,
            fit=ft.ImageFit.CONTAIN
        )

        printers = [printer[2] for printer in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]

        printer_dropdown = ft.Dropdown(
            label="Seleccione una impresora",
            options=[ft.dropdown.Option(printer) for printer in printers],
            value=win32print.GetDefaultPrinter()  # Establecer impresora predeterminada
        )

        copies_field = ft.TextField(
            label="Número de copias",
            value=1,
            keyboard_type=ft.KeyboardType.NUMBER
        )

        color_mode_dropdown = ft.Dropdown(
            label="Modo de color",
            options=[
                ft.dropdown.Option("Color"),
                ft.dropdown.Option("Blanco y Negro")
            ],
            value="Blanco y Negro"
        )

        cliente_field = ft.TextField(
            label="Cliente",
            hint_text="Ingrese el nombre o ID del cliente",
            error_text="",  # Inicia sin error
        )

        def validar_cliente():
            """Valida que el campo de cliente no esté vacío."""
            if not cliente_field.value.strip():
                cliente_field.error_text = "Debe ingresar un cliente"
                page.update()
                return False
            cliente_field.error_text = ""  # Limpia el error si todo está bien
            page.update()
            return True

        def imprimir_factura(e):
            if not validar_cliente():
                return  # No procede si el cliente no es válido
            printer_name = printer_dropdown.value
            try:
                if not cliente_field.value.strip():  # Validación del campo cliente
                    cliente_field.error_text = "Debe ingresar un cliente"
                    page.update()
                    return

                num_copies = int(copies_field.value)
                if num_copies <= 0:
                    raise ValueError

                color_mode = color_mode_dropdown.value == "Color"  # True si es color, False si es blanco y negro
                imprimir_imagen(cotizacion_img, printer_name, num_copies, color_mode)
                page.snack_bar = ft.SnackBar(ft.Text("Imprimiendo..."), bgcolor="green")
                page.snack_bar.open = True
                cerrar_modal()
                page.update()
            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Ingrese un número válido de copias"), bgcolor="red")
                page.snack_bar.open = True
                page.update()
                return

        opciones_impresion = ft.Column(
            [
                cliente_field,
                printer_dropdown,
                copies_field,
                color_mode_dropdown,
                ft.Row(
                    [
                        ft.ElevatedButton("Crear Cotizacion", on_click=lambda e: registrar_cotizacion(), bgcolor=ft.colors.BLUE, color="white"),
                        ft.ElevatedButton("Crear e Imprimir", on_click= imprimir_factura, bgcolor=ft.colors.RED, color="white"),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=10
                ),
            ],
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.START,
            width=300  # Ajusta el ancho según necesites
        )

        # Contenedor principal que contiene la imagen y las opciones a la derecha
        contenido_dialogo = ft.Row(
            [
                cotizacion_flet_imagen,
                opciones_impresion
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=20
        )

        modal = ft.AlertDialog(
            modal=True,
            title=ft.Row(
                controls=[
                    ft.Text("Cotización", size=18, weight="bold"),
                    ft.IconButton(
                        icon=ft.icons.CLOSE,
                        on_click=lambda e: cerrar_modal(),  # Botón para cerrar
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            content=contenido_dialogo,
        )

        def registrar_cotizacion():
            try:
                if not cliente_field.value.strip():  # Validación del campo cliente
                    cliente_field.error_text = "Debe ingresar un cliente"
                    page.update()
                    return

                total = sum(Decimal(venta["total"]) for venta in ventas)
                id_cotizacion = codigo_factura 

                registro_cotizacion(
                    identificador=id_cotizacion,
                    usuario_cotizacion=usuario_venta,
                    id_cliente=cliente_field.value.strip(),  # Usar el valor ingresado
                    total=total
                )

                for venta in ventas:
                    cantidad = venta["cantidad"]
                    precio_unitario = Decimal(venta["precio_unitario"])
                    subtotal_producto = cantidad * precio_unitario
                    id = venta['id']

                    registro_detalle_cotizacion(
                        cotizacion_id=id_cotizacion,
                        id_producto=id,
                        cantidad=cantidad,
                        precio_unitario=precio_unitario,
                        subtotal=subtotal_producto
                    )

                cerrar_modal()
                limpiar_pantalla()
                page.update()
            except Exception as e:
                return

        page.dialog = modal
        modal.open = True
        page.update()

        def cerrar_modal():
            modal.open = False
            page.update()




        
    def generar_factura_cotizacion(ventas, subtotal, decuento, total, codigo_factura, label_width=3.0, label_height=11, dpi=203):
        
        # Calcula las dimensiones en píxeles
        width = int(label_width * dpi)
        height = int(label_height * dpi)

        # Crear una imagen en blanco para la factura
        cotizacion_img = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(cotizacion_img)

        # Configuración de fuente
        font_path = "arial.ttf"  # Cambia a la ruta de una fuente TTF válida en tu sistema
        font_size = 20  # Ajusta el tamaño de la fuente para mayor legibilidad
        try:
            font = ImageFont.truetype(font_path, font_size)
        except IOError:
            font = ImageFont.load_default()

        y_offset = 70

        # Encabezado de la factura
        y_offset = 10  # Espaciado vertical inicial
        draw.text((width // 2 - 80, y_offset), "Supermercado XYZ", font=font, fill="black")
        y_offset += 30
        draw.text((10, y_offset), "Av. Principal #123, Ciudad", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Tel: +123 456 7890", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "RUC: 1234567890", font=font, fill="black")
        y_offset += 30

        # Fecha y ID de factura
        draw.text((10, y_offset), f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), f"ID Cotizacion: {codigo_factura}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "DETALLE DE LA COTIZACION", font=font, fill="black")
        y_offset += 30

        draw.text((10, y_offset), "Producto", font=font, fill="black")
        draw.text((width // 2 - 30, y_offset), "Cant.", font=font, fill="black")
        draw.text((width - 100, y_offset), "Total", font=font, fill="black")
        y_offset += 20

        # Detalle de productos
        for venta in ventas:
            draw.text((10, y_offset), venta['producto'], font=font, fill="black")
            draw.text((width // 2 - 30, y_offset), str(venta['cantidad']), font=font, fill="black")
            draw.text((width - 100, y_offset), f"${venta['total']:.2f}", font=font, fill="black")
            y_offset += 20


        y_offset += 10
        draw.line((10, y_offset, width - 10, y_offset), fill="black", width=1)
        y_offset += 10
        draw.text((10, y_offset), "Subtotal:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${subtotal:.2f}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Impuesto (0%):", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${decuento:.2f}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "TOTAL A PAGAR:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${total:.2f}", font=font, fill="black")
        y_offset += 30

        # Resumen
        
        draw.text((10, y_offset), f"Atendido por: {usuario_venta}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Método de pago: Efectivo", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Para cualquier reclamo", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "comuníquese con la persona que le atendió.", font=font, fill="black")
        y_offset += 40
        draw.text((width // 2 - 80, y_offset), "¡Gracias por su compra!", font=font, fill="black")

        return cotizacion_img

    def imprimir_imagen(imagen, printer_name, num_copies, color_mode):
        try:
            # Abre la impresora y obtiene el DEVMODE
            hPrinter = win32print.OpenPrinter(printer_name)
            devmode = win32print.GetPrinter(hPrinter, 2)["pDevMode"]

            # Configura el número de copias
            devmode.Copies = num_copies

            # Configura el modo de color
            devmode.Color = 1 if color_mode else 2  # 1 = Color, 2 = Blanco y Negro

            # Crea un contexto de dispositivo con el DEVMODE modificado
            hDC = win32ui.CreateDC()
            hDC.CreatePrinterDC(printer_name)
            hDC.SetMapMode(win32con.MM_TEXT)

            # Obtiene el área imprimible y el tamaño físico
            printable_area = hDC.GetDeviceCaps(win32con.HORZRES), hDC.GetDeviceCaps(win32con.VERTRES)
            printer_size = hDC.GetDeviceCaps(win32con.PHYSICALWIDTH), hDC.GetDeviceCaps(win32con.PHYSICALHEIGHT)
            printer_margins = hDC.GetDeviceCaps(win32con.PHYSICALOFFSETX), hDC.GetDeviceCaps(win32con.PHYSICALOFFSETY)

            # Obtiene las dimensiones de la imagen
            img_width, img_height = imagen.size

            # Escala la imagen para ajustarla al área imprimible
            ratios = [1.0 * printable_area[0] / img_width, 1.0 * printable_area[1] / img_height]
            scale = min(ratios)
            scaled_width, scaled_height = [int(scale * img_width), int(scale * img_height)]

            # Calcula la posición centrada de la imagen
            x1 = int((printer_size[0] - scaled_width) / 2)
            y1 = int((printer_size[1] - scaled_height) / 2)
            x2 = x1 + scaled_width
            y2 = y1 + scaled_height

            # Inicia el documento de impresión
            hDC.StartDoc("Prueba de Impresión")
            hDC.StartPage()

            # Crea un DIB de la imagen y la dibuja
            dib = ImageWin.Dib(imagen)
            dib.draw(hDC.GetHandleOutput(), (x1, y1, x2, y2))

            # Finaliza el documento de impresión
            hDC.EndPage()
            hDC.EndDoc()
            hDC.DeleteDC()

                # Cierra la impresora
            win32print.ClosePrinter(hPrinter)
            
        except Exception as e:
            return

        # Función para mostrar y confirmar cotización
        

        
    
    def mostrar_modal_confirmacion():
        codigo_factura = generar_codigo_factura_unico()
        modal_confirmacion = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirmar Venta", size=20, weight=ft.FontWeight.BOLD),
        )



            # Campo para ingresar la cédula del cliente
        cliente_cedula_input = ft.TextField(
            label="Cédula del Cliente",
            keyboard_type="number"
        )

        # Campo para la cantidad con la que paga el cliente
        cantidad_pago_input = ft.TextField(
            label="Cantidad con la que paga",
            keyboard_type="number",
            on_blur=lambda e: calcular_devolucion(),  # Calcula el cambio al detectar cambios
        )

        # Texto que muestra el cambio a devolver al cliente
        devolucion_tex = ft.Text(
            value="0.00",
            size=18,
            weight=ft.FontWeight.BOLD,
        )
        


        # Función para calcular la devolución en tiempo real
        def calcular_devolucion():
            try:
                total = sum(venta["total"] for venta in ventas)
                monto_pago = Decimal(cantidad_pago_input.value) if cantidad_pago_input.value else 0
                cambio = monto_pago - Decimal(total)
                devolucion_tex.value = f"{cambio:,.2f}" if cambio >= 0 else "0.00"
                devolucion_tex.update()  # Actualiza el texto en la interfaz
                modal_confirmacion.update()
            except ValueError:
                devolucion_tex.value = "0.00"
                devolucion_tex.update()

                
        # Función para confirmar la cancelación del modal con un código de autorización
        def confirmar_cancelacion():
            codigo_input = ft.TextField(
                label="Ingrese código de autorización",
                password=True,
                width=200,
            )
            
            # Modal de confirmación de cancelación
            modal_confirmacion_cancelacion = ft.AlertDialog(
                modal=True,
                title=ft.Text("Confirmar Cancelación", size=20, weight=ft.FontWeight.BOLD),
                content=ft.Column(
                    controls=[codigo_input],
                ),
                actions=[
                    ft.ElevatedButton(
                        text="Confirmar",
                        on_click=lambda _: validar_codigo_cancelacion(codigo_input.value),
                    ),
                    ft.ElevatedButton(
                        text="Cancelar",
                        on_click=lambda _: cerrar_modal_confirmacion_cancelacion(),
                    ),
                ],
            )
            page.on_change = lambda e: calcular_devolucion()
            page.update()
            
        
            # Función que valida el código ingresado
            def validar_codigo_cancelacion(codigo):
                codigo_correcto = "1234"  # Código de ejemplo; cambiar por el valor real
                if codigo == codigo_correcto:
                    cerrar_modal_venta()  # Cierra el modal de venta si el código es correcto
                    cerrar_modal_confirmacion_cancelacion()
                    
                else:
                    return

            # Cierra el modal de confirmación de cancelación
            def cerrar_modal_confirmacion_cancelacion():
                modal_confirmacion_cancelacion.open = False
                page.update()

            modal_confirmacion_cancelacion.open = True
            page.dialog = modal_confirmacion_cancelacion
            page.update()


        # Tipo de pago (efectivo, tarjeta, transferencia)
        tipo_pago_radio_group = ft.RadioGroup(
            content=ft.Row(
                controls=[
                    ft.Radio(label="Efectivo", value="efectivo"),
                    ft.Radio(label="Tarjeta", value="tarjeta"),
                    ft.Radio(label="Transferencia", value="transferencia"),
                ]
            ),
            value="efectivo",  # Predeterminado en efectivo
        )

        venta_img = generar_factura_imagen(ventas, subtotal, total, codigo_factura)

        venta_boffer = io.BytesIO()
        venta_img.save(venta_boffer, format='PNG')
        venta_data = venta_boffer.getvalue()

        ventas_flet_imagen= ft.Image(
            src_base64=base64.b64encode(venta_data).decode('utf-8'),
            width=500, 
            height=600,
            fit=ft.ImageFit.CONTAIN
        )

        # Obtener impresoras del sistema Windows
        def obtener_impresoras():
            impresoras = []
            try:
                impresoras = [printer[2] for printer in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
            except Exception as e:
                return
            return impresoras

        impresoras_disponibles = obtener_impresoras()

        # Selección de impresora
        impresora_selector = ft.Dropdown(
            label="Seleccionar impresora",
            options=[ft.dropdown.Option(impresora) for impresora in impresoras_disponibles],
            value=win32print.GetDefaultPrinter()
        )

        copies_field = ft.TextField(
            label="Número de copias",
            value=1,
            width=100,
            keyboard_type=ft.KeyboardType.NUMBER
        )

        color_mode_dropdown = ft.Dropdown(
            label="Modo de color",
            options=[
                ft.dropdown.Option("Color"),
                ft.dropdown.Option("Blanco y Negro")
            ],
            value="Blanco y Negro"
        )
        

        # Botones para realizar la venta o vender e imprimir
        botones_venta = ft.Row(
            controls=[
                ft.ElevatedButton(text="Vender", on_click=lambda _: registrar_venta_final()),
                ft.ElevatedButton(text="Vender e Imprimir", on_click=lambda _: vender_e_imprimir()),
            ]
        )

        def vender_e_imprimir():
            try:
                num_copies = int(copies_field.value)
                if num_copies <= 0:
                    raise ValueError
                color_mode = color_mode_dropdown.value == "Color" 
                impresora_seleccionada = impresora_selector.value
                if impresora_seleccionada:

                    
                    imprimir_factura_imagen(venta_img, impresora_seleccionada, num_copies, color_mode)
                    page.snack_bar = ft.SnackBar(ft.Text("Imprimiendo..."), bgcolor="green")
                    page.snack_bar.open = True
                    registrar_venta_final()
                    cerrar_modal_venta()
                    # Aquí se puede agregar la lógica de impresión real
                else:
                    return

            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Ingrese un número válido de copias"), bgcolor="red")
                page.snack_bar.open = True
                page.update()
                return
        
    




        
        
            
        # Estructura de la modal: Factura a la izquierda, otras opciones a la derecha
        modal_confirmacion.content = ft.Container(
            content=ft.Row(
                controls=[
                    # Parte izquierda: Detalle de la factura
                    ft.Container(
                        content=ventas_flet_imagen,
                        expand=1,
                        padding=10,
                        border=ft.border.all(1, color=ft.colors.GREY),
                    ),
                    # Parte derecha: Información adicional
                    ft.Column(
                        controls=[
                            ft.Text("Tipo de Pago"),
                            tipo_pago_radio_group,
                            cantidad_pago_input,
                            ft.Text("Devulta de Venta"),
                            devolucion_tex,
                            cliente_cedula_input,
                            impresora_selector,
                            copies_field,
                            color_mode_dropdown,
                            botones_venta,
                        ],
                        expand=1
                    ),
                ],
                expand=True
            ),
            width=600,
            height=600
        )
        
        def registrar_venta_final():
            try:
                # Generar un código único de factura
                
                
                # Datos generales de la venta
               
                id_cliente = cliente_cedula_input.value  # Cliente seleccionado
                #if not id_cliente:
                #    print("Error: No se ha seleccionado un cliente.")
                #    return

                
                if len(id_cliente) < 8:
                    
                    id_cliente = '1000000000'
                
                fecha_venta = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                total = sum(Decimal(venta["total"]) for venta in ventas)
                metodo_pago = tipo_pago_radio_group.value  
                id_venta = codigo_factura 
                devolucion = devolucion_tex.value
                cantidad_pagado = cantidad_pago_input.value
                

                registro_venta(
                    identifcador=id_venta,
                    usuario_venta=usuario_venta,
                    id_cliente=id_cliente,
                    fecha_venta=fecha_venta,
                    total=total,
                    metodo_pago=metodo_pago,
                    codigo_factura=codigo_factura,
                    
                )
                
                registrar_detalle(
                    id_factura = id_venta,
                    ingresos = total,
                    egresos = devolucion,
                    monto_pago = cantidad_pagado
                )
                

                
                for venta in ventas:
                    cantidad = venta["cantidad"]
                    precio_unitario = Decimal(venta["precio_unitario"])
                    tipo_venta = "venta normal" if venta_radio_group == "normal" else "venta por mayor"
                    subtotal_producto = cantidad * precio_unitario
                    id = venta['id']

                    # Registrar en la tabla `detallesventa` por cada producto
                    registro_detalle_venta(
                        id_venta=id_venta,
                        producto_venta=id,
                        cantidad=cantidad,
                        precio_unitario=precio_unitario,
                        subtotal=subtotal_producto,
                        tipo_venta=tipo_venta,  # Venta normal o por mayor
                        codigo_factura=codigo_factura,
                    )
                
                cerrar_modal_venta()
                limpiar_pantalla()
                page.update()

            except Exception as e:
                return

            cerrar_modal_venta()

        modal_confirmacion.open = True
        page.dialog = modal_confirmacion
        page.update()
        
        def cerrar_modal_venta():
            modal_confirmacion.open = False
            page.update()

    def generar_factura_imagen(ventas, subtotal, total, codigo_factura):

        label_width = 3.0  # Ancho en pulgadas (ajusta según tu impresora)
        label_height = 11  # Alto en pulgadas (ajusta según tu impresora)
        dpi = 203  # DPI típico de impresoras de tickets

        # Calcula las dimensiones en píxeles
        width = int(label_width * dpi)
        height = int(label_height * dpi)

        # Crear una imagen en blanco para la factura
        factura_img = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(factura_img)

        # Configuración de fuente
        font_path = "arial.ttf"  # Cambia a la ruta de una fuente TTF válida
        font_size = 20  # Ajusta el tamaño de la fuente para mayor legibilidad
        try:
            font = ImageFont.truetype(font_path, font_size)
        except IOError:
            font = ImageFont.load_default()

        # Información del supermercado
        y_offset = 10  # Espaciado vertical inicial
        draw.text((width // 2 - 80, y_offset), "Supermercado XYZ", font=font, fill="black")
        y_offset += 30
        draw.text((10, y_offset), "Av. Principal #123, Ciudad", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Tel: +123 456 7890", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "RUC: 1234567890", font=font, fill="black")
        y_offset += 30

        # Fecha y ID de factura
        draw.text((10, y_offset), f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), f"No Factura: {codigo_factura}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "DETALLE DE LA FACTURA", font=font, fill="black")
        y_offset += 20
        draw.line((20, y_offset, width - 20, y_offset), fill="black", width=2)

        # Títulos de las columnas
        draw.text((10, y_offset), "Producto", font=font, fill="black")
        draw.text((width // 2 - 30, y_offset), "Cant.", font=font, fill="black")
        draw.text((width - 100, y_offset), "Total", font=font, fill="black")
        y_offset += 20

        # Agregar los productos vendidos
        for venta in ventas:
            draw.text((10, y_offset), venta['producto'], font=font, fill="black")
            draw.text((width // 2 - 30, y_offset), str(venta['cantidad']), font=font, fill="black")
            draw.text((width - 100, y_offset), f"${venta['total']:.2f}", font=font, fill="black")
            y_offset += 20

        # Línea divisoria y resumen de totales
        y_offset += 10
        draw.line((10, y_offset, width - 20, y_offset), fill="black", width=2)
        y_offset += 10
        draw.text((10, y_offset), "Subtotal:", font=font, fill="black")
        draw.text((width - 340, y_offset), f"${subtotal:.2f}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Impuesto (0):", font=font, fill="black")
        draw.text((width - 340, y_offset), "$0.00", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "TOTAL A PAGAR:", font=font, fill="black")
        draw.text((width - 100, y_offset), f"${total:.2f}", font=font, fill="black")
        y_offset += 30

        # Información del cajero y agradecimiento
        draw.text((10, y_offset), f"Atendido por: {usuario_venta}", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset), "Para cualquier reclamo", font=font, fill="black")
        y_offset += 20
        draw.text((10, y_offset + 20), "comuníquese con la persona que le atendió.", font=font, fill="black")
        
        y_offset += 40
        draw.text((width // 2 - 80, y_offset), "¡Gracias por su compra!", font=font, fill="black")

        return factura_img


    def imprimir_factura_imagen(imagen,  printer_name, num_copies, color_mode):
        # Define la impresora y el trabajo de impresión
        try:
            # Abre la impresora y obtiene el DEVMODE
            hPrinter = win32print.OpenPrinter(printer_name)
            devmode = win32print.GetPrinter(hPrinter, 2)["pDevMode"]

            # Configura el número de copias
            devmode.Copies = num_copies

            # Configura el modo de color
            devmode.Color = 1 if color_mode else 2  # 1 = Color, 2 = Blanco y Negro

            # Crea un contexto de dispositivo con el DEVMODE modificado
            hDC = win32ui.CreateDC()
            hDC.CreatePrinterDC(printer_name)
            hDC.SetMapMode(win32con.MM_TEXT)

            # Obtiene el área imprimible y el tamaño físico
            printable_area = hDC.GetDeviceCaps(win32con.HORZRES), hDC.GetDeviceCaps(win32con.VERTRES)
            printer_size = hDC.GetDeviceCaps(win32con.PHYSICALWIDTH), hDC.GetDeviceCaps(win32con.PHYSICALHEIGHT)
            printer_margins = hDC.GetDeviceCaps(win32con.PHYSICALOFFSETX), hDC.GetDeviceCaps(win32con.PHYSICALOFFSETY)

            # Obtiene las dimensiones de la imagen
            img_width, img_height = imagen.size

            # Escala la imagen para ajustarla al área imprimible
            ratios = [1.0 * printable_area[0] / img_width, 1.0 * printable_area[1] / img_height]
            scale = min(ratios)
            scaled_width, scaled_height = [int(scale * img_width), int(scale * img_height)]

            # Calcula la posición centrada de la imagen
            x1 = int((printer_size[0] - scaled_width) / 2)
            y1 = int((printer_size[1] - scaled_height) / 2)
            x2 = x1 + scaled_width
            y2 = y1 + scaled_height

            # Inicia el documento de impresión
            hDC.StartDoc("Prueba de Impresión")
            hDC.StartPage()

            # Crea un DIB de la imagen y la dibuja
            dib = ImageWin.Dib(imagen)
            dib.draw(hDC.GetHandleOutput(), (x1, y1, x2, y2))

            # Finaliza el documento de impresión
            hDC.EndPage()
            hDC.EndDoc()
            hDC.DeleteDC()

            # Cierra la impresora
            win32print.ClosePrinter(hPrinter)
            
        except Exception as e:
            return

    
    venta_radio_group  = ""
    
    # Abre el modal para agregar un producto a la venta
    def abrir_modal_producto_venta(producto_id):
        producto = informacion_producto(producto_id)

        modal_venta = ft.AlertDialog(
            modal=True,
            title=ft.Text("Agregar Venta", size=20, weight=ft.FontWeight.BOLD),
        )

        # Campo de cantidad con valor inicial 1.
        cantidad_input = ft.TextField(
            label="Cantidad a vender",
            value="1",
            keyboard_type="number",
            width=200,
        )

        # Campo de precio por mayor (invisible al inicio).
        precio_mayor_input = ft.TextField(
            label="Precio de venta al por mayor",
            keyboard_type="number",
            width=200,
            visible=False,
        )

        # RadioGroup para seleccionar tipo de venta.
        venta_radio_group = ft.RadioGroup(
            content=ft.Row(
                controls=[
                    ft.Radio(label="Venta normal", value="normal"),
                    ft.Radio(label="Venta por mayor", value="mayor"),
                ]
            ),
            value="normal",  # Por defecto, selecciona venta normal.
            on_change=lambda e: cambiar_visibilidad_precio_mayor(e.control.value),
        )

        # Cambia la visibilidad del precio por mayor según la opción seleccionada.
        def cambiar_visibilidad_precio_mayor(valor):
            precio_mayor_input.visible = (valor == "mayor")
            precio_mayor_input.update()
            if valor == "mayor":
                precio_mayor_input.focus()  # Si es venta mayor, pone el focus aquí.
                precio_mayor_input.on_submit = lambda e: confirmar_venta(cantidad_input, precio_mayor_input, producto, producto_id)

        # Estructura del contenido del modal.
        modal_venta.content = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text(f"Producto: {producto['nombre_producto']}", size=18, weight=ft.FontWeight.BOLD),
                    ft.Row([cantidad_input, precio_mayor_input], spacing=10),
                    venta_radio_group,
                ],
                spacing=10,
            ),
            width=400,
            height=250,
        )

        # Botones de acciones del modal.
        modal_venta.actions = [
            ft.ElevatedButton(
                text="Confirmar",
                on_click=lambda _: confirmar_venta(cantidad_input, precio_mayor_input, producto, producto_id),
            ),
            ft.ElevatedButton(text="Cancelar", on_click=lambda _: cerrar_modal()),
        ]

        modal_venta.open = True
        page.dialog = modal_venta
        page.update()

        # El focus se pone inicialmente en el campo de cantidad.
        cantidad_input.focus()

        # Si se presiona Enter en el campo de cantidad, llama a confirmar_venta.
        cantidad_input.on_submit = lambda e: confirmar_venta(cantidad_input, precio_mayor_input, producto, producto_id)

        # Cierra el modal.
        def cerrar_modal():
            modal_venta.open = False
            page.update()

        # Lógica para confirmar la venta.
        def confirmar_venta(cantidad_input, precio_mayor_input, producto, producto_id):
            try:
                cantidad = int(cantidad_input.value or 0)
                if cantidad <= 0:
                    
                    return

                # Obtiene el precio mayor si está visible; de lo contrario, usa el precio normal.
                precio_mayor = Decimal(precio_mayor_input.value or 0) if precio_mayor_input.visible else None
                precio_venta = precio_mayor if precio_mayor else Decimal(producto['precio_venta'])

                venta_existente = next((v for v in ventas if v["id"] == producto_id), None)

                if venta_existente:
                    venta_existente["cantidad"] += cantidad
                    venta_existente["total"] = venta_existente["cantidad"] * precio_venta
                else:
                    ventas.append({
                        "id": producto_id,
                        "producto": producto["nombre_producto"],
                        "cantidad": cantidad,
                        "total": cantidad * precio_venta,
                        "precio_unitario": f"{precio_venta:.2f}",
                    })

                actualizar_detalle_venta()
                actualizar_totales()
                cerrar_modal()
            except Exception as e:
                return



    def actualizar_detalle_venta():
        detalle_venta_contenedor.content.controls.clear()
        for venta in ventas:
            fila = ft.Row(
                controls=[
                    ft.Text(venta["producto"], expand=2),
                    ft.Text(str(venta["cantidad"]), expand=1),
                    ft.Text(f"${float(venta['total']):,.2f}", expand=1),
                ]
            )

            # Agrega un GestureDetector para manejar clics en la fila
            detalle_venta_contenedor.content.controls.append(
                ft.GestureDetector(
                    on_tap=lambda e, v=venta: manejar_click_producto(v),
                    content=fila,
                )
            )
        detalle_venta_contenedor.update()


    def manejar_click_producto(venta):
        # Modal para editar o quitar producto
        def actualizar_cantidad(e):
            nueva_cantidad = int(input_cantidad.value)
            if nueva_cantidad > 0:
                # Calcula el total como operación matemática
                venta["cantidad"] = nueva_cantidad
                venta["total"] = float(venta["precio_unitario"]) * nueva_cantidad
            else:
                ventas.remove(venta)  # Si la cantidad es 0, elimina el producto
            modal.open = False  # Cierra el modal
            page.update()  # Actualiza la página
            actualizar_detalle_venta()  # Refresca la vista del detalle
            actualizar_totales()

        def quitar_producto(e):
            ventas.remove(venta)  # Elimina el producto
            modal.open = False  # Cierra el modal
            page.update()  # Actualiza la página
            actualizar_detalle_venta()  # Refresca la vista del detalle
            actualizar_totales()

        # Controles del modal
        input_cantidad = ft.TextField(
            label="Cantidad",
            value=str(venta["cantidad"]),
            keyboard_type=ft.KeyboardType.NUMBER,
        )
        btn_actualizar = ft.ElevatedButton("Actualizar", on_click=actualizar_cantidad)
        btn_quitar = ft.TextButton("Quitar", on_click=quitar_producto)

        # Contenedor con tamaño máximo
        contenido_modal = ft.Container(
            content=ft.Column(
                controls=[input_cantidad, btn_actualizar, btn_quitar],
                alignment=ft.MainAxisAlignment.START,
            ),
            width=300,  # Ancho máximo
            height=250,  # Alto máximo
            padding=20,
        )

        # Crear el modal
        modal = ft.AlertDialog(
            title=ft.Text(f"Editar Producto: {venta['producto']}"),
            content=contenido_modal,
            actions=[
                ft.TextButton(
                    "Cerrar",
                    on_click=lambda e: (setattr(modal, "open", False), page.update()),
                )
            ],
        )
        page.dialog = modal  # Asocia el modal con la página
        modal.open = True  # Abre el modal
        page.update()  # Actualiza la página para reflejar los cambios


    def buscar_productos(e):
        query = e.control.value.strip().lower()
        if query:
            productos_filtrados = buscar_producto_compra(query)
            actualizar_productos(productos_filtrados)
        else:
            product_catalog.controls.clear()
            product_catalog.update()

    def actualizar_productos(lista_productos):
        product_catalog.controls.clear()
        for producto in lista_productos:
            product_catalog.controls.append(crear_tarjeta_producto(producto))
        product_catalog.update()

    def crear_tarjeta_producto(producto):
        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text(producto[2], weight=ft.FontWeight.BOLD),
                    ft.Container(
                        content=ft.Image(
                            src=f"assets/image/{producto[3]}", 
                            width=100, 
                            height=120, 
                            fit=ft.ImageFit.CONTAIN
                        ),
                        alignment=ft.alignment.center,  # Centrar la imagen en el contenedor
                    ),
                    ft.Text(f"Precio: ${producto[8]:,.2f}", weight=ft.FontWeight.BOLD),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=8,
            ),
            padding=10,
            border=ft.border.all(1, ft.colors.GREY),
            border_radius=10,
            width=160,
            height=250,
            on_click=lambda _: abrir_modal_producto_venta(producto[0]),
        )

    
    campo_busqueda = ft.TextField(
            label="Buscar productos", 
            border_radius=10, 
            width=400, 
            height=40, 
            prefix_icon=ft.icons.SEARCH, 
            on_change=buscar_productos
        )

    header = ft.Row(
        controls=[
            campo_busqueda,
            ft.IconButton(icon=ft.icons.BARCODE_READER, tooltip="Escanear código de barras", visible=False),
            ft.IconButton(icon=ft.icons.PERSON_ADD, 
                          tooltip="Agregar cliente",  
                          on_click=lambda e: mostrar_modal(page),
                          ),
        ]
    )
    
    def limpiar_pantalla():
        # Limpia la lista de ventas
        ventas.clear()
        campo_busqueda.value = ""


        # Limpia los controles de búsqueda y catálogo de productos
        detalle_venta_contenedor.content.controls = []
        
        
        product_catalog.controls = []
        # Restablece los textos de subtotal, descuento y total
        subtotal_text.value = "Subtotal: $0.00"
        descuento_text.value = "Descuento: $0.00"
        total_text.value = "Total: $0.00"
         # Desactiva los botones de venta y cotización
        realizar_venta_btn.disabled = True
        realizar_cotizacion_btn.disabled = True

        # Actualiza los controles visuales
        campo_busqueda.update()
        subtotal_text.update()
        descuento_text.update()
        total_text.update()
        detalle_venta_contenedor.update()
        product_catalog.update()      
        realizar_venta_btn.update()
        realizar_cotizacion_btn.update()

        

    product_catalog = ft.GridView(max_extent=180, child_aspect_ratio=0.8, spacing=10, run_spacing=10, expand=True)

    return ft.Row(
        controls=[
            ft.Column(controls=[header, product_catalog], expand=True),
            ft.Container(
                content=ft.Column(
                    controls=[
                        ft.Text("Detalle de venta", size=20, weight=ft.FontWeight.BOLD),
                        ft.Divider(),
                        ft.Row(
                            controls=[
                                ft.Text("Nombre del Producto", weight=ft.FontWeight.BOLD, expand=2),
                                ft.Text("Cantidad", weight=ft.FontWeight.BOLD, expand=1),
                                ft.Text("Valor", weight=ft.FontWeight.BOLD, expand=1),
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                        ),
                        detalle_venta_contenedor,
                        ft.Divider(),  # Línea entre productos seleccionados y totales
                        subtotal_text,
                        descuento_text,
                        total_text,
                        ft.Divider(),  # Línea entre totales y botones
                        ft.Row([realizar_venta_btn, realizar_cotizacion_btn], alignment=ft.MainAxisAlignment.CENTER),
                    ],
                    expand=True,
                ),
                width=340, padding=10, bgcolor=ft.colors.BLUE_GREY_50, height=670,
            ),
        ],
        expand=True,
    )
