import flet as ft

from routes.estadisticas import cargar_estadisticas
from conexiondb import create_connection, close_connection
from datetime import datetime, timedelta



# Función para generar el gráfico de ingresos, egresos y ganancias
def generar_grafico_facturas_interactivo(ingresos, egresos, ganancias):
    # Cálculo de porcentajes
    total = ingresos + egresos + ganancias
    if total == 0:
        total = 1  # Evitar división por cero
    ingresos_pct = (ingresos / total) * 100
    egresos_pct = (egresos / total) * 100
    ganancias_pct = (ganancias / total) * 100

    # Creando el gráfico de dona usando PieChart de Flet (sin el argumento "interactive")
    pie_chart = ft.PieChart(
        sections=[
            ft.PieChartSection(ganancias_pct, color=ft.colors.GREEN, title="Ganancias"),
            ft.PieChartSection(ingresos_pct, color=ft.colors.BLUE, title="Ingresos"),
            ft.PieChartSection(egresos_pct, color=ft.colors.RED, title="Egresos"),
        ],
        sections_space=2,
        center_space_radius=30,
        width=250,
        height=250,
    )

    return pie_chart


# Función para generar gráfico de barras de ventas por días con Flet
# Función para generar gráfico de barras de ventas por días con Flet
def generar_grafico_ventas_diarias(semana_inicio, semana_fin):
    conexion = create_connection()
    cursor = conexion.cursor()

    dias_semana = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
    ventas_dias = [0] * 7  # Inicializar ventas en cero

    # Obteniendo ventas por día
    cursor.execute("""
        SELECT DAYOFWEEK(fecha_venta) AS dia_semana, SUM(total) AS total_venta
        FROM ventas
        WHERE fecha_venta BETWEEN %s AND %s
        GROUP BY dia_semana
    """, (semana_inicio, semana_fin))

    for dia_semana, total_venta in cursor.fetchall():
        # MySQL DAYOFWEEK devuelve 1 para Domingo, ajustamos para que empiece en Lunes=0
        index = (dia_semana + 5) % 7
        ventas_dias[index] = float(total_venta)  # Convertir total_venta a float

    conexion.close()

    max_venta = max(ventas_dias) or 1  # Evitar división por cero

    # Crear el gráfico de barras usando BarChart
    bar_chart = ft.BarChart(
        bar_groups=[
            ft.BarChartGroup(
                x=i,  # Indice del día
                bar_rods=[
                    ft.BarChartRod(
                        from_y=0,
                        to_y=venta,  # Valor de la venta del día
                        width=30,
                        color=ft.colors.BLUE,  
                        tooltip=f"{dias_semana[i]}: ${venta:,.2f}", 
                        border_radius=0,
                    ),
                ],
            ) for i, venta in enumerate(ventas_dias)  # Enumerar sobre las ventas
        ],
        border=ft.border.all(1, ft.colors.GREY_400),
        left_axis=ft.ChartAxis(
            labels_size=50,
        ),
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(
                    value=i, label=ft.Container(ft.Text(dia), padding=10)
                ) for i, dia in enumerate(dias_semana)
            ],
            labels_size=40,
        ),
        horizontal_grid_lines=ft.ChartGridLines(
            color=ft.colors.GREY_300, width=1, dash_pattern=[3, 3]
        ),
        tooltip_bgcolor=ft.colors.with_opacity(0.5, ft.colors.GREY_300),
        max_y=float(max_venta) * 1.1,  # Convertir max_venta a float antes de la multiplicación
        interactive=True,
        expand=True,
    )

    return bar_chart


# Función principal de la vista de estadísticas
def estadisticas_view(page):
    # Fecha actual y cálculo de la semana actual
    hoy = datetime.now()
    semana_actual_inicio = hoy - timedelta(days=hoy.weekday())
    semana_actual_fin = semana_actual_inicio + timedelta(days=6)

    # Variables para cambiar la semana
    semana_seleccionada_inicio = semana_actual_inicio
    semana_seleccionada_fin = semana_actual_fin

    # Función para actualizar las estadísticas y gráficas
    def actualizar_estadisticas(e=None):
        nonlocal semana_seleccionada_inicio, semana_seleccionada_fin
        estadisticas = cargar_estadisticas(semana_seleccionada_inicio, semana_seleccionada_fin)
        clientes, ingresos, ganancias, facturas, ventas_mes = cargar_estadisticas(semana_seleccionada_inicio, semana_seleccionada_fin)
        grafico_facturas = generar_grafico_facturas_interactivo(ingresos, egresos=ingresos - ganancias, ganancias=ganancias)
        grafico_ventas = generar_grafico_ventas_diarias(semana_seleccionada_inicio, semana_seleccionada_fin)
        if estadisticas is None:
            
            return None  # Salimos de la función si no hay datos

        # Actualizar textos de estadísticas
        clientes_text.value = f"{clientes}"
        ingresos_text.value = f"${ingresos:,.2f}"
        egresos_text.value = f"${(ingresos - ganancias):,.2f}"
        ganancias_text.value = f"${ganancias:,.2f}"
        facturas_text.value = f"{facturas}"
        ventas_mes_text.value = f"${ventas_mes:,.2f}"

        # Actualizar gráficas
        grafico_facturas_container.content = grafico_facturas
        grafico_ventas_container.content = grafico_ventas

        page.update()

    # Controles de textos para estadísticas
    clientes_text = ft.Text(size=24, weight="bold")
    ingresos_text = ft.Text(size=24, weight="bold")
    egresos_text = ft.Text(size=24, weight="bold")
    ganancias_text = ft.Text(size=24, weight="bold")
    facturas_text = ft.Text(size=24, weight="bold")
    ventas_mes_text = ft.Text(size=24, weight="bold")

    # Contenedores para las gráficas
    grafico_facturas_container = ft.Container()
    grafico_ventas_container = ft.Container()

    # Selector de semana
    def cambiar_semana(e):
        nonlocal semana_seleccionada_inicio, semana_seleccionada_fin
        semana_seleccionada_inicio = datetime.strptime(semana_selector.value + '-1', "%Y-W%W-%w")
        semana_seleccionada_fin = semana_seleccionada_inicio + timedelta(days=6)
        actualizar_estadisticas()

    semanas_opciones = []
    for i in range(4):  # Últimas 4 semanas
        semana = hoy - timedelta(weeks=i)
        semana_num = semana.strftime("%Y-W%W")
        semanas_opciones.append(ft.dropdown.Option(key=semana_num, text=f"Semana {semana.strftime('%W')} del {semana.strftime('%d/%m/%Y')}"))

    semana_selector = ft.Dropdown(
        label="Seleccionar semana",
        options=semanas_opciones,
        value=hoy.strftime("%Y-W%W"),
        on_change=cambiar_semana
    )

    # Botón para actualizar manualmente (opcional)
    actualizar_button = ft.ElevatedButton("Actualizar", on_click=actualizar_estadisticas)

    stats_row = ft.Row(
        controls=[
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Clientes", size=18), clientes_text,
                ft.Text("s", color=ft.colors.GREEN),
            ]), padding=5), elevation=3, width=200, expand=True),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Ingresos", size=18), ingresos_text,
                ft.Text("", color=ft.colors.RED),
            ]), padding=5), elevation=3, width=200, expand=True),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Egresos", size=18), egresos_text,
                ft.Text("", color=ft.colors.GREEN),
            ]), padding=5), elevation=3, width=200, expand=True),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Ganancias", size=18), ganancias_text,
                ft.Text("", color=ft.colors.GREEN),
            ]), padding=5), elevation=3, width=200, expand=True),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Ventas del Mes", size=18), ventas_mes_text,
                ft.Text("", color=ft.colors.GREEN),
            ]), padding=5), elevation=3, width=230, expand=True),
        ],
        alignment="spaceBetween",
        spacing=5,
        height=120,
    )

    grafico_row = ft.Row(
        controls=[
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Estadísticas de Semana", size=18),
                grafico_facturas_container,
            ]), padding=15), elevation=3, width=240, height=350, expand=False),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Análisis de Ventas", size=18),
                grafico_ventas_container,
            ]), padding=15), elevation=3, width=600, height=350, expand=True),
            ft.Card(content=ft.Container(content=ft.Column([
                ft.Text("Notificaciones", size=18),
                ft.Text("Cargando notificaciones...", size=16, color=ft.colors.BLUE),
                # Aquí puedes agregar la lógica para cargar notificaciones reales
            ]), padding=15), elevation=3, width=200, height=350, expand=True),
        ],
        alignment="spaceBetween",
        spacing=10
    )

    # Inicializar estadísticas y gráficas
    actualizar_estadisticas()

    vista_estadistica =ft.Column(
            controls=[
                semana_selector,
                stats_row,
                grafico_row,
                # Agrega aquí más controles si es necesario
            ]
         )
    
    return vista_estadistica
    