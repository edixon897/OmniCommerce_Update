from routes.verificacion import verify_code_in_db

def verify_code_model(code):
    
    
    return verify_code_in_db(code)
