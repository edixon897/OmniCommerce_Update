from routes.productos import registro_producto
from utils.usuarioSesion import estado_global

def registro_de_productos(codigo_barras, nombre_producto, descripcion_producto, categoria_producto, proveedor_producto, cantidad_disponible, stock_minimo, precio_unitario, precio_compra,  fecha_ingreso, ubicacion_almacen, imagen, marca_producto, referencia,  fecha_vencimiento ):
    
    nombre_registrador = estado_global.get_nombre()
    apellido_registrador = estado_global.get_apellido()
    
    return registro_producto(codigo_barras, nombre_producto, descripcion_producto, categoria_producto, cantidad_disponible, stock_minimo, precio_unitario, precio_compra, proveedor_producto, fecha_ingreso, ubicacion_almacen, referencia, marca_producto, fecha_vencimiento, imagen,   nombre_registrador, apellido_registrador)
