from routes.categoria import registro_categoria
from utils.usuarioSesion import estado_global
import datetime

def registro_de_categoria(nombre_categoria, descripcion_categoria):
    
    nombre_registrador = estado_global.get_nombre()
    apellido_registrador = estado_global.get_apellido()
    fecha_registro = datetime.datetime.now()
    
    return registro_categoria(nombre_categoria, descripcion_categoria, nombre_registrador, apellido_registrador, fecha_registro)

