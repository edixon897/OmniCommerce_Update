from routes.tienda import register_empresa

def registro_de_empresa(nombre_empresa, descripcion_empresa, direccion_empresa, telefono_empresa, correo_empresa, logo_empresa):
    
    
    return register_empresa( nombre_empresa, descripcion_empresa, direccion_empresa, telefono_empresa, correo_empresa, logo_empresa)