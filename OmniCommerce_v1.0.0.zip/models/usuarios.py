from routes.usuarios import registro_usuario
from utils.usuarioSesion import estado_global

def registro_de_usuarios(nombre_usuario, apellido_usuario, documento_usuario, tipo_documento, fecha_nacimiento, correo_usuario, contraseña_usuario, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, fecha_creacion, rol_usuario):
    
    nombre_registrador = estado_global.get_nombre()
    apelido_regitrador = estado_global.get_apellido()
    
    return registro_usuario(nombre_usuario, apellido_usuario, documento_usuario, tipo_documento, fecha_nacimiento, correo_usuario, contraseña_usuario, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, fecha_creacion, rol_usuario, nombre_registrador, apelido_regitrador)

