from routes.clientes import registro_cliente
from utils.usuarioSesion import estado_global

def registro_de_clientes(nombre_cliente, apellido_cliente, cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, fecha_creacion):
    
    nombre_registrador = estado_global.get_nombre()
    apelido_regitrador = estado_global.get_apellido()
    
    return registro_cliente(nombre_cliente, apellido_cliente, cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, nombre_registrador, apelido_regitrador, fecha_creacion)

