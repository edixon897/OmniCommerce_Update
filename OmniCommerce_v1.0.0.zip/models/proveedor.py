from routes.proveedor import registro_proveedor
from utils.usuarioSesion import estado_global

def registro_de_proveedor(nombre_proveedor, apellido_proveedor, documento_proveedor, tipo_documento_proveedor, cuidad_proveedor, direccion_proveedor, telefono_proveedor, correo_proveedor, fecha_registro):
    
    nombre_usuario = estado_global.get_nombre()
    apellido_usuario = estado_global.get_apellido()
    
    return registro_proveedor(nombre_proveedor, apellido_proveedor, documento_proveedor, tipo_documento_proveedor, cuidad_proveedor, direccion_proveedor, telefono_proveedor, correo_proveedor, nombre_usuario, apellido_usuario, fecha_registro)

