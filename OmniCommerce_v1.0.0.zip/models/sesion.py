from routes.sesion import iniciar_sesion

def inicio_de_sesion(documento_usuario, contraseña_usuario):
    
    
    return iniciar_sesion(documento_usuario, contraseña_usuario)