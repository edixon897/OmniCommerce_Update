from conexiondb import create_connection, close_connection
import datetime
from utils.usuarioSesion import estado_global


#REGISTRO DE USUARIO
def registro_producto(codigo_barras, nombre_producto, descripcion_producto, categoria_producto, cantidad_disponible, stock_minimo, precio_unitario, precio_compra, proveedor_producto, fecha_ingreso, ubicacion_almacen, referencia, marca_producto, fecha_vencimiento,   imagen, nombre_creador, apellido_creador):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `productos`
        (`codigo_barras`, `nombre_producto`, `descripcion_producto`, `imagen_producto`, `categoria_producto`, `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, `ubicacion_producto`, `referencia_producto`, `marca_producto`, `fecha_vencimiento`,  `nombre_creador`, `apellido_creador`, `promocion`, `estado_producto`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'no', 'activo')
        """
        cursor.execute(query, (codigo_barras, nombre_producto, descripcion_producto, imagen, categoria_producto, cantidad_disponible, stock_minimo, precio_unitario, precio_compra, proveedor_producto, fecha_ingreso, ubicacion_almacen, referencia, marca_producto, fecha_vencimiento,  nombre_creador, apellido_creador))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            


def actualizar_producto(
    producto_id, nombre_producto, imagen_producto, descripcion_producto, 
    categoria_producto, cantidad_disponible, stock_minim, precio_venta, 
    precio_compra, proveedor_producto, ubicacion_producto, marca_producto, 
    fecha_vencimiento
):
    connection = create_connection()
    if connection is None:
        
        return False

    try:
        cursor = connection.cursor()
        query = """
        UPDATE `productos`
        SET 
            `nombre_producto` = %s, 
            `imagen_producto` = %s, 
            `descripcion_producto` = %s, 
            `categoria_producto` = %s, 
            `cantidad_disponible` = %s, 
            `stock_minimo` = %s, 
            `precio_venta` = %s, 
            `precio_compra` = %s, 
            `proveedor_producto` = %s, 
            `ubicacion_producto` = %s,
            `marca_producto` = %s, 
            `fecha_vencimiento` = %s
        WHERE `id_producto` = %s;
        """
        # Ejecutar la consulta con los valores.
        cursor.execute(query, (
            nombre_producto, imagen_producto, descripcion_producto,
            categoria_producto, cantidad_disponible, stock_minim,
            precio_venta, precio_compra, proveedor_producto,
            ubicacion_producto, marca_producto, fecha_vencimiento, 
            producto_id
        ))

        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Productos', producto_id, 'update', fecha_actual, 
            nombre_registrador
        ))
        inve = """
        INSERT INTO `inventario`( `id_producto`, `tipo_movimiento`, `cantidad`, `fecha`) 
        VALUES (%s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(inve, (
            producto_id, 'ajuste',cantidad_disponible, fecha_actual
        ))


        # Confirmar los cambios.
        connection.commit()
        return True

    except Exception as e:
        
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)





def consulta_producto():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, `ubicacion_producto`,  `nombre_creador`, `apellido_creador` FROM `productos` WHERE `promocion` = 'no' AND `estado_producto` = 'activo'
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        
        
def consulta_producto_promocion():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        fecha_actual = datetime.datetime.now()
        cursor = connection.cursor()
        query = f"""
       SELECT `productos`.`id_producto`, `productos`.`codigo_barras`, `productos`.`nombre_producto`, `productos`.`imagen_producto`, `productos`.`descripcion_producto`, `productos`.`categoria_producto`, `productos`.`cantidad_disponible`, `productos`.`stock_minimo`, `productos`.`precio_venta`, `productos`.`precio_compra`, `productos`.`proveedor_producto`, `productos`.`fecha_ingreso`, `productos`.`ubicacion_producto`, `productos`.`nombre_creador`, `productos`.`apellido_creador`, `promociones`.`precio_promocion`, `promociones`.`fecha_inicio_promocion`, `promociones`.`fecha_fin_promocion`
        FROM `productos` 
        INNER JOIN  `promociones`
        ON `productos`.`id_producto` = `promociones`.`id_producto`
        WHERE `productos`.`promocion` = 'si' AND `promociones`.`fecha_inicio_promocion` <= '{fecha_actual}' AND `promociones`.`estado_promocion` = 'activo' AND `productos`.`estado_producto` = 'activo';
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)


def informacion_producto(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            `id_producto`, 
            `codigo_barras`, 
            `imagen_producto`, 
            `nombre_producto`, 
            `descripcion_producto`, 
            `categoria_producto`, 
            `cantidad_disponible`, 
            `stock_minimo`, 
            `precio_venta`, 
            `precio_compra`, 
            `proveedor_producto`, 
            `fecha_ingreso`, 
            `ubicacion_producto`, 
            `marca_producto`, 
            `fecha_vencimiento`, 
            `nombre_creador`, 
            `apellido_creador` 
        FROM `productos`
        WHERE `id_producto` = %s AND `estado_producto` = 'activo'
        """
        cursor.execute(query, (id,))  # Utiliza parámetros en lugar de concatenar

        resultado = cursor.fetchone() 

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)
        

def producto_promocion(id_promo, precion_promocion, fecha_inico_promo, fecha_fin_promo , codigo_promocion, cantidad_pro):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `promociones`(`id_producto`, `precio_promocion`, `fecha_inicio_promocion`, `fecha_fin_promocion`, `estado_promocion`, `codigo_promocion`) 
        VALUES (%s, %s, %s, %s, 'activo', %s)
        """
        query_inve = f"""
        UPDATE `productos` SET `promocion` = 'si' WHERE  `id_producto` = '{id_promo}'
        """
        cursor.execute(query_inve)
        cursor.execute(query, (id_promo, precion_promocion, fecha_inico_promo, fecha_fin_promo, codigo_promocion))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tablas Promocion, Producto', id_promo, 'insert', fecha_actual, 
            nombre_registrador
        ))
        
        inve = """
        INSERT INTO `inventario`( `id_producto`, `tipo_movimiento`, `cantidad`, `fecha`) 
        VALUES (%s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(inve, (
            id_promo, 'ajuste',cantidad_pro, fecha_actual
        ))


        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)


def buscar_producto(codigo_barras=None, nombre_producto=None, categoria_producto=None, proveedor_producto=None):
    connection = create_connection()
    
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()
        
        # Construimos la base de la consulta
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, 
            `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, 
            `ubicacion_producto`, `nombre_creador`, `apellido_creador`
        FROM `productos`
        WHERE `promocion` = 'no' AND `estado_producto` = 'activo'
        """

        # Lista para los parámetros
        params = []

        # Agregamos condiciones en función de los parámetros recibidos
        if codigo_barras:
            query += " AND `codigo_barras` LIKE %s"
            params.append(f"%{codigo_barras}%")

        if nombre_producto:
            query += " AND `nombre_producto` LIKE %s"
            params.append(f"%{nombre_producto}%")

        if categoria_producto:
            query += " AND `categoria_producto` LIKE %s"
            params.append(f"%{categoria_producto}%")

        if proveedor_producto:
            query += " AND `proveedor_producto` LIKE %s"
            params.append(f"%{proveedor_producto}%")

        # Ejecutamos la consulta con los parámetros dinámicos
        cursor.execute(query, params)
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []

    finally:
        close_connection(connection)



def eliminar_producto(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE productos SET `estado_producto` = 'inactivo' WHERE  `id_producto` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Productos', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def actualizar_cantidad_producto(id, cantidad):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE productos SET `cantidad_disponible` = '{cantidad}' WHERE  `id_producto` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Productos', id, 'update', fecha_actual, 
            nombre_registrador
        ))
        inve = """
        INSERT INTO `inventario`( `id_producto`, `tipo_movimiento`, `cantidad`, `fecha`) 
        VALUES (%s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(inve, (
            id, 'entrada',cantidad, fecha_actual
        ))


        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def buscar_producto_promocion(codigo_barras=None, nombre_producto=None, categoria_producto=None, proveedor_producto=None):
    connection = create_connection()  
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()

        # Consulta base para buscar productos en promoción
        query = """
        SELECT 
            `productos`.`id_producto`, 
            `productos`.`codigo_barras`, 
            `productos`.`nombre_producto`, 
            `productos`.`imagen_producto`, 
            `productos`.`descripcion_producto`, 
            `productos`.`categoria_producto`, 
            `productos`.`cantidad_disponible`, 
            `productos`.`stock_minimo`, 
            `productos`.`precio_unitario`, 
            `productos`.`precio_compra`, 
            `productos`.`proveedor_producto`, 
            `productos`.`fecha_ingreso`, 
            `productos`.`ubicacion_producto`, 
            `productos`.`nombre_creador`, 
            `productos`.`apellido_creador`, 
            `promociones`.`precio_promocion`, 
            `promociones`.`fecha_inicio_promocion`, 
            `promociones`.`fecha_fin_promocion`
        FROM `productos` 
        INNER JOIN `promociones` ON `productos`.`id_producto` = `promociones`.`id_producto`
        WHERE `productos`.`promocion` = 'si' 
        AND `promociones`.`estado_promocion` = 'activo' AND `estado_producto` = 'activo'
        """

        # Lista para almacenar los parámetros de búsqueda
        params = []


        # Condicionales para agregar los filtros de búsqueda
        if codigo_barras:
            query += " AND `inventario`.`codigo_barras` LIKE %s"
            params.append(f"%{codigo_barras}%")
        
        if nombre_producto:
            query += " AND `inventario`.`nombre_producto` LIKE %s"
            params.append(f"%{nombre_producto}%")  # El operador LIKE permite búsqueda parcial
        
        if categoria_producto:
            query += " AND `inventario`.`categoria_producto` = %s"
            params.append( f"%{categoria_producto}%")
        
        if proveedor_producto:
            query += " AND `inventario`.`proveedor_producto` = %s"
            params.append(f"%{proveedor_producto}%")

        # Ejecutar la consulta con los parámetros
        cursor.execute(query, params)

        # Obtener los resultados
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []
    
    finally:
        close_connection(connection)
        
        

def buscar_producto_compra(codigo_barras):
    connection = create_connection()
    
    if connection is None:
       
        return []

    try:
        cursor = connection.cursor()
        
        # Construimos la base de la consulta
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, 
            `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, 
            `ubicacion_producto`, `nombre_creador`, `apellido_creador`
        FROM `productos`
        WHERE `promocion` = 'no' AND `estado_producto` = 'activo' AND
         ( `codigo_barras` LIKE CONCAT('%', %s, '%')
        OR `nombre_producto` LIKE CONCAT('%', %s, '%')
        OR `categoria_producto` LIKE CONCAT('%', %s, '%')
        )
        """

        cursor.execute(query,(codigo_barras, codigo_barras, codigo_barras,))
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []

    finally:
        close_connection(connection)