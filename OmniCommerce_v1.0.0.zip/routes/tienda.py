from conexiondb import create_connection, close_connection

def consultar_empresa():
    # Función que consulta los datos de la empresa desde la base de datos.
    connection = create_connection()
    if connection is None:
        
        return None  # Cambiado a None para identificar falta de datos
    
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_tienda`, `nombre_tienda`, `direccion_tienda`, `telefono_tienda`, 
            `correo_tienda`, `logo_tienda`, `descripcion_tienda`, `fecha_creacion`, `estado_tienda` 
        FROM `tiendas`
        LIMIT 1  -- Suponiendo que solo necesitas el primer registro
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  # Cambiado a fetchone para obtener solo un registro
        return resultado
    except Exception as e:
        
        return None  # Cambiado a None para manejar errores
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)



def register_empresa(nombre_empresa, descripcion_empresa, direccion_empresa, telefono_empresa, correo_empresa, logo_empresa,):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `empresas` 
        (`nombre_tienda`, `descripcion_tienda`, direccion_tienda, `telefono_tienda`, `correo_tienda`, `logo_tienda`,  `fecha_creacion`, `estado_tienda` ) 
        VALUES (%s, %s, %s, %s, %s, %s, NOW())
        """
        cursor.execute(query, (nombre_empresa, descripcion_empresa, direccion_empresa, telefono_empresa, correo_empresa, logo_empresa))
        connection.commit()  # Confirma la transacción
        return True  # Devuelve True si la operación fue exitosa
    except Exception as e:
        
        return False  # Devuelve False si ocurrió un error
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
