from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime


#REGISTRO DE USUARIO 
def registro_categoria(nombre_categoria, descripcion_categoria, nombre_registrador, apellido_registrador, fecha_registro):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `categorias`
        ( `nombre_categoria`, `descripcion_categoria`, `nombre_registrador`, `apellido_registrador`, `fecha_registro`, `estado_categoria`) 
        VALUES (%s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (nombre_categoria, descripcion_categoria, nombre_registrador, apellido_registrador, fecha_registro))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def actualizar_categoria(id_categoria, nombre_categoria, descripcion_categoria):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        UPDATE `clientes`
        SET 
            `nombre_categoria` = %s,
            `descripcion_categoria` = %s,
        WHERE `id_categoria` = %s;
        """
        # Ejecutar la consulta con los valores
        cursor.execute(query, (
            nombre_categoria,
            descripcion_categoria,
            id_categoria
        ))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Categoria', id_categoria, 'update', fecha_actual, 
            nombre_registrador
        ))


        connection.commit()  
        return True
    except Exception as e:
       
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def consulta_categoria():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `nombre_categoria`, `descripcion_categoria`, `nombre_registrador`, `apellido_registrador`, `estado_categoria` FROM `categorias`
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)



def eliminar_categoria(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `categorias` SET `estado_categoria` = 'desactivado' WHERE  `id_categoria` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Categoria', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            