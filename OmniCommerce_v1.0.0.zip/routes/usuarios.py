from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime


#REGISTRO DE USUARIO 
def registro_usuario(nombre_usuario, apellido_usuario, documento_usuario, tipo_documento, fecha_nacimiento, correo_usuario, contraseña_usuario, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, fecha_creacion, rol_usuario, nombre_registrador, apelido_regitrador):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `usuarios`
        (`nombre_usuario`, `apellido_usuario`, `documento_usuario`, `tipo_documento`, `fecha_nacimiento`, `correo_usuario`, `contraseña_usuario`, `telefono_usuario`, `telefono_usuario2`, `direccion_usuario`, `cuidad_usuario`, `fecha_creacion`, `rol_usuario`, `estado_usuario`, `nombre_registrador`, `apellido_registrador`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'activo', %s, %s)
        """
        cursor.execute(query, (nombre_usuario, apellido_usuario, documento_usuario, tipo_documento, fecha_nacimiento, correo_usuario, contraseña_usuario, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, fecha_creacion, rol_usuario, nombre_registrador, apelido_regitrador))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def actualizar_usuario(usuario_id, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, correo_usuario, rol_usuario):
    connection = create_connection()
    if connection is None:
       
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        UPDATE `usuarios`
        SET 
            `telefono_usuario` = %s,
            `telefono_usuario2` = %s,
            `direccion_usuario` = %s,
            `cuidad_usuario` = %s,
            `correo_usuario` = %s,
            `rol_usuario` = %s
        WHERE `id_usuario` = %s;
        """
        # Ejecutar la consulta con los valores
        cursor.execute(query, (
            telefono_usuario, 
            telefono_usuario2, 
            direccion_usuario, 
            cuidad_usuario, 
            correo_usuario, 
            rol_usuario, 
            usuario_id
        ))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Usuario', usuario_id, 'update', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def consulta_usuario():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_usuario`, `nombre_usuario`, `apellido_usuario`, `documento_usuario`, `tipo_documento`, `fecha_nacimiento`, `correo_usuario`, `contraseña_usuario`, `telefono_usuario`, `telefono_usuario2`, `direccion_usuario`, `cuidad_usuario`, `fecha_creacion`, `rol_usuario`, `estado_usuario` 
        FROM `usuarios` LIMIT 3
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        print(f"Error al consultar usuarios: {e}")
        return []
    finally:
        close_connection(connection)


def informacion_usuario(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT `id_usuario`, `nombre_usuario`, `apellido_usuario`, `documento_usuario`, 
               `tipo_documento`, `fecha_nacimiento`, `correo_usuario`, `contraseña_usuario`, 
               `telefono_usuario`, `telefono_usuario2`, `direccion_usuario`, `cuidad_usuario`, 
               `fecha_creacion`, `rol_usuario`, `estado_usuario`
        FROM `usuarios` 
        WHERE `id_usuario` = {id}
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  # utilizo fetchone para que me traiga un solo resultado

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)



def eliminar_usuario(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `usuarios` SET `estado_usuario` = 'desactivado' WHERE  `id_usuario` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de usuario', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def buscar_usuario(nombre_usuario):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_usuario`, `nombre_usuario`, `apellido_usuario`, `documento_usuario`, `tipo_documento`, `fecha_nacimiento`, `correo_usuario`, `contraseña_usuario`, `telefono_usuario`, `telefono_usuario2`, `direccion_usuario`, `cuidad_usuario`, `fecha_creacion`, `rol_usuario`, `estado_usuario` 
        FROM `usuarios`
        WHERE
        ( `nombre_usuario` LIKE CONCAT('%', %s, '%')
        OR `apellido_usuario` LIKE CONCAT('%', %s, '%')
        OR `documento_usuario` LIKE CONCAT('%', %s, '%')
        )
        """
        
        cursor.execute(query, (nombre_usuario, nombre_usuario, nombre_usuario,))
        resultado = cursor.fetchall()
       

        return resultado

    except Exception as e:
        
        return []
    finally:
        close_connection(connection)

