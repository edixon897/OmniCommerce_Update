from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime



            
def actualizar_usuario(usuario_id, telefono_usuario, telefono_usuario2, direccion_usuario, cuidad_usuario, correo_usuario, rol_usuario):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        UPDATE `usuarios`
        SET 
            `telefono_usuario` = %s,
            `telefono_usuario2` = %s,
            `direccion_usuario` = %s,
            `cuidad_usuario` = %s,
            `correo_usuario` = %s,
            `rol_usuario` = %s
        WHERE `id_usuario` = %s;
        """
        # Ejecutar la consulta con los valores
        cursor.execute(query, (
            telefono_usuario, 
            telefono_usuario2, 
            direccion_usuario, 
            cuidad_usuario, 
            correo_usuario, 
            rol_usuario, 
            usuario_id
        ))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Usuario', usuario_id, 'update', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def consulta_ventas():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `indetificador`, `usuario_venta`, `fecha_venta`,  `metodo_pago`, `total`
        FROM `ventas`
        WHERE estado_venta = 'activo'
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)

def consulta_cotizaciones():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT  `identificador`, `usuario_cotizacion`, `fecha_cotizacion`, `total`
        FROM `cotizaciones`
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        

def consulta_devoluciones():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT   `facura_venta`, `usuario_devolucion`, fecha_devolucion, `total`
        FROM `devoluciones`
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        
        

def ver_venta(id):
    connection = create_connection()  # Asumiendo que ya tienes esta función implementada
    if connection is None:
        
        return []
    
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            v.indetificador AS id_venta,
            v.id_cliente,
            v.total,
            p.nombre_producto,
            d.cantidad,
            d.precio_unitario,
            d.subtotal,
            d.producto_venta,
            c.nombre_cliente,
            c.apellido_cliente,
            v.fecha_venta,
            c.direccion_cliente,
            c.cuidad_cliente
        FROM 
            ventas v
        JOIN 
            detallesventa d
        ON 
            v.indetificador = d.id_venta
        JOIN 
        productos p 
        ON
        d.producto_venta = p.id_producto
        JOIN 
        clientes c
        ON
        v.id_cliente = c.documento_cliente
        WHERE 
            v.indetificador = %s AND v.estado_venta = 'activo' AND  d.estado = 'activo'
        """
        cursor.execute(query, (id,))
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)






def informacion_usuario(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT `id_usuario`, `nombre_usuario`, `apellido_usuario`, `documento_usuario`, 
            `tipo_documento`, `fecha_nacimiento`, `correo_usuario`, `contraseña_usuario`, 
            `telefono_usuario`, `telefono_usuario2`, `direccion_usuario`, `cuidad_usuario`, 
            `fecha_creacion`, `rol_usuario`, `estado_usuario`
        FROM `usuarios` 
        WHERE `id_usuario` = {id}
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  # utilizo fetchone para que me traiga un solo resultado

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)








def buscar_ventas(nombre_producto):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `indetificador`, `usuario_venta`, `fecha_venta`,  `metodo_pago`, `total`
        FROM `ventas`
        WHERE
        ( `indetificador` LIKE CONCAT('%', %s, '%')
        OR `usuario_venta` LIKE CONCAT('%', %s, '%')
        OR `fecha_venta` LIKE CONCAT('%', %s, '%')
        )
        """
        
        cursor.execute(query, (nombre_producto, nombre_producto, nombre_producto))
        resultado = cursor.fetchall()
       

        return resultado

    except Exception as e:
        
        return []
    finally:
        close_connection(connection)

def buscar_cotizacion(nombre_producto):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT  `identificador`, `usuario_cotizacion`, `fecha_cotizacion`, `total`
        FROM `cotizaciones`
        WHERE
        ( `identificador` LIKE CONCAT('%', %s, '%')
        OR `usuario_cotizacion` LIKE CONCAT('%', %s, '%')
        OR `fecha_cotizacion` LIKE CONCAT('%', %s, '%')
        )
        """
        
        cursor.execute(query, (nombre_producto, nombre_producto, nombre_producto,))
        resultado = cursor.fetchall()
       

        return resultado

    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        

def buscar_devoluciones(criterio_busqueda):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            `facura_venta`, 
            `usuario_devolucion`, 
            `fecha_devolucion`, 
            `total`
        FROM 
            `devoluciones`
        WHERE
            (`facura_venta` LIKE CONCAT('%', %s, '%')
            OR `usuario_devolucion` LIKE CONCAT('%', %s, '%')
            OR `fecha_devolucion` LIKE CONCAT('%', %s, '%'))
        """
        
        cursor.execute(query, (criterio_busqueda, criterio_busqueda, criterio_busqueda))
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []
    finally:
        if connection.is_connected():
            connection.close()


