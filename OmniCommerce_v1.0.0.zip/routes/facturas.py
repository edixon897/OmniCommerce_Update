from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime

#REGISTRO DE USUARIO 
def registro_cliente(nombre_cliente, apellido_cliente,cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, nombre_usuario, apellido_usuario, fecha_creacion):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `clientes`
        (`nombre_cliente`, `apellido_cliente`, `cuidad_cliente`, `direccion_cliente`, `telefono_cliente`, `correo_cliente`, `tipo_documento`, `documento_cliente`, `nombre_usuario`, `apellido_usuario`, `fecha_creacion`, `estado_cliente`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (nombre_cliente, apellido_cliente, cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, nombre_usuario, apellido_usuario, fecha_creacion))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            





def consulta_facturas():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            facturas.id_factura, 
            GROUP_CONCAT(productos.nombre_producto SEPARATOR ', ') AS productos, 
            facturas.fecha_factura, 
            facturas.estado_factura,
            facturas.total
        FROM 
            facturas 
        JOIN 
            detalles_factura ON facturas.id_factura = detalles_factura.factura_id
        JOIN 
            productos  ON detalles_factura.producto = productos.id_producto
        WHERE 
            facturas.estado = 'activo'
        GROUP BY 
            facturas.id_factura,  facturas.fecha_factura, facturas.estado_factura, facturas.total;

        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)



def informacion_facturas(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT 
            f.id_factura, 
            COALESCE(c.nombre_cliente, '0000') AS nombre_cliente,
            COALESCE(c.apellido_cliente, '0000') AS apellido_cliente,
            COALESCE(c.documento_cliente, '0000') AS documento_cliente,
            COALESCE(c.direccion_cliente, '0000') AS direccion_cliente,
            COALESCE(c.cuidad_cliente, '0000') AS ciudad_cliente,
            p.nombre_producto, 
            f.fecha_factura, 
            f.estado_factura,
            df.cantidad,
            df.precio_unitario,
            f.usuario,
            f.total,
            f.subtotal
        FROM 
            facturas f
        JOIN 
            clientes c ON f.cliente_id = c.documento_cliente
        JOIN 
            detalles_factura df ON f.id_factura = df.factura_id
        JOIN 
            productos p ON df.producto = p.id_producto
        WHERE 
            f.estado = 'activo' AND f.id_factura = {id}
        ORDER BY 
            f.fecha_factura DESC;
        """
        cursor.execute(query)
        resultados = cursor.fetchall()

        if not resultados:
            return {}

        # Extraer información de la factura general (usando el primer resultado)
        factura_info = {
            "id_factura": resultados[0][0],
            "nombre_cliente": resultados[0][1],
            "apellido_cliente": resultados[0][2],
            "documento_cliente": resultados[0][3],
            "direccion_cliente": resultados[0][4],
            "cuidad_cliente": resultados[0][5],
            "fecha_factura": resultados[0][7],
            "estado_factura": resultados[0][8],
            "usuario": resultados[0][11],
            "total": resultados[0][12],
            "subtotal": resultados[0][13],
            "productos": []
        }

        # Agregar los productos a la lista
        for row in resultados:
            producto_info = {
                "nombre_producto": row[6],
                "cantidad": row[9],
                "precio_unitario": row[10]
            }
            factura_info["productos"].append(producto_info)

        return factura_info

    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)



def eliminar_cliente(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `clientes` SET `estado_cliente` = 'desactivado' WHERE  `id_cliente` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Cliente', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
            
def buscar_facturas(buscar):
    connection = create_connection()  
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()

        # Construimos la consulta SQL de forma dinámica
        query = """
        SELECT `id_factura`, `cliente_id`, `fecha_factura`, `fecha_vencimiento`, `subtotal`, `impuestos`, `total`, `forma_pago`, `estado_factura`, `usuario_id`, `estado` FROM `facturas`
        WHERE
        (`id_factura` LIKE CONCAT('%', %s, '%') 
        OR `fecha_factura` LIKE CONCAT('%', %s, '%')

        )
        """

        # Ejecutar la consulta con los parámetros
        cursor.execute(query, (buscar, buscar,))
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
