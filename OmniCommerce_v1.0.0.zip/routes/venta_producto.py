from conexiondb import create_connection, close_connection
import datetime
from utils.usuarioSesion import estado_global



def registro_venta(identifcador, usuario_venta, id_cliente, fecha_venta, total, metodo_pago, codigo_factura):
    connection = create_connection()
    if connection is None:
        
        return False

    fecha_fact = datetime.datetime.now().strftime('%Y-%m-%d')
    
    try:
        cursor = connection.cursor()

        # 1. Registrar la venta
        query = """
        INSERT INTO `ventas` 
        (`indetificador`, `usuario_venta`, `id_cliente`, `fecha_venta`, `total`, `metodo_pago`, `estado_venta`) 
        VALUES (%s, %s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (identifcador, usuario_venta, id_cliente, fecha_venta, total, metodo_pago))

        # 2. Registrar la factura
        fact = """
        INSERT INTO `facturas` 
        (`id_factura`, `cliente_id`, `fecha_factura`, `total`, `forma_pago`, `estado_factura`, `usuario`, `estado`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(fact, (codigo_factura, id_cliente, fecha_fact, total, metodo_pago, 'pagada', usuario_venta, 'activo',))

        # 3. Registrar detalle de la factura

        connection.commit()
        
        return True

    except Exception as e:
        
        connection.rollback()  # Deshacer los cambios si algo falla.
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)



            
def registro_detalle_venta(id_venta, producto_venta, cantidad, precio_unitario, subtotal, tipo_venta, codigo_factura):
    connection = create_connection()
    if connection is None:
        
        return False

    fecha_actual = datetime.datetime.now()
    fecha_caja = datetime.datetime.now().strftime('%Y-%m-%d')

    try:
        cursor = connection.cursor()

        # 1. Insertar el detalle de la venta
        query_detalle = """
        INSERT INTO `detallesventa` 
        (`id_venta`, `producto_venta`, `cantidad`, `precio_unitario`, `subtotal`, `tipo_venta`, `estado`) 
        VALUES (%s, %s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query_detalle, (id_venta, producto_venta, cantidad, precio_unitario, subtotal, tipo_venta,))

        # 2. Registrar el movimiento en inventario
        inve = """
        INSERT INTO `inventario` (`id_producto`, `tipo_movimiento`, `cantidad`, `fecha`) 
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(inve, (producto_venta, 'salida', cantidad, fecha_actual,))

        # 3. Actualizar la cantidad disponible del producto
        query_actualizar_producto = """
        UPDATE `productos` 
        SET `cantidad_disponible` = `cantidad_disponible` - %s 
        WHERE `id_producto` = %s
        """
        cursor.execute(query_actualizar_producto, (cantidad, producto_venta,))

        # 4. Actualizar la caja
        query_caja = """
        UPDATE `caja`
        SET `total_ventas` = `total_ventas` + %s, 
            `saldo_final` = `saldo_final` + %s,
            `ingresos` = `ingresos` + %s
        WHERE `fecha` = %s AND `estado_caja` = 'abierta'
        """
        cursor.execute(query_caja, (cantidad, subtotal, subtotal, fecha_caja,))

        # 5. Actualizar la factura
        fact = """
        UPDATE `facturas` 
        SET `subtotal` = %s 
        WHERE `id_factura` = %s
        """
        cursor.execute(fact, (subtotal, codigo_factura,))

        # 6. Actualizar el detalle de la factura
        detalle_fact = """
        INSERT INTO `detalles_factura`
        (`producto`, `cantidad`, `precio_unitario`, `factura_id`)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(detalle_fact, (producto_venta, cantidad, precio_unitario, codigo_factura,))

        connection.commit()
        
        return True

    except Exception as e:

        

        connection.rollback()  # Deshacer los cambios si algo falla.
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)



def registro_cotizacion(identificador, usuario_cotizacion,  id_cliente, total):
    connection = create_connection()
    if connection is None:
        
        return False

    fecha_cotizacion = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    try:
        cursor = connection.cursor()

        # 1. Registrar la venta
        query = """
        INSERT INTO `cotizaciones` 
        (`identificador`, `usuario_cotizacion`, `id_cliente`, `fecha_cotizacion`,  `total`, `estado_cotizacion`) 
        VALUES (%s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (identificador, usuario_cotizacion, id_cliente, fecha_cotizacion,  total))

        connection.commit()
        
        return True

    except Exception as e:
        
        connection.rollback()  # Deshacer los cambios si algo falla.
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)


def registro_detalle_cotizacion(cotizacion_id, id_producto, cantidad, precio_unitario, subtotal):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()

        # 1. Registrar la venta
        query = """
        INSERT INTO `detalles_cotizacion`
        (`cotizacion_id`, `producto_id`, `cantidad`, `precio_unitario`, `subtotal`) 
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(query, (cotizacion_id, id_producto, cantidad, precio_unitario, subtotal))

        connection.commit()
        
        return True

    except Exception as e:
        
        connection.rollback()  
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)







def consulta_producto():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, `ubicacion_producto`,  `nombre_creador`, `apellido_creador` FROM `productos` WHERE `promocion` = 'no' AND `estado_producto` = 'activo'
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        



def informacion_producto(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            `id_producto`, 
            `codigo_barras`, 
            `imagen_producto`, 
            `nombre_producto`, 
            `descripcion_producto`, 
            `categoria_producto`, 
            `cantidad_disponible`, 
            `stock_minimo`, 
            `precio_venta`, 
            `precio_compra`, 
            `proveedor_producto`, 
            `fecha_ingreso`, 
            `ubicacion_producto`, 
            `marca_producto`, 
            `fecha_vencimiento`, 
            `nombre_creador`, 
            `apellido_creador` 
        FROM `productos`
        WHERE `id_producto` = %s AND `estado_producto` = 'activo'
        """
        cursor.execute(query, (id,))  # Utiliza parámetros en lugar de concatenar

        resultado = cursor.fetchone() 

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)
        


def buscar_producto(buscarProductos):
    connection = create_connection()
    
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()
        
        # Construimos la base de la consulta
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, 
            `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, 
            `ubicacion_producto`, `nombre_creador`, `apellido_creador`
        FROM `productos`
        WHERE `promocion` = 'no' AND `estado_producto` = 'activo'
        ( `codigo_barras` LIKE CONCAT('%', %s, '%')
        OR `nombre_producto` LIKE CONCAT('%', %s, '%')
        OR `categoria_producto` LIKE CONCAT('%', %s, '%')
        )
        """

        # Ejecutamos la consulta con los parámetros dinámicos
        cursor.execute(query, (buscarProductos, buscarProductos, buscarProductos,) )
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []

    finally:
        close_connection(connection)




            
            

            
            

        
        

