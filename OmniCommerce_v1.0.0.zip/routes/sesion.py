
from conexiondb import create_connection, close_connection



def iniciar_sesion(documento_usuario, contraseña_usuario):
    connection = create_connection()
    if connection is None:
        
        return None
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT `nombre_usuario`, `apellido_usuario`
        FROM `usuarios`
        WHERE `documento_usuario` = '{documento_usuario}'
            AND `contraseña_usuario` = '{contraseña_usuario}'
            AND `estado_usuario` = 'activo'
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  
        if resultado:
            return {
                'nombre_usuario': resultado[0],
                'apellido_usuario': resultado[1]
                
            }
        return None
    except Exception as e:
        
        return None
    finally:
        close_connection(connection)