from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime

# REGISTRO DE DEVOLUCIÓN
def registro_devolucion(facura_venta, total, usuario_devolucion, motivo_devolucion):
    connection = create_connection()
    if connection is None:
        
        return False
    fecha_registro = datetime.datetime.now()
    try:
        cursor = connection.cursor()

        # Verificar si la factura ya existe en devoluciones
        check_query = """
        SELECT COUNT(*) FROM devoluciones WHERE facura_venta = %s
        """
        cursor.execute(check_query, (facura_venta,))
        result = cursor.fetchone()
        exists = result[0] > 0

        if exists:
            # Si existe, actualizar la fecha_devolucion y otros campos si es necesario
            update_query = """
            UPDATE devoluciones
            SET total = total + %s, usuario_devolucion = %s, motivo_devolucion = %s, fecha_devolucion = %s
            WHERE facura_venta = %s
            """
            cursor.execute(update_query, (total, usuario_devolucion, motivo_devolucion, fecha_registro, facura_venta))
        else:
            # Si no existe, insertar un nuevo registro
            insert_query = """
            INSERT INTO `devoluciones`
            (`facura_venta`, `total`, `usuario_devolucion`, `motivo_devolucion`, `fecha_devolucion`, `estado_devolucion`)
            VALUES (%s, %s, %s, %s, %s, 'activo')
            """
            cursor.execute(insert_query, (facura_venta, total, usuario_devolucion, motivo_devolucion, fecha_registro))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            

def registro_detalle_devolucion(factura_venta, id_producto, cantidad, precio_uni, subtotal):
    connection = create_connection()
    if connection is None:
        
        return False
    nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
    fecha_registro = datetime.datetime.now()
    try:
        cursor = connection.cursor()

        # Iniciar una transacción
        connection.start_transaction()

        # Insertar en detalle_devolucion
        query = """
        INSERT INTO `detalle_devolucion`
        (`factura_venta`, `id_producto`, `cantidad`, `precio_unitario`, `subtotal`, `fecha_devolucion`)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (factura_venta, id_producto, cantidad, precio_uni, subtotal,fecha_registro))

        # Actualizar cantidad disponible en productos
        reg_produ = """
            UPDATE `productos`
            SET `cantidad_disponible` = `cantidad_disponible` + %s 
            WHERE `id_producto` = %s
        """
        cursor.execute(reg_produ, (cantidad, id_producto))

        # Actualizar detallesventa
        # Obtener el detalle de venta correspondiente
        obtener_detalle = """
            SELECT `cantidad`, `subtotal`
            FROM `detallesventa`
            WHERE `id_venta` = %s AND `producto_venta` = %s AND `estado` = 'activo'
        """
        cursor.execute(obtener_detalle, (factura_venta, id_producto))
        detalle = cursor.fetchone()

        if detalle:
            cantidad_actual = detalle[0]
            subtotal_actual = detalle[1]

            nueva_cantidad = cantidad_actual - cantidad
            nuevo_subtotal = subtotal_actual - subtotal

            if nueva_cantidad > 0:
                # Actualizar detalle de venta con nueva cantidad y subtotal
                actualizar_detalle = """
                    UPDATE `detallesventa`
                    SET `cantidad` = %s, `subtotal` = %s
                    WHERE `id_venta` = %s AND `producto_venta` = %s
                """
                cursor.execute(actualizar_detalle, (nueva_cantidad, nuevo_subtotal, factura_venta, id_producto))
            else:
                # Marcar el detalle de venta como inactivo
                desactivar_detalle = """
                    UPDATE `detallesventa`
                    SET `estado` = 'inactivo'
                    WHERE `id_venta` = %s AND `producto_venta` = %s
                """
                cursor.execute(desactivar_detalle, (factura_venta, id_producto))
        else:
            
            connection.rollback()
            return False

        # Actualizar el total de la venta en la tabla ventas
        actualizar_total_venta = """
            UPDATE `ventas`
            SET `total` = (
                SELECT IFNULL(SUM(`subtotal`), 0)
                FROM `detallesventa`
                WHERE `id_venta` = %s AND `estado` = 'activo'
            )
            WHERE `indetificador` = %s
        """
        cursor.execute(actualizar_total_venta, (factura_venta, factura_venta))

        # Comprobar si todos los detalles de venta están inactivos para desactivar la venta
        verificar_venta = """
            SELECT COUNT(*)
            FROM `detallesventa`
            WHERE `id_venta` = %s AND `estado` = 'activo'
        """
        cursor.execute(verificar_venta, (factura_venta,))
        detalles_activos = cursor.fetchone()[0]

        if detalles_activos == 0:
            # Marcar la venta como inactiva
            desactivar_venta = """
                UPDATE `ventas`
                SET `estado_venta` = 'inactivo'
                WHERE `indetificador` = %s
            """
            cursor.execute(desactivar_venta, (factura_venta,))

        # Insertar en auditoría
        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(audi, (
            'Tabla de DetallesVenta', id_producto, 'update', fecha_registro, 
            nombre_registrador
        ))

        # Confirmar la transacción
        connection.commit()
        return True
    except Exception as e:
        
        if connection.is_connected():
            connection.rollback()
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def ver_devolucion(id):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
        `factura_venta`, 
        `productos`.`nombre_producto`,
        `cantidad`, 
        `precio_unitario`, 
        `subtotal`,
        `fecha_devolucion`
        FROM `detalle_devolucion`
        JOIN  `productos`
        ON `detalle_devolucion`.`id_producto` = `productos`.`id_producto`
        WHERE `factura_venta` = %s
        """
        cursor.execute(query, (id,))
        resultados = cursor.fetchall()  # Obtiene todos los resultados

        if resultados:
            # Convertir resultados a una lista de diccionarios
            columnas = [desc[0] for desc in cursor.description]
            return [dict(zip(columnas, fila)) for fila in resultados]
        else:
            
            return []
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        