from conexiondb import create_connection, close_connection

def verify_code_in_db(code):
    connection = create_connection()
    if connection is None:
        
        return {"existe": False, "usado": None, "actualizado": False}
    
    try:
        cursor = connection.cursor()

        # Verificar si el código existe y su estado actual
        query_select = """
        SELECT `usado` 
        FROM `codigos_registro` 
        WHERE `codigo_registro` = %s
        """
        cursor.execute(query_select, (code,))
        result = cursor.fetchone()

        if result:
            usado = result[0]

            if usado == 'NO':  # Suponiendo que 'NO' es el valor para códigos no usados
                # Actualizar el estado del código a 'SI'
                query_update = """
                UPDATE `codigos_registro`
                SET `usado` = 'SI'
                WHERE `codigo_registro` = %s
                """
                cursor.execute(query_update, (code,))
                connection.commit()

                return {"existe": True, "usado": usado, "actualizado": True}
            else:
                return {"existe": True, "usado": usado, "actualizado": False}
        else:
            return {"existe": False, "usado": None, "actualizado": False}
    
    except Exception as e:
        
        return {"existe": False, "usado": None, "actualizado": False}
    
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
