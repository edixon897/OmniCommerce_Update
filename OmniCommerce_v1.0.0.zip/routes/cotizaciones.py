
from conexiondb import create_connection, close_connection


def detalle_cotizacion(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = """
        SELECT
        c.`identificador`,
        p.nombre_producto,
        d.cantidad,
        d.precio_unitario,
        c.usuario_cotizacion,
        c.fecha_cotizacion,
        c.total,
        cl.nombre_cliente,
        cl.apellido_cliente,
        cl.documento_cliente,
        cl.direccion_cliente,
        cl.cuidad_cliente,
        
        d.subtotal
        
        FROM `cotizaciones` c
        JOIN 
            detalles_cotizacion d  ON  d.cotizacion_id = c.identificador
        JOIN 
            productos p  ON d.producto_id = p.id_producto
        JOIN 
            clientes cl ON c.id_cliente = cl.documento_cliente
            
        WHERE c.`identificador` = %s
        """


        cursor.execute(query, (id,))  # Utiliza parámetros en lugar de concatenar

        resultado = cursor.fetchall()
        

        return resultado
    except Exception as e:
        
        return {}