from conexiondb import create_connection, close_connection
from utils.usuarioSesion import estado_global
import datetime

#REGISTRO DE USUARIO 
def registro_cliente(nombre_cliente, apellido_cliente,cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, nombre_usuario, apellido_usuario, fecha_creacion):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `clientes`
        (`nombre_cliente`, `apellido_cliente`, `cuidad_cliente`, `direccion_cliente`, `telefono_cliente`, `correo_cliente`, `tipo_documento`, `documento_cliente`, `nombre_usuario`, `apellido_usuario`, `fecha_creacion`, `estado_cliente`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (nombre_cliente, apellido_cliente, cuidad_cliente, direccion_cliente, telefono_cliente, correo_cliente, tipo_documento, documento_cliente, nombre_usuario, apellido_usuario, fecha_creacion))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def actualizar_cliente(usuario_id, telefono_cliente,  direccion_cliente, cuidad_cliente, correo_cliente):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        UPDATE `clientes`
        SET 
            `telefono_cliente` = %s,
            `direccion_cliente` = %s,
            `cuidad_cliente` = %s,
            `correo_cliente` = %s
        WHERE `id_cliente` = %s;
        """
        # Ejecutar la consulta con los valores
        cursor.execute(query, (
            telefono_cliente, 
            direccion_cliente, 
            cuidad_cliente, 
            correo_cliente, 
            usuario_id
        ))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Clientes', usuario_id, 'update', fecha_actual, 
            nombre_registrador
        ))


        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def consulta_cliente():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_cliente`, `nombre_cliente`, `apellido_cliente`, `cuidad_cliente`, `direccion_cliente`, `telefono_cliente`, `correo_cliente`, `tipo_documento`, `documento_cliente`, `nombre_usuario`, `apellido_usuario`, `fecha_creacion`, `estado_cliente` FROM `clientes`
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)


def informacion_cliente(id):
    connection = create_connection()
    if connection is None:
       
        return {}
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT `id_cliente`, `nombre_cliente`, `cuidad_cliente`, `direccion_cliente`, `telefono_cliente`, `correo_cliente`, `tipo_documento`, `documento_cliente`, `nombre_usuario`, `apellido_usuario`, `fecha_creacion`, `estado_cliente` FROM `clientes` 
        WHERE `id_cliente` = {id}
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  # utilizo fetchone para que me traiga un solo resultado

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}
    finally:
        close_connection(connection)



def eliminar_cliente(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `clientes` SET `estado_cliente` = 'desactivado' WHERE  `id_cliente` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Cliente', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
            
def buscar_cliente(nombre_cliente):
    connection = create_connection()  
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()

        # Construimos la consulta SQL de forma dinámica
        query = """
        SELECT `id_cliente`, `nombre_cliente`, `apellido_cliente`, `cuidad_cliente`, `direccion_cliente`, `telefono_cliente`, `correo_cliente`, `tipo_documento`, `documento_cliente`, `nombre_usuario`, `apellido_usuario`, `fecha_creacion`, `estado_cliente`
        FROM `clientes`
        WHERE 
        (`nombre_cliente` LIKE CONCAT('%', %s, '%') 
        OR `apellido_cliente` LIKE CONCAT('%', %s, '%') 
        OR `documento_cliente` LIKE CONCAT('%', %s, '%'))
        """

        # Ejecutar la consulta con los parámetros
        cursor.execute(query, (nombre_cliente, nombre_cliente, nombre_cliente,))
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
