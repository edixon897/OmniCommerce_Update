from conexiondb import create_connection, close_connection
from  utils.usuarioSesion import estado_global
import datetime


#REGISTRO DE USUARIO 
def registro_proveedor(nombre_proveedor, apellido_proveedor, documento_proveedor, tipo_documento_proveedor, cuidad_proveedor, direccion_proveedor, telefono_proveedor, correo_proveedor, nombre_usuario, apellido_usuario, fecha_registro):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `proveedores`
        (`nombre_proveedor`, `apellido_proveedor`, `documento_proveedor`, `tipo_documento_proveedor`, `cuidad_proveedor`, `direccion_proveedor`, `telefono_proveedor`, `correo_proveedor`, `nombre_registrador`, `apellido_registrador`, `fecha_registro`, `estado_proveedor`) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'activo')
        """
        cursor.execute(query, (nombre_proveedor, apellido_proveedor, documento_proveedor, tipo_documento_proveedor, cuidad_proveedor, direccion_proveedor, telefono_proveedor, correo_proveedor, nombre_usuario, apellido_usuario, fecha_registro))
        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
def actualizar_proveedor(id_proveedor, telefono_proveedor,  direccion_proveedor, cuidad_proveedor, correo_proveedor):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        UPDATE `proveedores`
        SET 
            `telefono_proveedor` = %s,
            `direccion_proveedor` = %s,
            `cuidad_proveedor` = %s,
            `correo_proveedor` = %s
        WHERE `id_proveedor` = %s;
        """
        # Ejecutar la consulta con los valores
        cursor.execute(query, (
            telefono_proveedor, 
            direccion_proveedor, 
            cuidad_proveedor, 
            correo_proveedor, 
            id_proveedor
        ))
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Proveedor', id_proveedor, 'update', fecha_actual, 
            nombre_registrador
        ))


        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)




def consulta_proveedor():

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_proveedor`, `nombre_proveedor`, `apellido_proveedor`, `documento_proveedor`, `tipo_documento_proveedor`, `cuidad_proveedor`, `direccion_proveedor`, `telefono_proveedor`, `correo_proveedor`, `nombre_registrador`, `apellido_registrador`, `fecha_registro`, `estado_proveedor` FROM `proveedores`
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)


def informacion_proveedor(id):
    connection = create_connection()
    if connection is None:
       
        return {}
    try:
        cursor = connection.cursor()
        query = f"""
        SELECT `id_proveedor`, `nombre_proveedor`, `apellido_proveedor`, `documento_proveedor`, `tipo_documento_proveedor`, `cuidad_proveedor`, `direccion_proveedor`, `telefono_proveedor`, `correo_proveedor`, `nombre_registrador`, `apellido_registrador`, `fecha_registro`, `estado_proveedor` FROM `proveedores` 
        WHERE `id_proveedor` = {id}
        """
        cursor.execute(query)
        resultado = cursor.fetchone()  
        if resultado:
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        return {}
    finally:
        close_connection(connection)



def eliminar_proveedor(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `proveedores` SET `estado_proveedor` = 'desactivado' WHERE  `id_proveedor` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Proveedor', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
       
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)



def buscar_proveedor(nombre_proveedor=None, apellido_proveedor=None, documento_proveedor=None):

    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_proveedor`, `nombre_proveedor`, `apellido_proveedor`, `documento_proveedor`, `tipo_documento_proveedor`, `cuidad_proveedor`, `direccion_proveedor`, `telefono_proveedor`, `correo_proveedor`, `nombre_registrador`, `apellido_registrador`, `fecha_registro`, `estado_proveedor`
         FROM `proveedores`
         WHERE 1=1
        """

        parametros = []

        if nombre_proveedor:
            query += " AND nombre_proveedor LIKE %s"
            parametros.append(f"%{nombre_proveedor}%")

        if apellido_proveedor:
            query += " AND apellido_proveedor LIKE %s"
            parametros.append(f"%{apellido_proveedor}%")

        if documento_proveedor:
            query += " AND documento_proveedor LIKE %s"
            parametros.append(f"%{documento_proveedor}%")

        cursor.execute(query, parametros)
        resultado = cursor.fetchall()

        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)

            