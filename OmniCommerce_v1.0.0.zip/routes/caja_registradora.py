from conexiondb import create_connection, close_connection
import datetime
from utils.usuarioSesion import estado_global


#REGISTRO DE USUARIO
def registro_caja(codigo_caja, fecha_registro, id_usuario, saldo_inicial, ):
    connection = create_connection()
    if connection is None:
        
        return False
    
    try:
        cursor = connection.cursor()
        query = """
        INSERT INTO `caja`
        (`codigo_caja`, `fecha_hora`, `usuario_registro`,  `saldo_inicial`, `saldo_final`, `fecha`, `estado_caja`,`estado`) 
        VALUES (%s, %s, %s, %s, %s, %s, 'abierta','activo')
        
        """
        cursor.execute(query, (codigo_caja, fecha_registro, id_usuario, saldo_inicial, saldo_inicial, fecha_registro))

        #detalle = """
        #    INSERT INTO `detalle_caja`
        #    (`codigo_caja`, `cierre_caja`)
        #    VALUES (%s, 'no')
        #"""
        #cursor.execute(detalle, (codigo_caja, ))

        
        connection.commit()  
        return True
    except Exception as e:
       
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            


def actualizar_caja(id_caja, cantida_dinero):
    connection = create_connection()
    if connection is None:
        
        return False

    try:
        cursor = connection.cursor()
        query = """
        UPDATE `caja`
        SET 
        `saldo_final` =  `saldo_final` + %s
        WHERE `id_registro` = %s;
        """
        # Ejecutar la consulta con los valores.
        cursor.execute(query, ( cantida_dinero, id_caja))

        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla de Caja Registradora', id_caja,  'update', fecha_actual,nombre_registrador,))
        
        connection.commit()
        return True

    except Exception as e:
        
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            
            
def registrar_detalle(id_factura, ingresos, egresos, monto_pago):
    connection = create_connection()
    if connection is None:
        
        return False

    try:
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()
        fecha_caja = datetime.datetime.now().strftime('%Y-%m-%d')

        cursor = connection.cursor()
        query = """
        SELECT `codigo_caja` FROM `caja` 
        WHERE `estado_caja` = 'abierta' AND `estado` = 'activo' AND `fecha` = %s
        """
        cursor.execute(query, (fecha_caja,))
        resultado = cursor.fetchall()
        
        if not resultado:
            
            return False
        
        codigo = resultado[0][0]  # Extrae el valor correcto de la tupla

        query_detalle = """
        INSERT INTO `detalle_caja` (
            `codigo_caja`, `id_factura`, `ingresos`, `egresos`, `monto_pago`, `fecha_hor`, `usuario_venta`
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query_detalle, (codigo, id_factura, ingresos, egresos, monto_pago, fecha_actual, nombre_registrador))


        audi = """
        INSERT INTO `auditoria` (
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(audi, (
            'Registro en detalle de Caja', codigo, 'INSERT', fecha_actual, nombre_registrador))
        
        query_caja = """
        UPDATE `caja`
        SET 
            `egresos` = `egresos` + %s
        WHERE `fecha` = %s AND `estado_caja` = 'abierta' 
        """
        cursor.execute(query_caja, (egresos, fecha_actual, ))

        connection.commit()
        return True

    except Exception as e:
        
        return False

    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)

            






def consulta_caja():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_registro`, `codigo_caja`, `fecha_hora`, `saldo_final` FROM `caja` WHERE `estado` = 'activo' 
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)
        
        


def informacion_caja(id):
    connection = create_connection()
    if connection is None:
        
        return {}
    try:
        cursor = connection.cursor()
        query = """
        SELECT
            *
        FROM `caja`
        WHERE `estado` = 'activo' AND `id_registro` = %s
        """
        cursor.execute(query, (id,))  # Utiliza parámetros en lugar de concatenar

        resultado = cursor.fetchone() 

        # Verifico si el resultado no es None antes de convertirlo en un diccionario
        if resultado:
            # Mapeo el resultado a un diccionario usando los nombres de las columnas
            columnas = [desc[0] for desc in cursor.description]
            usuario = dict(zip(columnas, resultado))
            return usuario
        else:
            
            return {}
    except Exception as e:
        
        return {}




def informacion_detalle(id_detalle):
    connection = create_connection()
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
        `id_factura`, 
        `ingresos`, 
        `egresos`, 
        `monto_pago`, 
        `fecha_hor`, 
        `usuario_venta` 
        FROM `detalle_caja` 
        WHERE `codigo_caja` = %s
        """
        cursor.execute(query, (id_detalle,))
        resultados = cursor.fetchall()  # Obtiene todos los resultados

        if resultados:
            # Convertir resultados a una lista de diccionarios
            columnas = [desc[0] for desc in cursor.description]
            return [dict(zip(columnas, fila)) for fila in resultados]
        else:
            return []
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)

        




def buscar_caja(codigo_barras):
    connection = create_connection()
    
    if connection is None:
        
        return []

    try:
        cursor = connection.cursor()
        
        # Construimos la base de la consulta
        query = """
        SELECT `id_producto`, `codigo_barras`, `nombre_producto`, `imagen_producto`, `descripcion_producto`, `categoria_producto`, 
            `cantidad_disponible`, `stock_minimo`, `precio_venta`, `precio_compra`, `proveedor_producto`, `fecha_ingreso`, 
            `ubicacion_producto`, `nombre_creador`, `apellido_creador`
        FROM `productos`
        WHERE `promocion` = 'no' AND `estado_producto` = 'activo'
        """

        # Lista para los parámetros
        params = []

        # Agregamos condiciones en función de los parámetros recibidos
        if codigo_barras:
            query += " AND `codigo_barras` LIKE %s"
            params.append(f"%{codigo_barras}%")

        

        # Ejecutamos la consulta con los parámetros dinámicos
        cursor.execute(query, params)
        resultado = cursor.fetchall()

        return resultado

    except Exception as e:
        
        return []

    finally:
        close_connection(connection)



def eliminar_caja(id):
    connection = create_connection()
    if connection is None:
        
        return False
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE caja SET `estado` = 'inactivo' WHERE  `id_registro` = '{id}'
        """
        cursor.execute(query)
        # Preparar datos para la auditoría.
        nombre_registrador = f"{estado_global.get_nombre()} {estado_global.get_apellido()}"
        fecha_actual = datetime.datetime.now()

        audi = """
        INSERT INTO `auditoria`(
            `tabla_afectada`, `id_registro_afectado`, `tipo_accion`, 
            `fecha_accion`, `usuario_responsable`
        ) 
        VALUES (%s, %s, %s, %s, %s)
        """
        # Ejecutar la auditoría.
        cursor.execute(audi, (
            'Tabla  Caja de Registro', id, 'delete', fecha_actual, 
            nombre_registrador
        ))

        connection.commit()  
        return True
    except Exception as e:
        
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)
            
            

            
            

        
        

