# routes/estadisticas.py


from conexiondb import create_connection, close_connection
from datetime import datetime

def cargar_estadisticas(semana_inicio, semana_fin):
    try:
        conexion = create_connection()
        cursor = conexion.cursor(dictionary=True)
    
        # Total de clientes
        cursor.execute("SELECT COUNT(DISTINCT id_cliente) AS total_clientes FROM ventas")
        clientes_result = cursor.fetchone()
        clientes = clientes_result['total_clientes'] if clientes_result else 0
    
        # Ingresos y egresos de la tabla detalle_caja
        cursor.execute("""
            SELECT
                SUM(ingresos) AS total_ingresos,
                SUM(egresos) AS total_egresos
            FROM detalle_caja
            WHERE fecha_hor BETWEEN %s AND %s
        """, (semana_inicio, semana_fin))
        ingresos_egresos = cursor.fetchone()
        ingresos = ingresos_egresos['total_ingresos'] or 0
        egresos = ingresos_egresos['total_egresos'] or 0
    
        # Ganancias (Ingresos - Egresos)
        ganancias = ingresos - egresos
    
        # Total de facturas
        cursor.execute("SELECT COUNT(*) AS total_facturas FROM facturas WHERE fecha_factura BETWEEN %s AND %s", (semana_inicio, semana_fin))
        facturas_result = cursor.fetchone()
        facturas = facturas_result['total_facturas'] if facturas_result else 0
    
        # Ventas del mes actual
        mes_inicio = datetime.now().replace(day=1)
        mes_fin = datetime.now()
        cursor.execute("""
            SELECT SUM(total) AS total_ventas_mes
            FROM ventas
            WHERE fecha_venta BETWEEN %s AND %s
        """, (mes_inicio, mes_fin))
        ventas_mes_result = cursor.fetchone()
        ventas_mes = ventas_mes_result['total_ventas_mes'] or 0
    
        close_connection(conexion)
        return clientes, ingresos, ganancias, facturas, ventas_mes
    except Exception as e:
        
        return None
