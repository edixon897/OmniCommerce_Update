from conexiondb import create_connection, close_connection


def consulta_ubicacion():
    connection = create_connection()  
    if connection is None:
        
        return []
    try:
        cursor = connection.cursor()
        query = """
        SELECT `id_ubicacion`, `nombre_ubicacion`, `descripcion`, `edificio`, `piso`, `estante`, `casillero` FROM `ubicaciones_produc` 
        """
        cursor.execute(query)
        resultado = cursor.fetchall()
        return resultado
    except Exception as e:
        
        return []
    finally:
        close_connection(connection)