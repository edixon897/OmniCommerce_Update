import flet as ft
import shutil
import os
import re

# Ruta donde se guardará la imagen
DESTINATION_FOLDER = "assets/logo_empresa"  # Cambia esto a tu ruta deseada

# Asegúrate de que la carpeta de destino existe
os.makedirs(DESTINATION_FOLDER, exist_ok=True)

def crear_modal_tienda(page: ft.Page, on_submit, nombre_tienda="", direccion_tienda="", telefono_tienda="", correo_tienda="", logo_tienda_field="", descripcion_tienda=""):

    def validar_correo(campo):
        patron = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        return re.match(patron, campo.value) is not None

    def validar_telefono(campo):
        return campo.value.isdigit() and 7 <= len(campo.value) <= 15

    def validar_nombre(campo):
        return len(campo.value) >= 3

    def validar_campo(event, validacion_funcion, mensaje_error):
        campo = event.control
        if campo.value:  # Validar solo si hay texto ingresado
            if validacion_funcion(campo):
                campo.error_text = None
            else:
                campo.error_text = mensaje_error
        else:
            campo.error_text = None  # No mostrar error si no hay texto
        page.update()
        actualizar_botones()  # Actualizar botones después de la validación

    def actualizar_botones():
        campos_obligatorios = [
            nombre_tienda_field,
            telefono_tienda_field,
            correo_tienda_field,
        ]
        completados = all(campo.value for campo in campos_obligatorios)
        sin_errores = all(campo.error_text is None for campo in campos_obligatorios)

        # Habilitar el botón Guardar solo si todos los campos obligatorios están llenos y no tienen errores
        boton_guardar.disabled = not (completados and sin_errores)
        page.update()

    def actualizar_logo(event):
        if event.files:
            file = event.files[0]
            source_path = file.path
            destination_path = os.path.join(DESTINATION_FOLDER, file.name)

            # Copia el archivo a la nueva ubicación
            shutil.copy(source_path, destination_path)

            # Actualiza el campo de texto con el nombre del archivo
            logo_tienda_field.value = file.name
            logo_tienda_field.update()
        else:
            logo_tienda_field.value = "Seleccione el logo"
            logo_tienda_field.update()

    # Campos del formulario, con valores iniciales si se proporcionan
    nombre_tienda_field = ft.TextField(label="Nombre de la tienda", width=250, value=nombre_tienda, on_change=lambda e: validar_campo(e, validar_nombre, "El nombre debe tener al menos 3 caracteres"))
    direccion_tienda_field = ft.TextField(label="Dirección de la tienda", width=250, value=direccion_tienda, on_change=actualizar_botones)
    telefono_tienda_field = ft.TextField(label="Teléfono de la tienda", width=250, value=telefono_tienda, on_change=lambda e: validar_campo(e, validar_telefono, "Teléfono inválido"))
    correo_tienda_field = ft.TextField(label="Correo de la tienda", width=250, value=correo_tienda, on_change=lambda e: validar_campo(e, validar_correo, "Correo inválido"))
    descripcion_tienda_field = ft.TextField(label="Descripción de la tienda", width=250, height=80, multiline=True, value=descripcion_tienda, on_change=actualizar_botones)
    
    logo_empresa_field = ft.FilePicker(on_result=actualizar_logo)
    logo_tienda_field = ft.Text(value="Seleccione el logo", width=200)

    # Botón para abrir el selector de archivos
    logo_picker_button = ft.ElevatedButton("Seleccionar Logo", on_click=lambda _: logo_empresa_field.pick_files(allow_multiple=False))
    
    # Asegúrate de agregar el FilePicker al page.controls
    page.overlay.append(logo_empresa_field)

    # Mensaje de éxito (inicialmente oculto)
    success_message = ft.Text(
        "Formulario enviado con éxito!",
        color=ft.colors.GREEN,
        visible=False
    )

    # Función para manejar el cierre del modal
    def cerrar_modal(e):
        modal.open = False
        page.update()

    # Función para manejar el envío del formulario
    def enviar_formulario(e):
        # Recolectar los datos ingresados en el formulario
        tienda_data = {
            "nombre_tienda": nombre_tienda_field.value,
            "direccion_tienda": direccion_tienda_field.value,
            "telefono_tienda": telefono_tienda_field.value,
            "correo_tienda": correo_tienda_field.value,
            "logo_tienda": logo_tienda_field.value,
            "descripcion_tienda": descripcion_tienda_field.value,
        }
        # Llamar la función de callback con los datos del formulario
        on_submit(tienda_data)
        # Mostrar mensaje de éxito
        success_message.visible = True
        page.update()

    # Definir el modal con el formulario, ajustando el diseño en dos columnas
    modal = ft.AlertDialog(
        modal=True,
        content=ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text("Registrar Tienda", weight="bold", size=18),  # Ajusta el tamaño del título
                            ft.IconButton(
                                icon=ft.icons.CLOSE,
                                on_click=cerrar_modal,
                                tooltip="Cerrar",
                                icon_color=ft.colors.RED
                            ),
                        ],
                        alignment="spaceBetween",
                        vertical_alignment="center",  # Centrar verticalmente
                    ),
                    ft.Divider(height=1, color=ft.colors.GREY_200),  # Línea divisoria para separar el título del contenido
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    nombre_tienda_field,
                                    direccion_tienda_field,
                                    telefono_tienda_field,
                                ],
                                spacing=10,
                            ),
                            ft.Column(
                                [
                                    correo_tienda_field,
                                    logo_tienda_field,
                                    logo_picker_button,
                                    descripcion_tienda_field,
                                ],
                                spacing=10,
                            ),
                        ],
                        spacing=20,
                        alignment="center",  
                    ),
                    ft.Row(
                        [
                            ft.ElevatedButton(
                                "Guardar",
                                on_click=enviar_formulario,
                                bgcolor=ft.colors.BLUE,
                                color=ft.colors.WHITE,
                                disabled=True, 
                            ),
                            ft.TextButton(
                                "Cancelar",
                                on_click=cerrar_modal,
                            ),
                        ],
                        alignment="end",
                        spacing=10,  # Espacio entre los botones
                    ),
                    success_message,
                ],
                spacing=15,
                alignment="start",  # Alineación vertical del contenido
                horizontal_alignment="center",
            ),
            width=550,
            height=350,
            padding=20,
            bgcolor=ft.colors.WHITE,  # Remover color gris
            border_radius=8,
        ),
    )

    # Encontrar el botón de guardar correctamente
    boton_guardar = next(
        (control for control in modal.content.content.controls[3].controls if isinstance(control, ft.ElevatedButton) and control.text == "Guardar"), 
        None
    )
    actualizar_botones()  # Llamada inicial para asegurarse de que los botones están configurados correctamente

    # Función para mostrar el modal
    def mostrar_modal():
        page.dialog = modal
        modal.open = True
        success_message.visible = False
        page.update()

    return mostrar_modal

