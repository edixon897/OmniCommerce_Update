import flet as ft
from utils.promocion.promocion import mostrar_modal_promocion

# Variable global para almacenar el producto seleccionado
producto_seleccionado = None

def mostrar_modal_producto(page, producto):
    """Muestra el modal con las opciones del producto seleccionado."""
    global producto_seleccionado
    producto_seleccionado = producto  # Establecer el producto seleccionado

    # Crear el contenido del modal con un contenedor que define ancho y alto
    modal_content = ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(f"{producto[2]}", size=24, weight=ft.FontWeight.BOLD),
                        ft.IconButton(
                            icon=ft.icons.CLOSE,
                            on_click=lambda e: cerrar_modal(page),
                            tooltip="Cerrar",
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                ft.Row(
                    [
                        ft.ElevatedButton(
                            "Poner en Promoción", 
                            on_click=lambda e: poner_en_promocion(page),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                                color=ft.colors.WHITE,
                                bgcolor=ft.colors.GREEN,
                                padding=15,
                            ),
                        ),
                        ft.ElevatedButton(
                            "Editar Producto", 
                            on_click=lambda e: editar_producto(page),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                                color=ft.colors.WHITE,
                                bgcolor=ft.colors.BLUE,
                                padding=15,
                            ),
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                ),
                ft.Row(
                    [
                        ft.ElevatedButton(
                            "Ver Información del Producto", 
                            on_click=lambda e: ver_mas(page),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                                color=ft.colors.WHITE,
                                bgcolor=ft.colors.ORANGE,
                                padding=15,
                            ),
                        ),
                        ft.ElevatedButton(
                            "Eliminar Producto", 
                            on_click=lambda e: eliminar_producto(page),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                                color=ft.colors.WHITE,
                                bgcolor=ft.colors.RED,
                                padding=15,
                            ),
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=20,
        ),
        width=500,  # Ancho del contenido del modal
        height=250,  # Alto del contenido del modal
        padding=20,
        border_radius=ft.border_radius.all(20),  # Borde redondeado
        bgcolor=ft.colors.WHITE
    )

    # Crear el modal
    modal = ft.AlertDialog(
        content=modal_content,
        actions=[
            ft.TextButton(
                "Cerrar", 
                on_click=lambda e: cerrar_modal(page),
                style=ft.ButtonStyle(
                    shape=ft.RoundedRectangleBorder(radius=10),
                    padding=15,
                ),
            )
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    
    page.dialog = modal
    modal.open = True
    page.update()

def poner_en_promocion(page):
    
    cerrar_modal(page)
    mostrar_modal_promocion(page, producto_seleccionado)

def editar_producto(page):
    # Lógica para editar el producto
    
    cerrar_modal(page)

def ver_mas(page):
    # Lógica para ver más sobre el producto
    
    cerrar_modal(page)

def eliminar_producto(page):
    # Lógica para eliminar el producto
    
    cerrar_modal(page)

def cerrar_modal(page):
    """Cerrar el modal y actualizar la página."""
    page.dialog.open = False
    page.update()
