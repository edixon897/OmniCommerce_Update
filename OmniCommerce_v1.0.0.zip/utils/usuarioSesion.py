

class EstadoGlobal:
    def __init__(self):
        self.usuario = None

    def set_usuario(self, usuario):
        self.usuario = usuario

    def get_nombre(self):
        if self.usuario:
            return f"{self.usuario['nombre_usuario']}"
        return "Usuario Desconocido"
    def get_apellido(self):
        if self.usuario:
            return f"{self.usuario['apellido_usuario']}"
        return "Usuario Desconocido"
        

# Instancia global de EstadoGlobal
estado_global = EstadoGlobal()
