import flet as ft
from utils.mensajeAlerta import mostrar_alerta_auto
from models.proveedor import registro_de_proveedor
import datetime
import re

def mostrar_modal(page):
    def cerrar_modal(e=None):
        page.dialog.open = False
        page.update()

    def validar_campo(campo, validacion_funcion, mensaje_error):
        """ Valida un campo y actualiza el mensaje de error si es necesario. """
        if campo.value:  # Validar solo si hay texto ingresado
            if validacion_funcion(campo):
                campo.error_text = None
            else:
                campo.error_text = mensaje_error
        else:
            campo.error_text = None  # No mostrar error si no hay texto
        page.update()

    def actualizar_progreso(e=None):
        # Validación de campos con errores dinámicos solo al ingresar texto
        for campo, validacion_funcion, mensaje_error in validaciones:
            validar_campo(campo, validacion_funcion, mensaje_error)

        # Contar campos obligatorios completados
        completados = sum(1 for campo in campos_obligatorios if campo.value)

        # Actualizar el valor de la barra de progreso
        progreso.value = completados / len(campos_obligatorios)

        # Desactivar botón de guardar si no se han completado todos los campos obligatorios o si hay errores
        boton_guardar.disabled = completados < len(campos_obligatorios) or any(
            campo.error_text for campo, _, _ in validaciones
        )

        page.update()

    def registrar_empresa_y_administrador(e):
        registro = registro_de_proveedor(
            nombre_proveedor.value,
            apellido_proveedor.value,
            documento_proveedor.value,
            tipo_documento_proveedor.value,
            cuidad_proveedor.value,
            direccion_proveedor.value,
            telefono_proveedor.value,
            correo_proveedor.value,
            fecha_registro = datetime.datetime.now(),
        )

        if registro:
            cerrar_modal()
            mostrar_alerta_auto(page, "Proveedor creado", "Proveedor creado exitosamente", duracion=3)            
        else:
            mostrar_alerta_auto(page, "Error de registro", "El Proveedor no ha podido ser registrado", duracion=3)
        page.update()


    progreso = ft.ProgressBar(width=300, height=20, color=ft.colors.GREEN, bgcolor=ft.colors.LIGHT_GREEN)

    
    nombre_proveedor = ft.TextField(label="Nombre de proveerdor", on_change=actualizar_progreso)
    apellido_proveedor = ft.TextField(label="Apellido de proveedor", on_change=actualizar_progreso)
    documento_proveedor = ft.TextField(label="Documento de proveedor", on_change=actualizar_progreso)
    tipo_documento_proveedor = ft.Dropdown(
        label="Tipo de Documento", on_change=actualizar_progreso,
        options=[
            ft.dropdown.Option("Cédula de Ciudadanía"),
            ft.dropdown.Option("Pasaporte"),
            ft.dropdown.Option("Tarjeta de Identidad"),
        ],
    )
    correo_proveedor = ft.TextField(label="Correo Electrónico", on_change=actualizar_progreso)
    telefono_proveedor = ft.TextField(label="Teléfono", on_change=actualizar_progreso)
    direccion_proveedor = ft.TextField(label="Dirección (opcional)", on_change=actualizar_progreso)
    cuidad_proveedor= ft.TextField(label="Ciudad", on_change=actualizar_progreso)


    
    campos_obligatorios = [nombre_proveedor , apellido_proveedor, documento_proveedor, correo_proveedor, tipo_documento_proveedor, telefono_proveedor, cuidad_proveedor]

    
    validaciones = [
        (nombre_proveedor , lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
        (apellido_proveedor, lambda campo: len(campo.value) >= 3, "Debe tener al menos 3 caracteres"),
        (documento_proveedor, lambda campo: campo.value.isdigit() and len(campo.value) >= 8, "Debe ser numérico y tener al menos 8 dígitos"),
        (correo_proveedor, lambda campo: re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", campo.value) is not None, "Correo inválido"),
        (telefono_proveedor, lambda campo: campo.value.isdigit() and 10 <= len(campo.value) <= 12, "Debe tener entre 10 y 12 dígitos"),
    ]

    
    boton_guardar = ft.ElevatedButton("Guardar", on_click=registrar_empresa_y_administrador, disabled=True)
    boton_cancelar = ft.TextButton("Cancelar", on_click=cerrar_modal)

    
    modal = ft.AlertDialog(
        title=ft.Row(
            [
                ft.Text("Agregar Proveedor", weight=ft.FontWeight.BOLD, size=20),
                ft.IconButton(icon=ft.icons.CLOSE, icon_color=ft.colors.RED, on_click=cerrar_modal),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        content=ft.Container(
            content=ft.Column(
                [
                    progreso,
                    ft.Row([nombre_proveedor , apellido_proveedor]),
                    ft.Row([tipo_documento_proveedor, correo_proveedor]),
                    ft.Row([documento_proveedor, telefono_proveedor]),
                    ft.Row([cuidad_proveedor, direccion_proveedor]),
                ],
                spacing=10,
                scroll="auto",
            ),
            padding=10,
            width=630,
        ),
        actions=[
            boton_cancelar,
            boton_guardar,
        ],
        modal=True,
        on_dismiss=cerrar_modal,
        shape=ft.RoundedRectangleBorder(radius=10),
        bgcolor=ft.colors.WHITE,
    )

    # Mostrar modal
    actualizar_progreso()
    page.dialog = modal
    modal.open = True
    page.update()
