import flet as ft
from barcode import EAN13
from barcode.writer import ImageWriter
from horario.fecha import fecha_hora
import os
from rembg import remove


from models.productos import registro_de_productos
from routes.proveedor import consulta_proveedor
from routes.categoria import consulta_categoria

DESTINATION_FOLDER = "assets/image" 
DESTINATION_FOLDER_CODIGO_BARRAS = "assets/img"

# Asegúrate de que la carpeta de destino existe
os.makedirs(DESTINATION_FOLDER, exist_ok=True)

def mostrar_modal_producto_agg(page):
    
    # Categorías y proveedores simulados
    categorias = consulta_categoria()  
    proveedores = consulta_proveedor()  

    # Variable para almacenar el archivo seleccionado
    imagen_seleccionada = None

    # Función para generar el código de barras y guardarlo como imagen
    def generador_barras(codigo_barras):
        barcode_path = os.path.join(DESTINATION_FOLDER_CODIGO_BARRAS, f"{codigo_barras}.png")
        with open(barcode_path, 'wb') as f:
            EAN13(codigo_barras, writer=ImageWriter()).write(f)
        return barcode_path

    # Función para guardar la imagen seleccionada
    def guardar_imagen(file):
        if file:
            # El archivo seleccionado tiene un atributo "path" que contiene su ruta temporal
            image_path = os.path.join(DESTINATION_FOLDER, file.name)
            
            # Leer la imagen original desde la ruta del archivo seleccionado
            with open(file.path, 'rb') as input_file:
                input_data = input_file.read()

            # Eliminar el fondo de la imagen
            output_data = remove(input_data)  # Eliminar fondo

            # Guardar la imagen sin fondo en la carpeta de destino
            image_path_sin_fondo = os.path.join(DESTINATION_FOLDER, f"{file.name}")
            with open(image_path_sin_fondo, 'wb') as output_file:
                output_file.write(output_data)
            
            # Retornar el nombre del archivo sin fondo para guardarlo en la base de datos
            return f"{file.name}"

        return None

    # Función para manejar el resultado de la selección de imagen
    def on_image_selected(e):
        nonlocal imagen_seleccionada
        if e.files:
            imagen_seleccionada = e.files[0]  # Guardar el archivo seleccionado
            campo_imagen.value = imagen_seleccionada.name  # Mostrar el nombre de la imagen seleccionada
            page.update()

    # Controles del modal
    codigo_barra = ft.TextField(label="Código de Barras", width=300)
    nombre_producto = ft.TextField(label="Nombre del Producto", width=300)
    descripcion_producto = ft.TextField(label="Descripción del Producto", width=300, multiline=True, max_lines=3)
    
    # Selectores de categoría y proveedor
    categoria_producto = ft.Dropdown(
        label="Categoría del Producto",
        options=[ft.dropdown.Option(key=str(cat[0]), text=cat[1]) for cat in categorias],
        width=300
    )
    
    proveedor_producto = ft.Dropdown(
        label="Proveedor del Producto",
        options=[ft.dropdown.Option(key=str(prov[1]), text=prov[1]) for prov in proveedores],
        width=300
    )
    
    cantidad_disponible = ft.TextField(label="Cantidad Disponible", width=300)
    stock_minimo = ft.TextField(label="Stock Mínimo", width=300)
    precio_unitario = ft.TextField(label="Precio Unitario", width=300)
    precio_compra = ft.TextField(label="Precio de Compra", width=300)
    ubicacion_almacen = ft.TextField(label="Ubicación en Almacén", width=300)


    # Campo para mostrar el nombre de la imagen seleccionada
    campo_imagen = ft.TextField(label="Imagen seleccionada", read_only=True, width=300)

    # Selector de imagen
    imagen_producto = ft.FilePicker(on_result=on_image_selected)
    btn_seleccionar_imagen = ft.ElevatedButton("Seleccionar Imagen", on_click=lambda _: imagen_producto.pick_files(allow_multiple=False))
    page.overlay.append(imagen_producto)

    # Botones de acción
    btn_guardar = ft.ElevatedButton("Guardar", on_click=lambda e: guardar_producto())
    btn_cancelar = ft.ElevatedButton("Cancelar", on_click=lambda e: cerrar_modal())

    # Función para guardar el producto
    def guardar_producto():
        if not codigo_barra.value.strip():
            page.snack_bar = ft.SnackBar(ft.Text("El código de barras es obligatorio"), open=True)
            page.update()
            return
        
        # Generar el código de barras
        generador_barras(codigo_barra.value)
        
        # Guardar la imagen seleccionada
        imagen_path = guardar_imagen(imagen_seleccionada) if imagen_seleccionada else None

        # Datos del producto
        registro_de_productos(
            codigo_barra.value,
            nombre_producto.value,
            descripcion_producto.value,
            categoria_producto.value,
            proveedor_producto.value,
            cantidad_disponible.value,
            stock_minimo.value,
            precio_unitario.value,
            precio_compra.value,
            fecha_hora,
            ubicacion_almacen.value,
            campo_imagen.value
        )

        
        
        page.snack_bar = ft.SnackBar(ft.Text("Producto guardado exitosamente"), open=True)
        modal_producto.open = False
        page.update()

    # Modal con los campos organizados
    modal_producto = ft.AlertDialog(
        title=ft.Row(
            [
                ft.Text("Crear Producto", size=24, weight="bold"),
                ft.IconButton(ft.icons.CLOSE, on_click=lambda _: cerrar_modal(), icon_size=24)
            ],
            alignment="spaceBetween"
        ),
        content=ft.Column(
            [
                ft.Row([codigo_barra, nombre_producto]),
                ft.Row([cantidad_disponible, stock_minimo]),
                ft.Row([precio_unitario, precio_compra]),
                ft.Row([ubicacion_almacen, btn_seleccionar_imagen]),
                ft.Row([categoria_producto, campo_imagen]),
                ft.Row([proveedor_producto, descripcion_producto]),
            ],
            spacing=10,
            height=350,
            width=630
        ),
        actions=[btn_guardar, btn_cancelar],
        modal=True
    )

    # Mostrar el modal
    page.dialog = modal_producto
    modal_producto.open = True
    page.update()

    # Función para cerrar el modal
    def cerrar_modal(e=None):
        modal_producto.open = False
        page.update()



