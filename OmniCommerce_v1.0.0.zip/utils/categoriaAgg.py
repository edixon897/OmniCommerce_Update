import flet as ft
from models.categoria import registro_de_categoria
from utils.mensajeAlerta import mostrar_alerta_auto

def show_create_category_modal(page):
    # Función para mostrar el modal
    def on_save_click(e):
        # Lógica para guardar la categoría
        if nombre_categoria.value.strip() == "":
            nombre_categoria.error_text = "El nombre de la categoría es obligatorio"
            nombre_categoria.update()
        else:
            nombre = nombre_categoria.value
            descripcion = descripcion_categoria.value
            registro_de_categoria(nombre, descripcion)
            page.dialog.open = False
            page.update()
            mostrar_alerta_auto(page, "Registro exitoso", f"Categoria registrada exitosamente", duracion=3)

    # Función para cerrar el modal
    def on_close_click(e=None):
        page.dialog.open = False
        page.update()

    nombre_categoria = ft.TextField(
        label="Nombre de la categoría",
        hint_text="Ingrese el nombre de la categoría",
        autofocus=True,
        error_text="",
        expand=True
    )
    
    descripcion_categoria = ft.TextField(
        label="Descripción (opcional)",
        hint_text="Ingrese una descripción (opcional)",
        multiline=True,
        expand=True
    )
    
    modal = ft.AlertDialog(
        modal=True,
        title=ft.Row(
            [
                ft.Text("Crear nueva categoría", expand=True),
                ft.IconButton(ft.icons.CLOSE, on_click=lambda e: on_close_click())  # Botón X para cerrar
            ]
        ),
        content=ft.Container(
            content=ft.Column(
                [
                    nombre_categoria,
                    descripcion_categoria,
                ],
                tight=True,
            ),
            width=400,  # Ancho del contenido del modal
            height=150,  # Altura del contenido del modal
            padding=ft.padding.all(10),
        ),
        actions=[
            ft.ElevatedButton("Guardar", on_click=on_save_click),
            ft.TextButton("Cancelar", on_click=lambda e: on_close_click())  # También cierra el modal
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )

    page.dialog = modal
    page.dialog.open = True
    page.update()


