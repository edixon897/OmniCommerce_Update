from datetime import datetime
import flet as ft
from routes.productos import producto_promocion

def mostrar_modal_promocion(page, producto):
    """Muestra un modal para crear una promoción para el producto seleccionado."""

    # Elementos del modal
    precio_promocion = ft.TextField(label="Precio Promoción", width=250)
    

    # Variables para almacenar fecha y hora seleccionadas
    fecha_inicio = None
    hora_inicio = None
    fecha_fin = None
    hora_fin = None

    # Textos para mostrar las fechas y horas seleccionadas
    fecha_inicio_text = ft.Text("Selecciona la fecha de inicio", size=16)
    hora_inicio_text = ft.Text("Selecciona la hora de inicio", size=16)
    fecha_fin_text = ft.Text("Selecciona la fecha de fin", size=16)
    hora_fin_text = ft.Text("Selecciona la hora de fin", size=16)

    # Funciones para actualizar la fecha y hora seleccionadas
    def actualizar_fecha_inicio(e):
        nonlocal fecha_inicio
        fecha_inicio = e.control.value
        fecha_inicio_text.value = f"Fecha de inicio: {fecha_inicio.strftime('%d/%m/%Y')}"
        page.update()

    def actualizar_hora_inicio(e):
        nonlocal hora_inicio
        hora_inicio = e.control.value  # Ya es un objeto datetime.time
        hora_inicio_text.value = f"Hora de inicio: {hora_inicio.strftime('%H:%M')}"
        page.update()

    def actualizar_fecha_fin(e):
        nonlocal fecha_fin
        fecha_fin = e.control.value
        fecha_fin_text.value = f"Fecha de fin: {fecha_fin.strftime('%d/%m/%Y')}"
        page.update()

    def actualizar_hora_fin(e):
        nonlocal hora_fin
        hora_fin = e.control.value  # Ya es un objeto datetime.time
        hora_fin_text.value = f"Hora de fin: {hora_fin.strftime('%H:%M')}"
        page.update()

    # Botones para seleccionar la fecha y hora de inicio
    btn_fecha_inicio = ft.ElevatedButton(
        "Seleccionar Fecha Inicio",
        icon=ft.icons.CALENDAR_MONTH,
        on_click=lambda e: page.open(
            ft.DatePicker(
                first_date=datetime(2023, 10, 1),
                last_date=datetime(2024, 10, 1),
                on_change=actualizar_fecha_inicio,
            )
        ),
    )

    btn_hora_inicio = ft.ElevatedButton(
        "Seleccionar Hora Inicio",
        icon=ft.icons.ACCESS_TIME_FILLED,
        on_click=lambda e: page.open(
            ft.TimePicker(
                confirm_text="Confirmar",
                on_change=actualizar_hora_inicio,
            )
        ),
    )

    # Botones para seleccionar la fecha y hora de fin
    btn_fecha_fin = ft.ElevatedButton(
        "Seleccionar Fecha Fin",
        icon=ft.icons.CALENDAR_MONTH,
        on_click=lambda e: page.open(
            ft.DatePicker(
                first_date=datetime(2024, 10, 1),
                last_date=datetime(2030, 10, 1),
                on_change=actualizar_fecha_fin,
            )
        ),
    )

    btn_hora_fin = ft.ElevatedButton(
        "Seleccionar Hora Fin",
        icon=ft.icons.ACCESS_TIME_FILLED,
        on_click=lambda e: page.open(
            ft.TimePicker(
                confirm_text="Confirmar",
                on_change=actualizar_hora_fin,
            )
        ),
    )

    # Función para manejar la lógica al guardar la promoción
    def guardar_promocion(e):
        if fecha_inicio and hora_inicio and fecha_fin and hora_fin:
            # Combinar fecha y hora en un objeto datetime
            datetime_inicio = datetime.combine(fecha_inicio, hora_inicio)
            datetime_fin = datetime.combine(fecha_fin, hora_fin)

            # Precio de promoción
            precio_prom = precio_promocion.value
            codigo = codigo_promocion.value

            # Aquí puedes agregar la lógica para guardar en la base de datos
           

            # Cerrar el modal después de guardar
            cerrar_modal(page)
        else:
            return

    # Mostrar fecha y hora seleccionadas juntas
    date_time_row_inicio = ft.Row(
        [fecha_inicio_text, hora_inicio_text],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=20,
    )

    date_time_row_fin = ft.Row(
        [fecha_fin_text, hora_fin_text],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=20,
    )

    # Crear el modal
    modal_content = ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(f"Crear Promoción para: {producto[2]}", size=20, weight=ft.FontWeight.BOLD),
                        ft.IconButton(
                            icon=ft.icons.CLOSE,
                            on_click=lambda e: cerrar_modal(page),
                            tooltip="Cerrar",
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                precio_promocion, codigo_promocion,
                ft.Row(
                    [
                        btn_fecha_inicio,
                        btn_hora_inicio,
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                ),
                date_time_row_inicio,  # Fecha y hora de inicio juntas
                ft.Row(
                    [
                        btn_fecha_fin,
                        btn_hora_fin,
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                ),
                date_time_row_fin,  # Fecha y hora de fin juntas
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=20,
        ),
        width=500,  # Ancho del modal
        height=380,  # Alto del modal
        padding=20,
        border_radius=ft.border_radius.all(20),  # Bordes redondeados
        bgcolor=ft.colors.WHITE,
    )

    # Botones "Guardar" y "Cancelar" alineados a la izquierda
    modal = ft.AlertDialog(
        content=modal_content,
        actions=[
            ft.Row(
                [
                    ft.ElevatedButton(
                        "Guardar Promoción",
                        on_click=guardar_promocion,
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(radius=10),
                            color=ft.colors.WHITE,
                            bgcolor=ft.colors.GREEN,
                            padding=15,
                        ),
                    ),
                    ft.TextButton(
                        "Cancelar",
                        on_click=lambda e: cerrar_modal(page),
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=15,
                        ),
                    ),
                ],
                alignment=ft.MainAxisAlignment.END,  # Alineación a la izquierda
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )

    page.dialog = modal
    modal.open = True
    page.update()

def cerrar_modal(page):
    """Cierra el modal y actualiza la página."""
    page.dialog.open = False
    page.update()
 #CREAR PROMOCIONES PARA PRODUCTOS
   