from flet import AlertDialog, Text, Page
import threading

# Función para mostrar un alert que se cierra automáticamente
def mostrar_alerta_auto(page: Page, titulo: str, mensaje: str, duracion: int = 3):
    # Crear un diálogo de alerta
    alerta = AlertDialog(
        title=Text(titulo),
        content=Text(mensaje),
        modal=True,  # Hacer que el diálogo sea modal (centrado y encima del contenido)
    )

    # Mostrar el diálogo en la página
    page.dialog = alerta
    alerta.open = True
    page.update()

    # Función para cerrar el alert después de la duración especificada
    def cerrar_alerta():
        # Esperar la duración especificada
        threading.Timer(duracion, lambda: cerrar()).start()

    def cerrar():
        # Cerrar el alert automáticamente
        alerta.open = False
        page.update()

    # Llamar a la función de cerrar_alerta
    cerrar_alerta()