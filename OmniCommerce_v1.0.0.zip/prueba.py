import xml.etree.ElementTree as ET
from conexiondb import create_connection, close_connection


def generar_factura_xml(factura_id):
    connection = create_connection()
    if connection is None:
        print("No hay conexión con la base de datos")
        return None
    factura_id="FAC-000021"
    try:
        cursor = connection.cursor()
        query = """
        SELECT 
            f.id_factura, 
            c.nombre_cliente, 
            p.nombre_producto, 
            f.fecha_factura, 
            f.estado_factura,
            f.total,
            df.cantidad,
            df.precio_unitario,
            p.id_producto
        FROM 
            facturas f
        JOIN 
            clientes c ON f.cliente_id = c.id_cliente
        JOIN 
            detalles_factura df ON f.id_factura = df.factura_id
        JOIN 
            productos p ON df.producto = p.id_producto
        WHERE 
            f.id_factura  = %s
        """
        cursor.execute(query, (factura_id,))
        factura = cursor.fetchall()
        if not factura:
            print("No se encontraron datos para la factura con ID:", factura_id)
            return None

        # Crear el árbol XML
        invoice = ET.Element("Invoice", attrib={
            "xmlns": "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
            "xmlns:cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
            "xmlns:cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
            "xmlns:ext": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"
        })
        
        # Información básica
        ET.SubElement(invoice, "cbc:ID").text = str(factura[0][0])  # Número de factura
        ET.SubElement(invoice, "cbc:IssueDate").text = str(factura[0][3])  # Fecha de emisión
        
        # Agregar información del cliente
        customer = ET.SubElement(invoice, "cac:AccountingCustomerParty")
        party = ET.SubElement(customer, "cac:Party")
        ET.SubElement(party, "cbc:CompanyID", attrib={"schemeID": "13"}).text = str(factura[0][0])
        ET.SubElement(party, "cbc:Name").text = str(factura[0][1])
        
        # Agregar detalles de los productos
        for item in factura:
            invoice_line = ET.SubElement(invoice, "cac:InvoiceLine")
            ET.SubElement(invoice_line, "cbc:ID").text = str(item[8])
            ET.SubElement(invoice_line, "cbc:InvoicedQuantity", attrib={"unitCode": "EA"}).text = str(item[6])
            ET.SubElement(invoice_line, "cbc:LineExtensionAmount", attrib={"currencyID": "COP"}).text = str(item[5])
            item_desc = ET.SubElement(invoice_line, "cac:Item")
            ET.SubElement(item_desc, "cbc:Description").text = item[2]
            price = ET.SubElement(invoice_line, "cac:Price")
            ET.SubElement(price, "cbc:PriceAmount", attrib={"currencyID": "COP"}).text = str(item[7])

        # Convertir a cadena de texto XML
        xml_data = ET.tostring(invoice, encoding='utf8', method='xml').decode()

        return xml_data

    except Exception as e:
        print(f"Error al generar XML: {e}")
        return None

    finally:
        close_connection(connection)

def guardar_factura_xml(factura_id):
    # Llamar a la función que genera el XML
    xml_data = generar_factura_xml(factura_id)
    
    if xml_data:
        # Guardar el XML en un archivo local
        with open("factura.xml", "w") as f:
            f.write(xml_data)
        print("Factura XML generada y guardada como 'factura.xml'")
    else:
        print("No se pudo generar la factura XML")

# Probar la función con una factura de ejemplo (ID 1)
guardar_factura_xml(1)
