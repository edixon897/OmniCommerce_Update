
import random
from conexiondb import create_connection, close_connection

# Función para generar un código de factura aleatorio de 6 dígitos
def generar_codigo_factura_aleatorio():
    return f"{random.randint(100000, 999999)}"

# Función para verificar si el código ya existe en la base de datos
def verificar_existencia_codigo(codigo):
    connection = create_connection()
    if connection is None:
        return False

    try:
        cursor = connection.cursor()
        cursor.execute("SELECT id_factura FROM facturas WHERE id_factura=%s", (codigo,))
        resultado = cursor.fetchone()
        return resultado is not None
    except Exception as e:
        return False
    finally:
        cursor.close()
        close_connection(connection)

# Función para generar un código de factura único
def generar_codigo_factura_unico():
    codigo = generar_codigo_factura_aleatorio()
    while verificar_existencia_codigo(codigo):
        codigo = generar_codigo_factura_aleatorio()
    return codigo
