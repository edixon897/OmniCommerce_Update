import schedule
import time
import datetime
import threading
from conexiondb import create_connection, close_connection


# Función para actualizar la base de datos
def actualizar_base_datos(id):
    connection = create_connection()
    if connection is None:
        return False
    
    try:
        cursor = connection.cursor()
        query = f"""
        UPDATE `promociones` SET `estado_promocion` = 'terminado' WHERE `id_producto` = '{id}';
        """
        query_inve = f"""
        UPDATE `productos` SET `promocion` = 'no' WHERE `id_producto` = '{id}';
        """
        cursor.execute(query_inve)
        cursor.execute(query)
        connection.commit()  
        print('Actualizada: ', query, query_inve)
        return True
    except Exception as e:
        print(f"Error al actualizar promoción: {e}")
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)

# Función para verificar la fecha de finalización de promociones
def verificar_fecha_fin():
    print('En ejecución')
    connection = create_connection()
    if connection is None:
        return False

    try:
        cursor = connection.cursor()
        query = """
        SELECT `productos`.`id_producto`, `promociones`.`fecha_fin_promocion`
        FROM `productos` 
        INNER JOIN `promociones`
        ON `productos`.`id_producto` = `promociones`.`id_producto`
        WHERE `productos`.`promocion` = 'si' AND `promociones`.`estado_promocion` = 'activo'
        """
        cursor.execute(query)
        resultados = cursor.fetchall()

        for row in resultados:
            id_producto, fecha_fin_promocion = row
            fecha_formateada = fecha_fin_promocion.strftime("%Y/%m/%d %H:%M:%S")
            fecha_hora = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            if fecha_formateada <= fecha_hora:  
                actualizar_base_datos(id_producto)
                
    except Exception as e:
        return False
    finally:
        if connection.is_connected():
            cursor.close()
            close_connection(connection)

#Función que ejecuta el scheduler en segundo plano
def run_scheduler():
    schedule.every(1).minutes.do(verificar_fecha_fin)
    
    while True:
        schedule.run_pending()
        time.sleep(1)

        

# Inicia la ejecución del scheduler en un hilo separado
scheduler_thread = threading.Thread(target=run_scheduler)
scheduler_thread.daemon = True  # Aseguro que el hilo se cierre cuando la aplicación principal termine
scheduler_thread.start()


